'use client';
import { useState, useEffect } from 'react';
import { useFirestore, useMemoFirebase, errorEmitter, FirestorePermissionError } from '@/firebase';
import {
  collection,
  query,
  onSnapshot,
  FirestoreError,
  DocumentData,
  QuerySnapshot,
  collectionGroup,
  where,
  getDocs,
  Timestamp,
} from 'firebase/firestore';
import type { DjProfile, Event } from '@/types';

// Cache para perfis de DJ
const djProfileCache = new Map<string, DjProfile>();

export function useDjs() {
  const firestore = useFirestore();
  const [djs, setDjs] = useState<DjProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<FirestoreError | null>(null);

  const djsCollectionRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(collection(firestore, 'djProfiles'));
  }, [firestore]);

  useEffect(() => {
    if (!djsCollectionRef || !firestore) return;

    setIsLoading(true);
    const unsubscribe = onSnapshot(
      djsCollectionRef,
      async (snapshot: QuerySnapshot<DocumentData>) => {
        try {
          const fetchedDjs = snapshot.docs.map(doc => {
              const data = { id: doc.id, ...doc.data() } as DjProfile;
              return data;
          });

          // Otimização: Buscar contagem de todos os eventos futuros de uma só vez
          const agendaCollection = collectionGroup(firestore, 'agenda');
          const futureEventsQuery = query(agendaCollection, where('date', '>=', Timestamp.now()));
          const futureEventsSnapshot = await getDocs(futureEventsQuery);

          const eventCounts = new Map<string, number>();
          futureEventsSnapshot.forEach(eventDoc => {
              const djId = eventDoc.ref.parent.parent?.id;
              if (djId) {
                  eventCounts.set(djId, (eventCounts.get(djId) || 0) + 1);
              }
          });
          
          const djsWithEventCount = fetchedDjs.map(dj => ({
              ...dj,
              eventCount: eventCounts.get(dj.id) || 0,
          }));
          
          // Ordenação no lado do cliente
          djsWithEventCount.sort((a, b) => {
              const aTime = a.lastEventUpdate ? new Date(a.lastEventUpdate.toString()).getTime() : 0;
              const bTime = b.lastEventUpdate ? new Date(b.lastEventUpdate.toString()).getTime() : 0;
              if (bTime !== aTime) return bTime - aTime;

              if (b.verified && !a.verified) return 1;
              if (!b.verified && a.verified) return -1;
              
              return (a.name || '').localeCompare(b.name || '');
          });

          djsWithEventCount.forEach(dj => djProfileCache.set(dj.id, dj));

          setDjs(djsWithEventCount);
          setError(null);
        } catch (e) {
            const err = e as FirestoreError;
            console.error("useDjs - Erro ao buscar contagem de eventos:", err);
            setError(err);
            if (err.code === 'permission-denied') {
                 const contextualError = new FirestorePermissionError({
                    operation: 'list',
                    path: 'agenda', // Representing the collection group
                });
                errorEmitter.emit('permission-error', contextualError);
            }
        } finally {
            setIsLoading(false);
        }
      },
      (err: FirestoreError) => {
        console.error("useDjs - Erro ao buscar perfis de DJ:", err);
        setError(err);
        setIsLoading(false);
         if (err.code === 'permission-denied') {
            const contextualError = new FirestorePermissionError({
                operation: 'list',
                path: 'djProfiles',
            });
            errorEmitter.emit('permission-error', contextualError);
        }
      }
    );

    return () => unsubscribe();
  }, [djsCollectionRef, firestore]);

  return { djs, isLoading, error };
}
