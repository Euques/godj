'use client';
import { useState, useEffect } from 'react';
import { useFirestore, useMemoFirebase } from '@/firebase';
import { getDocument } from '@/firebase/firestore-reads';
import {
  collectionGroup,
  query,
  where,
  getDocs,
  Timestamp,
  doc,
  type FirestoreError,
  orderBy,
  collection,
} from 'firebase/firestore';
import type { Event, DjProfile } from '@/types';
import { getSafeDate } from '@/lib/utils';
import { useDjs } from './use-djs';


// Cache para perfis de DJ para evitar re-fetching desnecessário
const djProfileCache = new Map<string, DjProfile>();

export function useEvents() {
  const firestore = useFirestore();
  const { djs: allDjs, isLoading: areDjsLoading } = useDjs();
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const agendaCollectionGroup = useMemoFirebase(() => {
    if (!firestore) return null;
    return collectionGroup(firestore, 'agenda');
  }, [firestore]);

  useEffect(() => {
    if (areDjsLoading || !agendaCollectionGroup || !firestore) {
      return;
    }

    const fetchEvents = async () => {
      setIsLoading(true);
      setError(null);

      // Pré-popular o cache com os DJs já carregados
      allDjs.forEach(dj => djProfileCache.set(dj.id, dj));

      try {
        const now = Timestamp.now();
        // Query for all future events, ordering by their event date
        const q = query(agendaCollectionGroup, where('date', '>=', now), orderBy('date', 'asc'));
        
        const querySnapshot = await getDocs(q);

        const fetchedEvents: Event[] = await Promise.all(
          querySnapshot.docs.map(async (eventDoc) => {
            const eventData = eventDoc.data() as Omit<Event, 'id'>;
            const djProfileId = eventDoc.ref.parent.parent?.id;

            if (!djProfileId) {
              return null;
            }

            let djProfile: DjProfile | undefined = djProfileCache.get(djProfileId);

            if (!djProfile) {
              const djDocSnap = await getDocument(doc(firestore, 'djProfiles', djProfileId));
              if (djDocSnap) {
                  djProfile = { id: djDocSnap.id, ...djDocSnap } as DjProfile;
                  djProfileCache.set(djProfileId, djProfile);
              }
            }
            
            if (!djProfile) return null;

            // Contar eventos futuros para este DJ (se necessário)
            const agendaSnapshot = await getDocs(query(collection(firestore, `djProfiles/${djProfileId}/agenda`), where('date', '>=', now)));
            const futureEventCount = agendaSnapshot.size;

            return {
              id: eventDoc.id,
              ...eventData,
              date: eventData.date, // Mantém o formato original
              lastUpdatedAt: eventData.lastUpdatedAt, // Mantém o formato original
              djProfileId: djProfile.id,
              djName: djProfile.name,
              djSlug: djProfile.slug,
              djProfilePictureUrl: djProfile.profilePictureUrl,
              djIsVerified: djProfile.verified || false,
              djEventCount: futureEventCount,
            };
          })
        );
        
        const validEvents = fetchedEvents.filter((e): e is Event => e !== null);
        
        setEvents(validEvents);

      } catch (e: any) {
        console.error("Falha ao buscar eventos com collectionGroup:", e);
        setError(e);
      } finally {
        setIsLoading(false);
      }
    };

    fetchEvents();
  }, [agendaCollectionGroup, firestore, allDjs, areDjsLoading]);

  return { events, isLoading: isLoading || areDjsLoading, error };
}
