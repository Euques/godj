import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const url = request.nextUrl
  const hostname = request.headers.get('x-forwarded-host') || request.headers.get('host') || ''
  const pathname = url.pathname

  // 1. Normalização do Hostname: Remove porta e converte para minúsculas
  const rawHostname = hostname.split(':')[0].toLowerCase().trim()
  
  // 2. Limpeza do prefixo 'www.': Tratamos o domínio de forma idêntica com ou sem www
  // Usamos regex para garantir que apenas o 'www.' inicial seja removido
  const cleanHostname = rawHostname.replace(/^www\./, '')

  // Lista de domínios internos/principais (sem o prefixo www pois já limpamos acima)
  const mainDomains = [
    'localhost',
    'godj.com.br',
  ]

  const isMainDomain = mainDomains.includes(cleanHostname) || 
                       cleanHostname.endsWith('.firebaseapp.com') || 
                       cleanHostname.endsWith('.web.app') ||
                       cleanHostname.endsWith('.run.app') ||
                       cleanHostname.includes('ais-dev') ||
                       cleanHostname.includes('ais-pre')

  // Lista de caminhos que devem ser ignorados (rotas de sistema e administração)
  const isSystemPath = pathname.startsWith('/_next') ||
                       pathname.startsWith('/api') ||
                       pathname.startsWith('/admin') ||
                       pathname.startsWith('/super-admin') ||
                       pathname.startsWith('/login') ||
                       pathname.startsWith('/signup') ||
                       pathname.startsWith('/perfil') || 
                       pathname.startsWith('/eventos') ||
                       pathname.startsWith('/djs') ||
                       pathname.includes('.') // Arquivos estáticos

  if (isSystemPath) {
    return NextResponse.next()
  }

  // 3. Lógica para o domínio principal (godj.com.br)
  if (isMainDomain) {
    // Se for a home, deixa passar
    if (pathname === '/') {
      return NextResponse.next()
    }
    
    // Rewrite interno: godj.com.br/katatau -> /perfil/katatau
    const slug = pathname.substring(1) // Remove a barra inicial
    return NextResponse.rewrite(new URL(`/perfil/${slug}`, request.url))
  }

  // 4. Lógica para Subdomínios (ex: euques.godj.com.br) ou Domínios Personalizados (ex: meudj.com)
  let identifier = cleanHostname

  // Extração do identificador do DJ se for um subdomínio da plataforma
  if (identifier.endsWith('.godj.com.br')) {
      identifier = identifier.replace('.godj.com.br', '')
  }
  
  // Se o usuário está na RAIZ do domínio personalizado, mostramos o perfil do dono do domínio
  if (pathname === '/') {
      return NextResponse.rewrite(new URL(`/perfil/${identifier}`, request.url))
  }

  // Se o usuário está em outro caminho (ex: meudominio.com/katatau), 
  // permitimos que ele navegue para outros perfis ou páginas normalmente.
  const slug = pathname.substring(1)
  return NextResponse.rewrite(new URL(`/perfil/${slug}`, request.url))
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
