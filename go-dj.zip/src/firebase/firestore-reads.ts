'use client';

import {
  getDoc,
  getDocs,
  DocumentReference,
  Query,
  DocumentData,
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Performs a getDoc operation with contextual error handling.
 */
export async function getDocument(docRef: DocumentReference): Promise<DocumentData | null> {
  try {
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    errorEmitter.emit(
      'permission-error',
      new FirestorePermissionError({
        path: docRef.path,
        operation: 'get',
      })
    );
    throw error;
  }
}

/**
 * Performs a getDocs operation with contextual error handling.
 */
export async function getDocuments(query: Query): Promise<DocumentData[]> {
  try {
    const querySnapshot = await getDocs(query);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    // Note: For collectionGroup queries, the path will be less specific.
    // The error handler in use-events.ts provides a more representative path.
    const path = (query as any)._query.path?.canonicalString() || 'unknown path';
    errorEmitter.emit(
      'permission-error',
      new FirestorePermissionError({
        path: path,
        operation: 'list',
      })
    );
    throw error;
  }
}
