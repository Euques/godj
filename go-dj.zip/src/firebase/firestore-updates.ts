'use client';
    
import {
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  CollectionReference,
  DocumentReference,
  SetOptions,
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import {FirestorePermissionError} from '@/firebase/errors';

/**
 * Performs a setDoc operation. It now returns a promise that resolves on completion.
 */
export async function setDocument(docRef: DocumentReference, data: any, options: SetOptions): Promise<void> {
  try {
    await setDoc(docRef, data, options);
  } catch (error) {
    errorEmitter.emit(
      'permission-error',
      new FirestorePermissionError({
        path: docRef.path,
        operation: options.merge ? 'update' : 'create',
        requestResourceData: data,
      })
    );
    throw error;
  }
}

/**
 * Performs an addDoc operation. It now returns a promise that resolves with the new DocumentReference.
 */
export async function addDocument(colRef: CollectionReference, data: any): Promise<DocumentReference> {
  try {
    const docRef = await addDoc(colRef, data);
    return docRef;
  } catch (error) {
    errorEmitter.emit(
      'permission-error',
      new FirestorePermissionError({
        path: colRef.path,
        operation: 'create',
        requestResourceData: data,
      })
    );
    throw error;
  }
}

/**
 * Performs an updateDoc operation. It now returns a promise that resolves on completion.
 */
export async function updateDocument(docRef: DocumentReference, data: any): Promise<void> {
  try {
    await updateDoc(docRef, data);
  } catch (error) {
    errorEmitter.emit(
      'permission-error',
      new FirestorePermissionError({
        path: docRef.path,
        operation: 'update',
        requestResourceData: data,
      })
    );
    throw error;
  }
}

/**
 * Performs a deleteDoc operation. It now returns a promise that resolves on completion.
 */
export async function deleteDocument(docRef: DocumentReference): Promise<void> {
  try {
    await deleteDoc(docRef);
  } catch (error) {
    errorEmitter.emit(
      'permission-error',
      new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      })
    );
    throw error;
  }
}
