'use server';

import { getAdminSdks } from '@/firebase/server';

interface GetSignedUrlProps {
    filePath: string;
    contentType: string;
}

interface SignedUrlResponse {
    uploadUrl: string;
    publicUrl: string;
}

// This function is kept for potential future server-side use, but is no longer
// used by the client-side ImageUploader component.
export async function getSignedUploadUrl({ filePath, contentType }: GetSignedUrlProps): Promise<SignedUrlResponse> {
    try {
        const { storage } = getAdminSdks();
        const bucket = storage.bucket();
        const file = bucket.file(filePath);

        // Define options for the signed URL
        const options = {
            version: 'v4' as const,
            action: 'write' as const,
            expires: Date.now() + 15 * 60 * 1000, // 15 minutes
            contentType,
        };

        // Generate the signed URL for uploading
        const [uploadUrl] = await file.getSignedUrl(options);

        return {
            uploadUrl,
            publicUrl: file.publicUrl(),
        };

    } catch (error: any) {
        console.error("Error generating signed URL: ", error);
        if (error.code === 403) {
            throw new Error(`Storage Permission Denied: ${error.message}. Ensure the service account has 'Storage Admin' or 'Storage Object Creator' role.`);
        }
        throw new Error(`Could not generate signed URL: ${error.message}`);
    }
}
