'use server';

import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import { getAdminApp } from '@/firebase/server';
import { revalidatePath } from 'next/cache';


// Initialize admin app
const adminApp = getAdminApp();
const adminAuth = getAuth(adminApp);
const adminFirestore = getFirestore(adminApp);
const adminStorage = getStorage(adminApp).bucket();

/**
 * Sets or removes the 'isSuperAdmin' custom claim for a given user.
 * @param uid The user ID (uid) to set the claim for.
 * @param isSuperAdmin Boolean indicating whether to add or remove the admin claim.
 */
export async function setAdminClaim(uid: string, isSuperAdmin: boolean) {
    if (!uid) {
        throw new Error("UID do usuário é obrigatório.");
    }
    try {
        await adminAuth.setCustomUserClaims(uid, { isSuperAdmin });
        // After setting a claim, we should revalidate any paths that might
        // depend on user roles, though often a client-side token refresh is more direct.
        console.log(`Custom claim 'isSuperAdmin: ${isSuperAdmin}' set for user ${uid}`);
        return { success: true, message: `Privilégio de admin ${isSuperAdmin ? 'concedido' : 'removido'} com sucesso.` };
    } catch (error: any) {
        console.error(`Falha ao definir custom claim para o usuário ${uid}:`, error);
        throw new Error(`Ocorreu um erro ao alterar os privilégios de admin: ${error.message}`);
    }
}

/**
 * Deletes a DJ and all their associated data from Firestore, Storage, and Auth.
 * This is a destructive and irreversible action.
 * @param djId The UID of the DJ to delete.
 */
export async function deleteDj(djId: string) {
    if (!djId) {
        throw new Error("ID do DJ é obrigatório para a exclusão.");
    }

    try {
        // 1. Delete Firestore data (profile and subcollections)
        const djDocRef = adminFirestore.collection('djProfiles').doc(djId);
        
        // Recursively delete subcollections (like 'agenda')
        await adminFirestore.recursiveDelete(djDocRef);
        
        // The recursiveDelete also deletes the document itself. If it fails or if you
        // want to be explicit, you could call: await djDocRef.delete();

        // 2. Delete Firebase Storage files
        const folderPath = `djs/${djId}/`;
        await adminStorage.deleteFiles({ prefix: folderPath });

        // 3. Delete user from Firebase Auth
        await adminAuth.deleteUser(djId);

        console.log(`DJ with UID ${djId} has been successfully deleted.`);
        return { success: true, message: `DJ ${djId} excluído com sucesso.` };

    } catch (error: any) {
        console.error(`Falha ao excluir DJ com UID ${djId}:`, error);

        // Provide more specific error messages
        if (error.code === 'auth/user-not-found') {
             throw new Error('Usuário não encontrado no Firebase Authentication. Os dados do Firestore e Storage podem ter sido removidos.');
        } else if (error.code === 'permission-denied') {
             throw new Error('Permissão negada. Verifique as credenciais do Admin SDK.');
        }

        throw new Error(`Ocorreu um erro ao excluir o DJ: ${error.message}`);
    }
}
