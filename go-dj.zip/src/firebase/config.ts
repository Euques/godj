export const firebaseConfig = {
  "projectId": "studio-5669116883-ca230",
  "appId": "1:473188531141:web:0f9bf4c1e60c75c00069ac",
  "apiKey": "AIzaSyCeAIIA6HCkGFnfuqszsLve9Gk2AWIsX6I",
  "authDomain": "studio-5669116883-ca230.firebaseapp.com",
  "storageBucket": "studio-5669116883-ca230.firebasestorage.app",
  "measurementId": "",
  "messagingSenderId": "473188531141"
};
