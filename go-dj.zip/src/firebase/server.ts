// NOTE: This is a server-only file. It is not intended to be used in client-side code.
import { getApps, initializeApp, App, cert } from 'firebase-admin/app';
import { getStorage } from 'firebase-admin/storage';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import fs from 'fs';
import path from 'path';

let adminApp: App | null = null;

/**
 * Localiza e lê o arquivo de chave do Firebase de forma simples e segura.
 */
export function getAdminApp(): App {
  if (adminApp) return adminApp;

  const existingApps = getApps();
  if (existingApps.length) {
    adminApp = existingApps[0];
    return adminApp;
  }
  
  const storageBucket = 'studio-5669116883-ca230.firebasestorage.app';

  try {
      // 1. Tenta carregar via variável de ambiente (JSON string)
      if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
          const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
          if (serviceAccount.private_key) {
              serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
          }
          adminApp = initializeApp({
            credential: cert(serviceAccount),
            storageBucket: storageBucket,
          });
          return adminApp;
      }

      // 2. Tenta carregar via arquivo local firebase-key.json na raiz do projeto (se existir)
      const filePath = path.join(process.cwd(), 'firebase-key.json');
      if (fs.existsSync(filePath)) {
          const fileContent = fs.readFileSync(filePath, 'utf8');
          const serviceAccount = JSON.parse(fileContent);
          
          if (serviceAccount.private_key) {
              serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
          }

          adminApp = initializeApp({
            credential: cert(serviceAccount),
            storageBucket: storageBucket,
          });
          return adminApp;
      }
  } catch (error) {
      console.warn("[Firebase Admin] Erro ao carregar credenciais customizadas:", error);
  }
  
  // Fallback padrão
  adminApp = initializeApp({ storageBucket });
  return adminApp;
}

export function getAdminSdks() {
  try {
      const app = getAdminApp();
      return {
        storage: getStorage(app),
        auth: getAuth(app),
        firestore: getFirestore(app)
      };
  } catch (e) {
      console.error("[Firebase Admin] Falha ao obter SDKs:", e);
      return { storage: null, auth: null, firestore: null };
  }
}
