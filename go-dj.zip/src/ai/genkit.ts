import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';

export const ai = genkit({
  plugins: [googleAI({ apiKey: process.env.GEMINI_API_KEY || process.env.GOOGLE_GENAI_API_KEY || 'placeholder' })],
  // Do not specify a model here for general flows like image processing.
  // Models should be specified in `ai.generate()` calls where needed.
});
