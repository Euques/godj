'use server';
import { config } from 'dotenv';
config();

// This file is used to export Genkit flows for development and inspection.
// It is not used in the production build.
// To run, use: `genkit start -- tsx src/ai/dev.ts`
