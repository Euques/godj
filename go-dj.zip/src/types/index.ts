'use client';
import type { Timestamp } from 'firebase/firestore';
import { z } from 'zod';


export interface DjProfile {
    id: string;
    slug: string;
    customDomain?: string;
    name: string;
    email: string | null;
    bio?: string;
    tags?: string[];
    location?: string;
    profilePictureUrl?: string;
    coverPhotoUrl?: string;
    socials?: {
        instagram?: string;
        facebook?: string;
        tiktok?: string;
        spotify?: string;
        soundcloud?: string;
        twitter?: string;
        youtube?: string;
    };
    whatsapp?: string;
    verified?: boolean;
    isSuperAdmin?: boolean;
    eventCount?: number;
    lastEventUpdate?: Timestamp | string;
    createdAt?: Timestamp | string;
    storeOpenByDefault?: boolean;
    agendaOpenByDefault?: boolean;
}

export interface Event {
    id: string;
    djProfileId: string;
    djName: string;
    djSlug: string;
    djProfilePictureUrl?: string;
    djIsVerified?: boolean;
    djEventCount?: number;
    title: string;
    date: Timestamp | string; // Allow string for serialized dates from server
    venue: string;
    city: string;
    description?: string;
    address?: string;
    flyerUrl?: string;
    url?: string;
    lastUpdatedAt?: Timestamp | string;
}

export interface Product {
    id: string;
    djProfileId: string;
    title: string;
    description?: string;
    price: number;
    imageUrl?: string;
    category?: string;
    inStock?: boolean;
    featured?: boolean;
    lastUpdatedAt?: Timestamp | string;
}

export const PixelCropSchema = z.object({
  x: z.number(),
  y: z.number(),
  width: z.number(),
  height: z.number(),
});
export type PixelCrop = z.infer<typeof PixelCropSchema>;


export const ProcessImageInputSchema = z.object({
  imageDataUri: z.string().describe("The source image as a data URI."),
  crop: PixelCropSchema.describe("The crop parameters for the image."),
  storagePath: z.string().describe("The base path in Firebase Storage to save the image."),
  fileName: z.string().describe("The name of the file to save in Storage."),
  cropEnabled: z.boolean().describe("Whether cropping should be applied."),
});
export type ProcessImageInput = z.infer<typeof ProcessImageInputSchema>;


export const ProcessImageOutputSchema = z.object({
  url: z.string().describe("The public URL of the uploaded image."),
});
export type ProcessImageOutput = z.infer<typeof ProcessImageOutputSchema>;
