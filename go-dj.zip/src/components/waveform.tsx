'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface WaveformProps {
  progress: number;
  color: string;
}

const WaveformPath = () => (
    <path d="M0 32.09 C 1.63 32.09, 3.26 15.68, 4.9 15.68 C 6.53 15.68, 8.16 48.23, 9.8 48.23 C 11.43 48.23, 13.06 2.01, 14.7 2.01 C 16.33 2.01, 17.96 46.51, 19.6 46.51 C 21.23 46.51, 22.86 10.66, 24.5 10.66 C 26.13 10.66, 27.76 49.33, 29.4 49.33 C 31.03 49.33, 32.66 23.95, 34.3 23.95 C 35.93 23.95, 37.56 52.88, 39.2 52.88 C 40.83 52.88, 42.46 32.36, 44.1 32.36 C 45.73 32.36, 47.36 57.38, 49 57.38 C 50.63 57.38, 52.26 31.81, 53.9 31.81 C 55.53 31.81, 57.16 61.99, 58.8 61.99 C 60.43 61.99, 62.06 32.09, 63.7 32.09 C 65.33 32.09, 66.96 42.55, 68.6 42.55 C 70.23 42.55, 71.86 16.9, 73.5 16.9 C 75.13 16.9, 76.76 41.53, 78.4 41.53 C 80.03 41.53, 81.66 25.43, 83.3 25.43 C 84.93 25.43, 86.56 58.62, 88.2 58.62 C 90.03 58.62, 91.86 32.09, 93.7 32.09 C 95.53 32.09, 97.36 40.86, 99.2 40.86 C 101.03 40.86, 102.86 28.53, 104.7 28.53 C 106.53 28.53, 108.36 51.27, 110.2 51.27 C 112.03 51.27, 113.86 32.09, 115.7 32.09 C 117.53 32.09, 119.36 63.98, 121.2 63.98 C 123.03 63.98, 124.86 4.96, 126.7 4.96 C 128.53 4.96, 130.36 45.5, 132.2 45.5 C 134.03 45.5, 135.86 21.23, 137.7 21.23 C 139.53 21.23, 141.36 54.32, 143.2 54.32 C 145.03 54.32, 146.86 29.76, 148.7 29.76 C 150.53 29.76, 152.36 59.94, 154.2 59.94 C 156.03 59.94, 157.86 32.09, 159.7 32.09" strokeWidth="2" fill="none" vectorEffect="non-scaling-stroke" />
);

export const Waveform: React.FC<WaveformProps> = ({ progress, color }) => {
  const uniqueId = React.useId();
  const clipPathId = `clip-path-${uniqueId}`;

  return (
    <div className="w-full h-full flex items-center justify-center">
      <svg viewBox="0 0 160 64" className="w-full h-full" preserveAspectRatio="none">
        <defs>
          <clipPath id={clipPathId}>
            <rect x="0" y="0" width={`${progress}%`} height="100%" />
          </clipPath>
        </defs>

        {/* Background Waveform */}
        <g className="stroke-current text-muted-foreground/30">
          <WaveformPath />
        </g>
        
        {/* Progress Waveform */}
        <g style={{ stroke: color }} clipPath={`url(#${clipPathId})`}>
          <WaveformPath />
        </g>
      </svg>
    </div>
  );
};
