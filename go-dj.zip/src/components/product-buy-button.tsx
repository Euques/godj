'use client';

import React from 'react';
import { Button } from '@/components/ui/button';

export function WhatsappIcon({ className = "w-5 h-5 shrink-0" }: { className?: string }) {
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.99c-.002 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c-.001 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
    </svg>
  );
}

export function ProductBuyButton({ 
  whatsapp, 
  djName, 
  productTitle, 
  formattedPrice 
}: { 
  whatsapp?: string; 
  djName: string; 
  productTitle: string; 
  formattedPrice: string; 
}) {
  const handleBuy = () => {
    if (!whatsapp) return;
    
    const message = `Olá ${djName}! Tenho interesse no produto: ${productTitle} (${formattedPrice}).`;
    let cleanNumber = whatsapp.replace(/\D/g, '');
    if ((cleanNumber.length === 10 || cleanNumber.length === 11) && !cleanNumber.startsWith('55')) {
      cleanNumber = `55${cleanNumber}`;
    }
    
    const waUrl = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
    window.open(waUrl, '_blank');
  };

  if (!whatsapp) {
    return (
      <Button disabled className="w-full h-12 text-sm font-medium rounded-full bg-zinc-800/80 text-muted-foreground border-0">
        Contato do DJ indisponível
      </Button>
    );
  }

  return (
    <Button 
      onClick={handleBuy} 
      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium h-12 rounded-full text-sm border-0 shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2"
    >
      <WhatsappIcon className="w-5 h-5 text-white shrink-0" />
      <span>Comprar via WhatsApp</span>
    </Button>
  );
}
