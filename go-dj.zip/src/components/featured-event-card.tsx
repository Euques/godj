
'use client';
import type { Event } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { ManagedImage } from "./managed-image";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { getSafeDate, formatDayOfWeek, generateSlug } from "@/lib/utils";
import { format, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, ShieldCheck, MapPin } from "lucide-react";
import { useMemo } from 'react';

export function FeaturedEventCard({ event }: { event: Event }) {
    const { eventDate, dateParts, isEventToday, isHappeningNow } = useMemo(() => {
        const date = getSafeDate(event.date);
        if (!date) {
            return { eventDate: null, dateParts: null, isEventToday: false, isHappeningNow: false };
        }
        
        const now = new Date();
        const today = isToday(date);
        const eventEndTime = new Date(date.getTime() + 6 * 60 * 60 * 1000);
        const happeningNow = now >= date && now <= eventEndTime;
        
        const parts = {
            dayOfWeek: formatDayOfWeek(date),
            day: format(date, 'dd'),
            month: format(date, 'MMM', { locale: ptBR }).toUpperCase(),
        };

        return { eventDate: date, dateParts: parts, isEventToday: today, isHappeningNow: happeningNow };
    }, [event.date]);

    const dayLabel = () => {
        if (!dateParts) return null;
        if (isHappeningNow) return 'AGORA';
        if (isEventToday) return 'HOJE';
        return dateParts.dayOfWeek;
    };

    return (
        <Link href={`/${event.djSlug}/evento/${generateSlug(event.title)}`} className="block group h-full">
            <Card className="overflow-hidden bg-card h-full flex flex-col">
                <div className="relative aspect-[4/3]">
                    <ManagedImage
                        src={event.flyerUrl || 'https://picsum.photos/seed/event-placeholder/600/800'}
                        alt={event.title || 'Flyer do evento'}
                        fill
                        className="object-cover object-top"
                        data-ai-hint="event flyer"
                    />
                     <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-card to-transparent" />
                     <div className="absolute bottom-4 left-4 text-white space-y-1">
                        <h3 className="text-xl font-bold drop-shadow-lg">{event.title}</h3>
                        <div className="flex items-center gap-1.5 text-sm drop-shadow-lg">
                            <span className="truncate uppercase">{event.venue}</span>
                        </div>
                     </div>
                </div>

                <CardContent className="p-4 flex-grow flex items-center">
                     <div className="flex items-center gap-4 h-full w-full">
                        {dateParts ? (
                            <div className="font-bold text-sm text-center text-white w-12 shrink-0 flex flex-col">
                                <span className={(isEventToday || isHappeningNow) ? "text-xs font-bold text-red-500" : "text-xs"}>
                                    {dayLabel()}
                                </span>
                                <span className="text-2xl text-white font-bold tracking-tight">{dateParts.day}</span>
                                <span className="text-xs">{dateParts.month}</span>
                            </div>
                        ) : (
                            <div className="flex items-center justify-center w-12 shrink-0">
                                <Calendar className="w-6 h-6 text-muted-foreground" />
                            </div>
                        )}
                        <div className="border-l border-zinc-700 pl-4 flex-1 min-w-0 flex items-center gap-3">
                                <Avatar className="h-12 w-12 border-2 border-zinc-700 shrink-0">
                                    <AvatarImage src={event.djProfilePictureUrl} data-ai-hint="dj portrait" />
                                    <AvatarFallback>{event.djName ? event.djName.substring(0, 2) : 'DJ'}</AvatarFallback>
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                     <div className="flex items-center gap-2">
                                        <span className="font-semibold text-white truncate">{event.djName}</span>
                                        {event.djIsVerified && <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0" />}
                                    </div>
                                    <div className="text-xs text-white flex items-center gap-1.5 mt-1">
                                        <MapPin className="w-3 h-3" />
                                        <span>{event.city}</span>
                                    </div>
                                </div>
                                {event.djEventCount !== undefined && event.djEventCount > 0 && (
                                    <div className="flex items-center gap-1.5 bg-red-600 text-white font-bold text-xs px-2 py-1 rounded-full shrink-0 ml-auto">
                                        <Calendar className="w-3 h-3" />
                                        <span>{event.djEventCount}</span>
                                    </div>
                                )}
                        </div>
                    </div>
                </CardContent>
            </Card>
        </Link>
    )
}
