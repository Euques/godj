
'use client';

import Link from 'next/link';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/ui/avatar';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth, useUser, useFirestore, useMemoFirebase, useDoc } from '@/firebase';
import { doc } from 'firebase/firestore';
import type { DjProfile } from '@/types';
import { LayoutDashboard, User as UserIcon, Calendar, LogOut, Loader2, ChevronDown, Menu, Eye, ShieldCheck, ShoppingBag } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';

const SUPER_ADMIN_EMAIL = "euques@gmail.com";

function UserNavContent() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const firestore = useFirestore();
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const djProfileRef = useMemoFirebase(() => {
    if (isUserLoading || !user || !firestore) return null;
    return doc(firestore, 'djProfiles', user.uid);
  }, [isUserLoading, user, firestore]);

  const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
  
  const isLoading = isUserLoading || isProfileLoading;

  useEffect(() => {
    if (user && !isUserLoading) {
      if (user.email === SUPER_ADMIN_EMAIL) {
        setIsSuperAdmin(true);
        return;
      }
      user.getIdTokenResult().then((idTokenResult) => {
        const isAdminClaim = !!idTokenResult.claims.isSuperAdmin;
        setIsSuperAdmin(isAdminClaim);
      });
    } else {
      setIsSuperAdmin(false);
    }
  }, [user, isUserLoading]);


  const handleLogout = () => {
    if(auth) {
        auth.signOut();
    }
  };

  if (isLoading) {
    return <Loader2 className="h-8 w-8 animate-spin" />;
  }

  if (!user) {
    return (
      <div className="flex items-center gap-2">
        <Link href="/eventos" className="md:hidden">
          <Button variant="ghost" size="sm" className="text-xs text-zinc-300 px-2.5 py-2 h-auto min-h-[40px]">
            Eventos
          </Button>
        </Link>
        <Link href="/djs" className="md:hidden">
          <Button variant="ghost" size="sm" className="text-xs text-zinc-300 px-2.5 py-2 h-auto min-h-[40px]">
            Deejays
          </Button>
        </Link>
        <Link href="/login">
          <Button variant="outline" size="sm" className="gap-2 px-3.5 py-2 min-h-[40px] border-zinc-800 text-xs sm:text-sm font-medium bg-zinc-900 hover:bg-zinc-800">
             <Menu className="h-4 w-4" />
             <span>Entrar</span>
          </Button>
        </Link>
      </div>
    );
  }
  
  const avatarUrl = djProfile?.profilePictureUrl;
  const avatarName = djProfile?.name;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="flex items-center gap-2.5 px-3 py-2 rounded-full h-auto min-h-[44px] focus-visible:ring-0 focus-visible:ring-offset-0 hover:bg-zinc-800/70 border border-zinc-800/80 bg-zinc-900/60">
          <Avatar className="h-8 w-8 border border-zinc-700/50 shrink-0">
            <AvatarImage src={avatarUrl} alt={avatarName || ''} />
            <AvatarFallback className="text-xs bg-zinc-800 text-zinc-200">{avatarName ? avatarName.substring(0, 2).toUpperCase() : 'DJ'}</AvatarFallback>
          </Avatar>
          <span className="text-xs sm:text-sm font-medium max-w-[100px] sm:max-w-[160px] truncate text-zinc-200">{avatarName || user.email}</span>
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0 ml-0.5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64 p-2 bg-zinc-950 border-zinc-800 text-white shadow-2xl rounded-xl" align="end" forceMount>
        <DropdownMenuLabel className="px-3 py-3 font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-semibold leading-none text-white">{avatarName || 'Usuário'}</p>
            <p className="text-xs leading-none text-zinc-400 truncate mt-1">
              {user.email}
            </p>
          </div>
        </DropdownMenuLabel>
        
        <DropdownMenuSeparator className="bg-zinc-800/80 my-1.5" />

        <DropdownMenuGroup className="space-y-1">
          <Link href="/eventos" className="md:hidden">
            <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
              <Calendar className="mr-3 h-4 w-4 text-red-400" />
              <span className="font-medium">Explorar Eventos</span>
            </DropdownMenuItem>
          </Link>
          <Link href="/djs" className="md:hidden">
            <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
              <UserIcon className="mr-3 h-4 w-4 text-red-400" />
              <span className="font-medium">Ver Deejays</span>
            </DropdownMenuItem>
          </Link>
          <DropdownMenuSeparator className="bg-zinc-800/80 my-1.5 md:hidden" />

          <Link href="/admin/painel-de-controle">
            <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
              <LayoutDashboard className="mr-3 h-4 w-4 text-zinc-400" />
              <span>Painel de Controle</span>
            </DropdownMenuItem>
          </Link>
          <Link href="/admin/agenda">
            <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
              <Calendar className="mr-3 h-4 w-4 text-zinc-400" />
              <span>Gerenciar Agenda</span>
            </DropdownMenuItem>
          </Link>
          <Link href="/admin/loja">
            <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
              <ShoppingBag className="mr-3 h-4 w-4 text-zinc-400" />
              <span>Minha Loja</span>
            </DropdownMenuItem>
          </Link>
          <Link href="/admin/profile">
            <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
              <UserIcon className="mr-3 h-4 w-4 text-zinc-400" />
              <span>Editar Perfil</span>
            </DropdownMenuItem>
          </Link>
          {djProfile?.slug && (
              <Link href={`/${djProfile.slug}`}>
                  <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
                      <Eye className="mr-3 h-4 w-4 text-zinc-400" />
                      <span>Visualizar perfil</span>
                  </DropdownMenuItem>
              </Link>
          )}
        </DropdownMenuGroup>
        
        {isSuperAdmin && (
            <>
                <DropdownMenuSeparator className="bg-zinc-800/80 my-1.5" />
                <DropdownMenuGroup className="space-y-1">
                    <DropdownMenuLabel className="px-3 py-1 text-xs text-zinc-500 font-semibold uppercase tracking-wider">Super Admin</DropdownMenuLabel>
                     <Link href="/super-admin/painel">
                        <DropdownMenuItem className="py-2.5 px-3 text-sm cursor-pointer hover:bg-zinc-800/80 focus:bg-zinc-800/80 rounded-lg min-h-[44px]">
                            <ShieldCheck className="mr-3 h-4 w-4 text-red-400" />
                            <span>Painel Super Admin</span>
                        </DropdownMenuItem>
                    </Link>
                </DropdownMenuGroup>
            </>
        )}

        <DropdownMenuSeparator className="bg-zinc-800/80 my-1.5" />

        <DropdownMenuItem onClick={handleLogout} className="py-2.5 px-3 text-sm cursor-pointer text-red-400 hover:text-red-300 hover:bg-red-950/40 focus:bg-red-950/40 focus:text-red-300 rounded-lg min-h-[44px]">
          <LogOut className="mr-3 h-4 w-4" />
          <span className="font-medium">Sair</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function UserNav() {
  return <UserNavContent />;
}
