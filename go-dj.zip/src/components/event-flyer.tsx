'use client';

import React, { useState } from 'react';
import { ManagedImage } from '@/components/managed-image';
import { Maximize2, Minimize2, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

interface EventFlyerProps {
  flyerUrl?: string;
  title: string;
}

export function EventFlyer({ flyerUrl, title }: EventFlyerProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!flyerUrl) {
    return (
      <div className="relative aspect-square w-full rounded-2xl overflow-hidden border border-zinc-800/80 bg-card/60 flex flex-col items-center justify-center p-6 text-center">
        <Calendar className="w-16 h-16 text-muted-foreground/40 mb-4" />
        <h2 className="text-xl font-bold text-white/90">{title}</h2>
      </div>
    );
  }

  return (
    <div className="w-full space-y-2">
      <div
        className={cn(
          "relative w-full rounded-2xl overflow-hidden border border-zinc-800/80 bg-black/90 shadow-2xl transition-all duration-300 flex items-center justify-center",
          isExpanded ? "max-h-none" : "max-h-[380px] sm:max-h-[460px] md:max-h-none"
        )}
      >
        <div className={cn("relative w-full flex justify-center items-center", isExpanded ? "" : "h-[380px] sm:h-[460px] md:h-auto")}>
          <ManagedImage
            src={flyerUrl}
            alt={title}
            width={800}
            height={1000}
            className="object-contain max-h-full md:max-h-none w-auto md:w-full h-auto mx-auto"
            wrapperClassName="w-full h-full md:h-auto flex items-center justify-center"
            priority
            unoptimized
          />
        </div>

        {!isExpanded && (
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black via-black/60 to-transparent pointer-events-none md:hidden" />
        )}

        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="absolute bottom-3 right-3 md:hidden bg-zinc-900/90 hover:bg-zinc-800 text-white p-2.5 rounded-full border border-zinc-700/80 shadow-lg transition-all active:scale-95 flex items-center gap-1.5 text-xs font-medium z-10"
          aria-label={isExpanded ? "Recolher flyer" : "Expandir flyer"}
        >
          {isExpanded ? (
            <>
              <Minimize2 className="w-4 h-4 text-white shrink-0" />
              <span>Recolher</span>
            </>
          ) : (
            <>
              <Maximize2 className="w-4 h-4 text-white shrink-0" />
              <span>Expandir</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
