'use client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { addDocument, setDocument, updateDocument, useStorage } from '@/firebase';
import { collection, doc, Timestamp, getDoc, Firestore, serverTimestamp } from 'firebase/firestore';
import type { User } from 'firebase/auth';
import type { DjProfile, Event } from '@/types';
import { useEffect, useState, useCallback } from 'react';
import { ImageUploader } from './image-uploader';
import { Loader2 } from 'lucide-react';
import { formatForInput, generateSlug } from '@/lib/utils';
import { ref as storageRef, uploadString, getDownloadURL } from 'firebase/storage';
import Image from 'next/image';

const eventFormSchema = z.object({
  title: z.string().min(3, 'O título é muito curto').max(50, 'O título é muito longo'),
  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: 'Data inválida',
  }),
  venue: z.string().min(3, 'O nome do local é muito curto'),
  city: z.string().min(3, 'O nome da cidade é muito curto'),
  address: z.string().optional().or(z.literal('')),
  description: z.string().max(500, 'A descrição é muito longa').optional().or(z.literal('')),
  url: z.string().url("URL do evento inválida").optional().or(z.literal('')),
});

type EventFormValues = z.infer<typeof eventFormSchema>;

interface EventFormProps {
  user: User;
  firestore: Firestore;
  djProfile: DjProfile;
  eventToEdit?: Event | null;
  onFinished?: () => void;
}

export function EventForm({ user, firestore, djProfile, eventToEdit, onFinished }: EventFormProps) {
  const { toast } = useToast();
  const storage = useStorage();
  const isEditing = !!eventToEdit;

  const [flyerUrl, setFlyerUrl] = useState(eventToEdit?.flyerUrl || '');
  
  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: '',
      date: '',
      venue: '',
      city: '',
      address: '',
      description: '',
      url: '',
    },
    mode: 'onChange',
  });

  useEffect(() => {
    if (eventToEdit) {
      form.reset({
        title: eventToEdit.title || '',
        date: eventToEdit.date ? formatForInput(eventToEdit.date) : '',
        venue: eventToEdit.venue || '',
        city: eventToEdit.city || '',
        address: eventToEdit.address || '',
        description: eventToEdit.description || '',
        url: eventToEdit.url || '',
      });
      setFlyerUrl(eventToEdit.flyerUrl || '');
    } else {
        form.reset({
          title: '',
          date: '',
          venue: '',
          city: '',
          address: '',
          description: '',
          url: '',
        });
        setFlyerUrl('');
    }
  }, [eventToEdit, form]);

 const handleFlyerUpload = useCallback((url: string | null) => {
    if (url) {
      setFlyerUrl(url);
    }
  }, []);

  async function onSubmit(data: EventFormValues) {
    if (!user || !firestore) return;
    
    const profileRef = doc(firestore, 'djProfiles', user.uid);
    const freshDjProfileSnap = await getDoc(profileRef);

    if (!freshDjProfileSnap.exists() || !freshDjProfileSnap.data()?.name) {
        toast({
            variant: 'destructive',
            title: 'Perfil incompleto',
            description: 'Seu perfil precisa ter um nome antes de criar eventos.',
        });
        return;
    }

    const freshDjProfile = freshDjProfileSnap.data() as DjProfile;
    const slug = freshDjProfile.slug || generateSlug(freshDjProfile.name);
    let finalFlyerUrl = flyerUrl;

    try {
       // Only upload if flyerUrl is a new data URI
      if (flyerUrl && flyerUrl.startsWith('data:image')) {
        if (!storage) throw new Error("Serviço de Storage não está disponível.");
        const eventId = eventToEdit?.id || doc(collection(firestore, 'dummy')).id;
        const filePath = `djs/${djProfile.id}/events/${eventId}/flyer.webp`;
        const fileRef = storageRef(storage, filePath);
        
        await uploadString(fileRef, flyerUrl, 'data_url');
        finalFlyerUrl = await getDownloadURL(fileRef);
      }

      const eventData: Omit<Event, 'id'> = {
          title: data.title || '',
          date: Timestamp.fromDate(new Date(data.date)),
          venue: data.venue || '',
          city: data.city || '',
          address: data.address || '',
          description: data.description || '',
          flyerUrl: finalFlyerUrl || '',
          url: data.url || '',
          djProfileId: user.uid,
          djName: freshDjProfile.name,
          djSlug: slug,
          djProfilePictureUrl: freshDjProfile.profilePictureUrl,
          lastUpdatedAt: serverTimestamp(),
      };

      if (isEditing && eventToEdit?.id) {
          const eventRef = doc(firestore, 'djProfiles', user.uid, 'agenda', eventToEdit.id);
          await setDocument(eventRef, eventData, { merge: true });
          toast({
            title: 'Evento Atualizado!',
            description: 'As informações do evento foram salvas.',
          });
      } else {
          const agendaCollectionRef = collection(firestore, 'djProfiles', user.uid, 'agenda');
          const newDocRef = await addDocument(agendaCollectionRef, eventData);
          toast({
            title: 'Evento Criado!',
            description: 'Seu evento foi adicionado à agenda.',
          });
      }

      // Update lastEventUpdate on DJ Profile
      await updateDocument(profileRef, { lastEventUpdate: serverTimestamp() });
      
      form.reset();
      setFlyerUrl('');
      onFinished?.();
    } catch(e) {
        console.error(e);
        toast({
            variant: 'destructive',
            title: 'Falha ao salvar',
            description: 'Não foi possível salvar os detalhes do evento. Tente novamente.',
        });
    }
  }

  if (!djProfile?.id) {
      return (
        <div className="flex items-center justify-center p-8 rounded-lg bg-card border border-border">
            <Loader2 className="animate-spin w-6 h-6 mr-3 text-muted-foreground" />
            <span className="text-muted-foreground">Carregando dados do perfil...</span>
        </div>
      );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Título do Evento</FormLabel>
              <FormControl>
                <Input placeholder="Sunset Party" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="date"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Data e Hora</FormLabel>
              <FormControl>
                <Input type="datetime-local" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="venue"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nome do Local</FormLabel>
              <FormControl>
                <Input placeholder="Ex: Club A" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="city"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Cidade</FormLabel>
              <FormControl>
                <Input placeholder="Ex: São Paulo" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Endereço do Evento (Opcional)</FormLabel>
              <FormControl>
                <Input placeholder="Av. Principal, 123, Bairro" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
       
        <div className="bg-zinc-900/50 p-4 rounded-lg space-y-4">
            <FormItem>
                <FormLabel>Flyer do Evento (Opcional)</FormLabel>
                 {flyerUrl && (
                    <div className="mt-4 mb-4 relative w-full aspect-[1/1] max-w-sm mx-auto rounded-md overflow-hidden bg-muted">
                        <Image 
                            src={flyerUrl} 
                            alt="Preview do Flyer" 
                            layout="fill" 
                            objectFit="contain" 
                        />
                    </div>
                )}
                <FormControl>
                    <ImageUploader 
                        onUploadComplete={handleFlyerUpload} 
                        cropEnabled={false}
                        initialImageUrl={flyerUrl}
                    />
                </FormControl>
                 <FormDescription>
                    O flyer será enviado sem recorte.
                </FormDescription>
            </FormItem>
        </div>
        
        <FormField
          control={form.control}
          name="url"
          render={({ field }) => (
            <FormItem>
              <FormLabel>URL do Evento (Opcional)</FormLabel>
              <FormControl>
                <Input placeholder="https://example.com/evento" {...field} />
              </FormControl>
              <FormDescription>Link para ingressos, mais informações, etc.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descrição (Opcional)</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Descreva o evento, line-up, etc."
                  className="resize-none"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" disabled={form.formState.isSubmitting}>
            {(form.formState.isSubmitting) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEditing ? "Salvar Alterações" : "Adicionar Evento"}
        </Button>
      </form>
    </Form>
  );
}
