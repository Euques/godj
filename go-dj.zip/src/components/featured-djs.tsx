'use client';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { DjProfile } from '@/types';
import { Loader2, MapPin, Calendar, ShieldCheck } from 'lucide-react';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { ManagedImage } from './managed-image';
import { useDjs } from '@/hooks/use-djs';
import { getSafeDate } from '@/lib/utils';
import { useMemo } from 'react';
import { Skeleton } from './ui/skeleton';

function DjCardSkeleton() {
    return (
      <div className="flex flex-col space-y-3 h-full">
        <div className="relative">
            <Skeleton className="h-auto w-full aspect-[2/1] rounded-t-lg" />
            <div className="absolute inset-x-0 -bottom-16 flex justify-center">
                <Skeleton className="h-32 w-32 rounded-full border-4 border-card" />
            </div>
        </div>
        <div className="space-y-2 text-center flex flex-col items-center pt-20 flex-grow p-4">
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
        </div>
      </div>
    );
}

function FeaturedDjCard({ dj }: { dj: DjProfile }) {
    const eventCount = dj.eventCount || 0;
    return (
        <Link href={`/${dj.slug}`} className="block group">
            <Card className="overflow-hidden bg-card h-full">
                <div className="relative aspect-[2/1]">
                    <ManagedImage
                        src={dj.coverPhotoUrl || 'https://picsum.photos/seed/placeholder-lg/800/800'}
                        alt={dj.name || 'Capa do DJ'}
                        fill
                        className="object-cover object-top"
                        data-ai-hint="dj banner"
                    />
                     <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
                    <div className="absolute top-3 left-3 flex items-center gap-2">
                        {eventCount > 0 && (
                            <div className="flex items-center gap-1.5 bg-red-600/90 backdrop-blur-sm text-white font-bold text-xs px-2 py-1 rounded-full">
                                <Calendar className="w-4 h-4" />
                                <span>{eventCount}</span>
                            </div>
                        )}
                        {dj.verified && (
                            <div className="flex items-center justify-center bg-blue-500/80 backdrop-blur-sm text-white font-bold text-xs p-1.5 rounded-full">
                                <ShieldCheck className="w-4 h-4" />
                            </div>
                        )}
                    </div>
                    <div className="absolute inset-x-0 -bottom-16 flex justify-center">
                        <Avatar className="h-32 w-32 border-4 border-card shadow-lg transition-transform duration-300 group-hover:scale-110">
                            <AvatarImage src={dj.profilePictureUrl} data-ai-hint="dj portrait" />
                            <AvatarFallback>{dj.name ? dj.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                        </Avatar>
                    </div>
                </div>
                <CardContent className="p-4 pt-20 text-center">
                    <h3 className="text-2xl font-bold truncate text-white">{dj.name || 'DJ sem nome'}</h3>
                    {dj.location && (
                        <div className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground mt-1">
                            <MapPin className="w-4 h-4" />
                            <span className="truncate">{dj.location}</span>
                        </div>
                    )}
                    {dj.tags && dj.tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-4 h-6 justify-center overflow-hidden">
                            {dj.tags.slice(0, 3).map((tag) => (
                                <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </Link>
    );
}


function FeaturedDjsContent() {
    const { djs, isLoading } = useDjs();
    
    const featuredDjs = useMemo(() => {
        if (!djs) return [];
        // Filter for DJs who have updated their events, sort them by the most recent update, and take the top 6.
        return djs
            .filter(dj => dj.lastEventUpdate)
            .sort((a, b) => {
                const timeA = getSafeDate(a.lastEventUpdate)?.getTime() || 0;
                const timeB = getSafeDate(b.lastEventUpdate)?.getTime() || 0;
                return timeB - timeA; // Sort descending
            })
            .slice(0, 6);
    }, [djs]);
    
    return (
        <div className="space-y-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-white tracking-wider font-headline">DJs em Destaque</h2>
                <p className="text-md text-muted-foreground mt-1">
                    Conheça os artistas que estão agitando a cena.
                </p>
            </div>

            {isLoading && (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <DjCardSkeleton />
                    <DjCardSkeleton />
                    <DjCardSkeleton />
                </div>
            )}
            {!isLoading && featuredDjs.length === 0 && (
                <p className="text-muted-foreground text-center py-10">Nenhum DJ em destaque no momento.</p>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {!isLoading && featuredDjs.map((dj) => (dj && <FeaturedDjCard key={dj.id} dj={dj} />))}
            </div>
        </div>
    );
}


export function FeaturedDjs() {
    return <FeaturedDjsContent />
}