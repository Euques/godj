
'use client';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { DjProfile } from '@/types';
import { Loader2, MapPin, Calendar, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { Separator } from './ui/separator';
import { useDjs } from '@/hooks/use-djs';

function OtherDjItem({ dj }: { dj: DjProfile }) {
    const eventCount = dj.eventCount || 0;
    return (
        <Card className="bg-card hover:bg-zinc-800/50">
            <Link href={`/perfil/${dj.slug}`} className="block group p-3">
                <div className="flex items-center gap-4">
                    <Avatar className="h-14 w-14 border-2 border-zinc-700">
                        <AvatarImage src={dj.profilePictureUrl} data-ai-hint="dj portrait" />
                        <AvatarFallback>{dj.name ? dj.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                            {dj.verified && <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0" />}
                            <h4 className="font-bold truncate text-white">{dj.name || 'DJ sem nome'}</h4>
                        </div>
                        {dj.location && (
                            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                                <MapPin className="w-3 h-3" />
                                <span className="truncate">{dj.location}</span>
                            </div>
                        )}
                    </div>
                    {eventCount > 0 && (
                        <div className="flex items-center gap-1.5 bg-red-600 text-white font-bold text-xs px-2 py-1 rounded-full shrink-0">
                            <Calendar className="w-4 h-4" />
                            <span>{eventCount}</span>
                        </div>
                    )}
                </div>
            </Link>
        </Card>
    )
}


function OtherDjsContent() {
    const { djs, isLoading } = useDjs();
    const activeDjs = (djs || []).filter(dj => dj.lastEventUpdate);
    const inactiveDjs = (djs || []).filter(dj => !dj.lastEventUpdate);
    
    // Skip the first 6 active djs, as they are in the featured section
    const otherDjs = [...activeDjs.slice(6), ...inactiveDjs];
    
    if (isLoading || otherDjs.length === 0) {
        return null;
    }
    
    return (
        <div className="space-y-4 pt-8">
            <div className="flex items-center gap-4">
                <Separator className="flex-1 bg-zinc-700" />
                <h3 className="text-center font-semibold text-muted-foreground tracking-widest text-sm">OUTROS DJS NA PLATAFORMA</h3>
                    <Separator className="flex-1 bg-zinc-700" />
            </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {otherDjs.map(dj => (
                    dj && <OtherDjItem key={dj.id} dj={dj} />
                ))}
            </div>
        </div>
    );
}


export function OtherDjs() {
    return <OtherDjsContent />;
}
