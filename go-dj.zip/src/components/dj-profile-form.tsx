'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { setDocument } from '@/firebase';
import { collection, doc, getDocs, query, where, type Firestore, serverTimestamp } from 'firebase/firestore';
import type { DjProfile } from '@/types';
import { useRouter } from 'next/navigation';
import { Loader2, CheckCircle2, Globe, Share2, Youtube, Instagram, Facebook, Music2, Twitter } from 'lucide-react';
import { ImageUploader } from './image-uploader';
import type { User } from 'firebase/auth';
import { generateSlug, cn } from '@/lib/utils';
import { useDebounceEffect } from '@/components/useDebounceEffect';
import Image from 'next/image';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const SUPER_ADMIN_EMAIL = "euques@gmail.com";

const normalizeDomain = (domain: string) => {
    if (!domain) return '';
    return domain
        .toLowerCase()
        .replace(/^(https?:\/\/)?(www\.)?/, '')
        .replace(/\/$/, '')
        .trim();
};

const createProfileFormSchema = (firestore: Firestore, userId: string, isEditing: boolean) => z.object({
  name: z.string().min(2, { message: 'O nome deve ter pelo menos 2 caracteres.' }).max(50),
  slug: z.string().min(3, "O slug deve ter pelo menos 3 caracteres.").refine(async (slug) => {
        if (!slug) return true;
        const sanitizedSlug = generateSlug(slug);
        const q = query(collection(firestore, 'djProfiles'), where('slug', '==', sanitizedSlug));
        const snapshot = await getDocs(q);
        return snapshot.empty || (isEditing && snapshot.docs[0].id === userId);
    }, 'Este endereço já está em uso.'),
  customDomain: z.string().optional().or(z.literal('')),
  bio: z.string().max(500, "Biografia muito longa.").optional().or(z.literal('')),
  tags: z.string().optional().or(z.literal('')),
  location: z.string().min(1, 'A cidade é obrigatória.'),
  whatsapp: z.string().min(10, 'Número inválido (mínimo 10 dígitos)').regex(/^\d+$/, 'Apenas números.'),
  instagram: z.string().url("URL inválida").optional().or(z.literal('')),
  facebook: z.string().url("URL inválida").optional().or(z.literal('')),
  tiktok: z.string().url("URL inválida").optional().or(z.literal('')),
  spotify: z.string().url("URL inválida").optional().or(z.literal('')),
  soundcloud: z.string().url("URL inválida").optional().or(z.literal('')),
  twitter: z.string().url("URL inválida").optional().or(z.literal('')),
  youtube: z.string().url("URL inválida").optional().or(z.literal('')),
});

type ProfileFormValues = z.infer<ReturnType<typeof createProfileFormSchema>>;

interface DjProfileFormProps {
    user: User;
    currentUser?: User;
    firestore: Firestore;
    djProfile: DjProfile | null;
    isEditing?: boolean;
    onImageUpload?: (imageDataUri: string | null, imageType: 'profile' | 'cover') => Promise<string | null>;
}

export function DjProfileForm({ user, currentUser, djProfile, firestore, isEditing = false, onImageUpload }: DjProfileFormProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [isSlugManuallyEdited, setIsSlugManuallyEdited] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  
  const schema = useMemo(() => createProfileFormSchema(firestore, user.uid, isEditing), [firestore, user.uid, isEditing]);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '', slug: '', customDomain: '', bio: '', tags: '', location: '', whatsapp: '',
      instagram: '', facebook: '', tiktok: '', spotify: '', soundcloud: '', twitter: '', youtube: '',
    },
    mode: 'onSubmit',
  });

  useEffect(() => {
    const viewer = currentUser || user;
    if (viewer) {
      if (viewer.email === SUPER_ADMIN_EMAIL) setIsSuperAdmin(true);
      else viewer.getIdTokenResult().then(res => setIsSuperAdmin(!!res.claims.isSuperAdmin));
    }
  }, [currentUser, user]);

  useEffect(() => {
    if (djProfile) {
      form.reset({
        name: djProfile.name || '',
        slug: djProfile.slug || '',
        customDomain: djProfile.customDomain || '',
        bio: djProfile.bio || '',
        tags: djProfile.tags?.join(', ') || '',
        location: djProfile.location || '',
        whatsapp: djProfile.whatsapp || '',
        instagram: djProfile.socials?.instagram || '',
        facebook: djProfile.socials?.facebook || '',
        tiktok: djProfile.socials?.tiktok || '',
        spotify: djProfile.socials?.spotify || '',
        soundcloud: djProfile.socials?.soundcloud || '',
        twitter: djProfile.socials?.twitter || '',
        youtube: djProfile.socials?.youtube || '',
      });
      setIsSlugManuallyEdited(!!djProfile.slug);
    }
  }, [djProfile, form]);
  
  const nameValue = form.watch('name');
  useDebounceEffect(() => {
    if (!isSlugManuallyEdited && nameValue) {
        form.setValue('slug', generateSlug(nameValue), { shouldValidate: true });
    }
  }, 500, [nameValue, isSlugManuallyEdited]);

  const onSubmit = async (data: ProfileFormValues) => {
    try {
        const profileRef = doc(firestore, 'djProfiles', user.uid);
        const tagsArray = (data.tags || '').split(',').map(tag => tag.trim()).filter(Boolean);
        const finalSlug = generateSlug(data.slug);

        const profileData: Partial<DjProfile> = {
            name: data.name,
            slug: finalSlug,
            customDomain: normalizeDomain(data.customDomain || ''),
            bio: data.bio || '',
            location: data.location || '',
            tags: tagsArray,
            whatsapp: data.whatsapp,
            socials: {
                instagram: data.instagram || '',
                facebook: data.facebook || '',
                tiktok: data.tiktok || '',
                spotify: data.spotify || '',
                soundcloud: data.soundcloud || '',
                twitter: data.twitter || '',
                youtube: data.youtube || '',
            },
            updatedAt: serverTimestamp(),
        };

        if (!isEditing) {
            Object.assign(profileData, {
                id: user.uid,
                email: user.email,
                profilePictureUrl: `https://avatar.vercel.sh/${finalSlug}.png`,
                coverPhotoUrl: `https://picsum.photos/seed/${finalSlug}/1200/400`,
                createdAt: serverTimestamp(),
                verified: false,
                isSuperAdmin: false,
            });
        }

        await setDocument(profileRef, profileData, { merge: true });
        toast({ title: isEditing ? 'Perfil Atualizado!' : 'Perfil Criado!' });
        if (!isEditing) router.push('/admin/painel-de-controle');
    } catch(e: any) {
        toast({ variant: 'destructive', title: 'Erro ao salvar', description: e.message });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 text-left">
        
        <div className="grid gap-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome Artístico</FormLabel>
                <FormControl><Input placeholder="DJ Sparkle" {...field} className="bg-input border-zinc-800" /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <FormField
            control={form.control}
            name="slug"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL do Perfil (Slug)</FormLabel>
                <FormControl>
                    <div className={cn(
                        "flex h-10 w-full items-center rounded-md border border-zinc-800 bg-input px-3 ring-offset-background focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2",
                    )}>
                        <span className="text-muted-foreground mr-1 text-sm">godj.com.br/</span>
                        <Input 
                            {...field}
                            onChange={(e) => { setIsSlugManuallyEdited(true); field.onChange(e.target.value.replace(/\s/g, '-').toLowerCase()); }}
                           className="flex-1 border-none bg-transparent p-0 shadow-none ring-0 focus-visible:ring-0 text-sm"
                        />
                         {form.formState.isValidating ? <Loader2 className="h-4 w-4 animate-spin" /> : (!form.formState.errors.slug && field.value && <CheckCircle2 className="h-4 w-4 text-green-500" />)}
                    </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          {isSuperAdmin && (
            <FormField
              control={form.control}
              name="customDomain"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2"><Globe className="w-4 h-4" /> Domínio Personalizado</FormLabel>
                  <FormControl><Input placeholder="meusite.com.br" {...field} className="bg-input border-zinc-800" onBlur={(e) => field.onChange(normalizeDomain(e.target.value))} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
        </div>

        <div className="space-y-4 rounded-lg border border-zinc-800 bg-card p-4">
            <FormLabel>Imagens do Perfil</FormLabel>
            <div className="relative w-full aspect-[2/1] rounded-md overflow-hidden bg-muted flex items-center justify-center">
                 {djProfile?.coverPhotoUrl && <Image src={djProfile.coverPhotoUrl} alt="Capa" fill className="object-cover" />}
                 <div className="absolute bottom-2 right-2 z-10">
                     {onImageUpload && <ImageUploader onUploadComplete={(url) => onImageUpload(url, 'cover')} aspect={2} />}
                 </div>
            </div>
            <div className="flex justify-center -mt-20">
                <div className="relative group w-40 h-40">
                    <Avatar className="h-40 w-40 border-4 border-white/50 shadow-lg">
                        <AvatarImage src={djProfile?.profilePictureUrl} className="object-cover" />
                        <AvatarFallback>{form.watch('name')?.substring(0, 2) || 'DJ'}</AvatarFallback>
                    </Avatar>
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full">
                         {onImageUpload && <ImageUploader onUploadComplete={(url) => onImageUpload(url, 'profile')} aspect={1} circularCrop />}
                    </div>
                </div>
            </div>
        </div>

        <div className="grid gap-6">
            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bio (Opcional)</FormLabel>
                  <FormControl><Textarea placeholder="Sobre sua trajetória..." rows={5} {...field} className="bg-input border-zinc-800" /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cidade</FormLabel>
                      <FormControl><Input placeholder="Ex: São Paulo, SP" {...field} className="bg-input border-zinc-800" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="tags"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gêneros / Tags</FormLabel>
                      <FormControl><Input placeholder="Ex: Techno, House" {...field} className="bg-input border-zinc-800" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
            </div>
            
            <FormField
              control={form.control}
              name="whatsapp"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-bold text-white flex items-center gap-1">
                    WhatsApp para Contato <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl><Input placeholder="DDD + Número" {...field} className="bg-input border-zinc-800 focus-visible:ring-primary shadow-none" /></FormControl>
                  <FormDescription className="text-xs">Obrigatório para contatos e funcionamento da loja.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Accordion type="single" collapsible className="bg-zinc-900/30 rounded-lg border border-zinc-800 overflow-hidden">
              <AccordionItem value="socials" className="border-none">
                <AccordionTrigger className="p-4 hover:no-underline">
                  <div className="flex items-center gap-3 text-left">
                    <Share2 className="w-5 h-5 text-primary" />
                    <div>
                      <span className="font-bold text-md tracking-tight uppercase">Redes Sociais</span>
                      <p className="text-[10px] text-muted-foreground uppercase font-medium">Instagram, TikTok, YouTube e outros.</p>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-6 space-y-4 pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { name: 'instagram', label: 'Instagram', icon: <Instagram className="w-3 h-3"/> },
                      { name: 'tiktok', label: 'TikTok', icon: <Music2 className="w-3 h-3"/> },
                      { name: 'youtube', label: 'YouTube', icon: <Youtube className="w-3 h-3"/> },
                      { name: 'spotify', label: 'Spotify', icon: <Music2 className="w-3 h-3"/> },
                      { name: 'soundcloud', label: 'SoundCloud', icon: <Music2 className="w-3 h-3"/> },
                      { name: 'facebook', label: 'Facebook', icon: <Facebook className="w-3 h-3"/> },
                      { name: 'twitter', label: 'Twitter/X', icon: <Twitter className="w-3 h-3"/> }
                    ].map((social) => (
                      <FormField
                        key={social.name}
                        control={form.control}
                        name={social.name as any}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center gap-2 text-xs">{social.icon} {social.label}</FormLabel>
                            <FormControl><Input placeholder="https://..." {...field} className="bg-input border-zinc-800 h-9 text-xs" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
        </div>

        <Button type="submit" className="w-full" size="lg" disabled={form.formState.isSubmitting}>
            {form.formState.isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : (isEditing ? 'Salvar Alterações' : 'Criar Perfil')}
        </Button>
      </form>
    </Form>
  );
}
