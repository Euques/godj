
'use client';
import { useEffect, DependencyList } from 'react'

export function useDebounceEffect(
  fn: () => void,
  waitTime: number,
  deps: DependencyList,
) {
  useEffect(() => {
    const t = setTimeout(() => {
      // This is a workaround for a bug in React's types.
      // The deps array is not properly typed for apply.
      // See: https://github.com/facebook/react/issues/14082
      fn()
    }, waitTime)

    return () => {
      clearTimeout(t)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}
