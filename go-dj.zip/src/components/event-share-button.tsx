'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Share2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function EventShareButton({ 
  title, 
  djName, 
  eventUrl,
  variant = 'secondary', 
  className 
}: { 
  title: string; 
  djName?: string; 
  eventUrl?: string;
  variant?: 'secondary' | 'outline' | 'default' | 'ghost'; 
  className?: string 
}) {
  const { toast } = useToast();

  const handleShare = async () => {
    const fullUrl = eventUrl && typeof window !== 'undefined'
      ? (eventUrl.startsWith('http') ? eventUrl : `${window.location.origin}${eventUrl}`)
      : (typeof window !== 'undefined' ? window.location.href : '');

    const shareData = {
      title: `${title}${djName ? ` - Dj ${djName}` : ''}`,
      text: `Confira o evento ${title}${djName ? ` com Dj ${djName}` : ''} no GoDJ!`,
      url: fullUrl,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err) {
        // User cancelled or not allowed
      }
    }

    try {
      await navigator.clipboard.writeText(fullUrl);
      toast({
        title: "Link copiado!",
        description: "O link do evento foi copiado para a área de transferência.",
      });
    } catch (e) {
      toast({
        variant: "destructive",
        title: "Erro ao compartilhar",
        description: "Não foi possível copiar o link.",
      });
    }
  };

  return (
    <Button variant={variant} onClick={handleShare} className={className}>
      <Share2 className="mr-2 h-5 w-5 shrink-0" /> Enviar para um amigo
    </Button>
  );
}
