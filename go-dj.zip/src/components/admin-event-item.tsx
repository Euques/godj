'use client';
import type { Event } from "@/types";
import { getSafeDate } from "@/lib/utils";
import { format, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, MapPin, Edit, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { ManagedImage } from "./managed-image";

interface AdminEventItemProps {
    event: Event;
    onEdit: (event: Event) => void;
    onDelete: (eventId: string) => void;
}

export function AdminEventItem({ event, onEdit, onDelete }: AdminEventItemProps) {
    if (!event) return null;
    
    const eventDate = getSafeDate(event.date);
    const now = new Date();
    const isEventToday = eventDate ? isToday(eventDate) : false;

    const eventEndTime = eventDate ? new Date(eventDate.getTime() + 6 * 60 * 60 * 1000) : null;
    const isHappeningNow = eventDate && now >= eventDate && now <= eventEndTime;
    
    const formattedDate = eventDate ? format(eventDate, "dd/MM/yy 'às' HH:mm", { locale: ptBR }) : 'Data inválida';

    const getDateLabel = () => {
        if (isHappeningNow) {
            return `AGORA - ${formattedDate}`;
        }
        if (isEventToday) {
            return `HOJE - ${formattedDate}`;
        }
        return formattedDate;
    };


    return (
        <div className="flex items-start gap-3 p-3 rounded-lg bg-zinc-800/50 transition-colors">
            {event.flyerUrl ? (
                <ManagedImage
                    src={event.flyerUrl}
                    alt={`Flyer do evento ${event.title}`}
                    fill
                    className="object-cover"
                    wrapperClassName="relative h-16 w-16 shrink-0 rounded-md overflow-hidden"
                />
            ) : (
                <div className="h-16 w-16 shrink-0 rounded-md bg-zinc-700/50 flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-muted-foreground" />
                </div>
            )}
            
            <div className="flex-1 flex flex-col sm:flex-row sm:items-start sm:justify-between min-w-0">
                <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-md truncate">{event.title || 'Evento sem título'}</h3>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                        <MapPin className="w-4 h-4 shrink-0" />
                        <span className="truncate">{event.venue || 'Local não informado'}, {event.city || 'cidade não informada'}</span>
                    </div>
                     <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                        <Calendar className="w-4 h-4 shrink-0" />
                        <span className={(isEventToday || isHappeningNow) ? 'font-bold text-red-500' : ''}>
                           {getDateLabel()}
                        </span>
                    </div>
                </div>

                <div className="flex items-center justify-end w-full sm:w-auto mt-2 sm:mt-0 sm:ml-2">
                     <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0 h-8 px-2" disabled={!event.id}>
                                Excluir
                            </Button>
                        </AlertDialogTrigger>
                         <AlertDialogContent>
                            <AlertDialogHeader>
                            <AlertDialogTitle>Você tem certeza que deseja excluir {`"${event.title}"`}?</AlertDialogTitle>
                            <AlertDialogDescription>
                                Essa ação não pode ser desfeita. Isso excluirá permanentemente o evento da sua agenda.
                            </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => onDelete(event.id!)}>Excluir</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                    <Button variant="ghost" size="sm" onClick={() => onEdit(event)} className="text-muted-foreground hover:text-white hover:bg-white/10 h-8 px-2">
                        <Edit className="w-4 h-4 mr-1" /> Editar
                    </Button>
                </div>
            </div>
        </div>
    )
}
