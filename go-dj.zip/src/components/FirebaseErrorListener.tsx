'use client';

/**
 * Disabled error listener as requested.
 */
export function FirebaseErrorListener() {
  return null;
}

