'use client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/firebase';
import {
  type AuthError,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
} from 'firebase/auth';
import { Separator } from './ui/separator';
import Link from 'next/link';
import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { useRouter } from 'next/navigation';

const formSchema = z.object({
  email: z.string().email({ message: 'Endereço de e-mail inválido.' }),
  password: z
    .string()
    .min(6, { message: 'A senha deve ter pelo menos 6 caracteres.' }),
});

function GoogleIcon(props: React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 48 48"
        width="24px"
        height="24px"
      >
        <path
          fill="#FFC107"
          d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12s5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24s8.955,20,20,20s20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"
        />
        <path
          fill="#FF3D00"
          d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"
        />
        <path
          fill="#4CAF50"
          d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.222,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"
        />
        <path
          fill="#1976D2"
          d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.574l6.19,5.238C39.99,34.551,44,28.717,44,20C44,22.659,43.862,21.35,43.611,20.083z"
        />
      </svg>
    );
}

interface AuthFormProps {
  authType: 'login' | 'signup';
}

export function AuthForm({ authType }: AuthFormProps) {
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);


  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const handleAuthError = (error: AuthError) => {
    console.warn('Falha de autenticação capturada:', error);
    let description = 'Ocorreu um erro inesperado. Verifique os dados digitados.';
    if (error.code === 'auth/email-already-in-use') {
        description = 'Este e-mail já está em uso. Tente fazer login.';
    } else if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        description = 'E-mail ou senha incorretos.';
    } else if (error.code === 'auth/invalid-email') {
        description = 'Endereço de e-mail inválido.';
    } else if (error.code === 'auth/popup-closed-by-user') {
        description = 'A janela de login do Google foi fechada.';
    }
    toast({
      variant: 'destructive',
      title: 'Falha na autenticação',
      description: description,
    });
  };

  const handleSignUp = async (values: z.infer<typeof formSchema>) => {
    try {
      await createUserWithEmailAndPassword(auth, values.email, values.password);
      toast({
        title: 'Cadastro realizado com sucesso',
        description: "Você será redirecionado para criar seu perfil.",
      });
      router.push('/admin/profile');
    } catch (error) {
      handleAuthError(error as AuthError);
    }
  };

  const handleSignIn = async (values: z.infer<typeof formSchema>) => {
    try {
      await signInWithEmailAndPassword(auth, values.email, values.password);
      toast({
        title: 'Login realizado com sucesso',
        description: "Bem-vindo(a) de volta!",
      });
      router.push('/admin/painel-de-controle');
    } catch (error) {
      handleAuthError(error as AuthError);
    }
  };
  
  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      toast({
        title: 'Login com Google realizado com sucesso!',
        description: 'Bem-vindo(a)!',
      });
       router.push('/admin/painel-de-controle');
    } catch (error) {
      handleAuthError(error as AuthError);
    }
  };

  const isLogin = authType === 'login';

  return (
    <div className="mt-6">
       <Button variant="outline" className="w-full bg-white text-black hover:bg-neutral-200 hover:text-black" onClick={handleGoogleSignIn}>
            <GoogleIcon className="mr-2 h-4 w-4" />
            Continuar com Google
        </Button>

        <div className="my-4 flex items-center">
            <div className="flex-grow border-t border-muted" />
            <span className="mx-4 text-xs text-muted-foreground">OU</span>
            <div className="flex-grow border-t border-muted" />
        </div>

        <Form {...form}>
            <form onSubmit={form.handleSubmit(isLogin ? handleSignIn : handleSignUp)} className="space-y-4 pt-4">
                <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                            <Input placeholder="dj@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                        <FormItem>
                          <FormLabel>Senha</FormLabel>
                          <div className="relative">
                            <FormControl>
                                <Input type={showPassword ? 'text' : 'password'} placeholder="••••••••" {...field} />
                            </FormControl>
                            <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="absolute inset-y-0 right-0 h-full w-10 text-muted-foreground hover:bg-transparent"
                                onClick={() => setShowPassword((prev) => !prev)}
                            >
                                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </Button>
                          </div>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <Button type="submit" className="w-full">{isLogin ? 'Entrar' : 'Criar Conta'}</Button>
            </form>
        </Form>
        <div className="mt-6 space-y-4">
            <div className="flex items-center">
                <div className="flex-grow border-t border-muted" />
                <span className="mx-4 text-xs font-semibold text-muted-foreground">OU</span>
                <div className="flex-grow border-t border-muted" />
            </div>

            {isLogin ? (
                <Link href="/signup" className="block w-full">
                    <Button variant="secondary" className="w-full font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700/80">
                        Cadastre-se
                    </Button>
                </Link>
            ) : (
                <Link href="/login" className="block w-full">
                    <Button variant="secondary" className="w-full font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700/80">
                        Já tenho conta (Entrar)
                    </Button>
                </Link>
            )}
        </div>
    </div>
  );
}
