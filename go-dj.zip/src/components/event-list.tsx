'use client';

// This component is deprecated and caused errors.
// Returning null to ensure it doesn't break any part of the app.
export function EventList() {
  return null;
}
