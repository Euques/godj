'use client';

import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { UploadCloud, RotateCw, Crop, Check, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Label } from './ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import ReactCrop, { type Crop as CropType, centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

interface ImageUploaderProps {
    onUploadComplete: (url: string | null) => void;
    initialImageUrl?: string;
    aspect?: number;
    circularCrop?: boolean;
    cropEnabled?: boolean;
    className?: string;
}

const MIN_DIMENSION = 150;

export function ImageUploader({
    onUploadComplete,
    initialImageUrl = '',
    aspect = 1,
    circularCrop = false,
    cropEnabled = true,
    className,
}: ImageUploaderProps) {
    const fileInputId = React.useRef(`file-input-${Math.random().toString(36).substring(2, 9)}`).current;
    const { toast } = useToast();
    const imgRef = useRef<HTMLImageElement | null>(null);
    
    const [imgSrc, setImgSrc] = useState('');
    const [crop, setCrop] = useState<CropType>();
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    // Use a separate state for preview to handle updates from props
    const [imagePreview, setImagePreview] = useState(initialImageUrl);
    React.useEffect(() => {
        setImagePreview(initialImageUrl);
    }, [initialImageUrl]);


    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            toast({
                variant: 'destructive',
                title: 'Arquivo muito grande',
                description: 'Por favor, selecione uma imagem com menos de 5MB.',
            });
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            const dataUrl = reader.result?.toString() || '';
            setImgSrc(dataUrl);
            if(cropEnabled) {
                setIsModalOpen(true);
            } else {
                onUploadComplete(dataUrl);
                 toast({
                    title: 'Imagem Adicionada',
                    description: 'A nova imagem foi selecionada.',
                });
            }
        };
        reader.readAsDataURL(file);
        e.target.value = ''; // Reset input
    };

    const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
        const { width, height } = e.currentTarget;
        const cropWidthInPercent = (MIN_DIMENSION / width) * 100;
        
        const newCrop = makeAspectCrop(
            { unit: 'px', width: MIN_DIMENSION },
            aspect,
            width,
            height
        );
        const centeredCrop = centerCrop(newCrop, width, height);
        setCrop(centeredCrop);
    };
    
    const getCroppedImg = (): Promise<string | null> => {
        const image = imgRef.current;
        if (!image || !crop || !crop.width || !crop.height) {
            return Promise.resolve(null);
        }

        const canvas = document.createElement('canvas');
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        
        const cropX = crop.x * scaleX;
        const cropY = crop.y * scaleY;

        const cropWidth = crop.width * scaleX;
        const cropHeight = crop.height * scaleY;
        
        canvas.width = cropWidth;
        canvas.height = cropHeight;

        const ctx = canvas.getContext('2d');
        if (!ctx) return Promise.resolve(null);

        ctx.drawImage(
            image,
            cropX,
            cropY,
            cropWidth,
            cropHeight,
            0,
            0,
            cropWidth,
            cropHeight
        );
        
        return new Promise((resolve) => {
            resolve(canvas.toDataURL('image/webp', 0.9));
        });
    };

    const handleCropConfirm = async () => {
        const croppedDataUrl = await getCroppedImg();
        if (croppedDataUrl) {
            onUploadComplete(croppedDataUrl);
            setImagePreview(croppedDataUrl); // Update preview immediately
            toast({
                title: 'Imagem Atualizada',
                description: 'A nova imagem foi recortada e salva.',
            });
        } else {
             toast({
                variant: 'destructive',
                title: 'Falha no Recorte',
                description: 'Não foi possível recortar a imagem. Tente novamente.',
            });
        }
        setIsModalOpen(false);
        setImgSrc('');
    };
    
    const hasImage = !!imagePreview;

    return (
        <div className={cn("w-full", className)}>
            <input
                type="file"
                id={fileInputId}
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileSelect}
                className="hidden"
            />

            <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
                <DialogContent className="max-w-md">
                    <DialogHeader>
                        <DialogTitle>Recortar Imagem</DialogTitle>
                    </DialogHeader>
                    {imgSrc && (
                        <div className="flex justify-center my-4">
                        <ReactCrop
                            crop={crop}
                            onChange={(pixelCrop, percentCrop) => setCrop(pixelCrop)}
                            circularCrop={circularCrop}
                            keepSelection
                            aspect={aspect}
                            minWidth={MIN_DIMENSION}
                        >
                            <img
                                ref={imgRef}
                                src={imgSrc}
                                alt="Recortar"
                                style={{ maxHeight: '70vh' }}
                                onLoad={onImageLoad}
                            />
                        </ReactCrop>
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsModalOpen(false)}><X className="mr-2"/>Cancelar</Button>
                        <Button onClick={handleCropConfirm}><Check className="mr-2"/>Confirmar</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

             <Button asChild className="w-full cursor-pointer" variant={hasImage ? 'secondary' : 'default'}>
                 <Label htmlFor={fileInputId} className="cursor-pointer">
                    {hasImage ? <RotateCw/> : <UploadCloud />}
                    {hasImage ? "Alterar Imagem" : "Enviar Imagem"}
                </Label>
            </Button>
        </div>
    );
}
