import React from 'react';
import Image from 'next/image';

export function Footer() {
  return (
    <footer className="py-8 text-center flex flex-col items-center justify-center gap-4 mt-auto">
      <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
      <a 
        href="https://wabes.com.br" 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
      >
        © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
      </a>
    </footer>
  );
}
