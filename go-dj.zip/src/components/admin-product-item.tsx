'use client';
import type { Product } from "@/types";
import { Edit, Trash2, ShoppingBag, Loader2, Star } from "lucide-react";
import { Button } from "./ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { ManagedImage } from "./managed-image";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { useState } from "react";
import { doc } from "firebase/firestore";
import { useFirestore, updateDocument } from "@/firebase";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "./ui/badge";
import { cn } from "@/lib/utils";

interface AdminProductItemProps {
    product: Product;
    onEdit: (product: Product) => void;
    onDelete: (productId: string) => void;
}

export function AdminProductItem({ product, onEdit, onDelete }: AdminProductItemProps) {
    const firestore = useFirestore();
    const { toast } = useToast();
    const [isUpdating, setIsUpdating] = useState(false);
    const formattedPrice = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price);

    const handleUpdate = async (field: 'inStock' | 'featured', value: boolean) => {
        if (!firestore || !product.djProfileId) return;
        setIsUpdating(true);
        try {
            const productRef = doc(firestore, 'djProfiles', product.djProfileId, 'products', product.id);
            await updateDocument(productRef, { [field]: value });
            toast({
                title: "Produto atualizado",
                description: `${product.title} atualizado com sucesso.`
            });
        } catch (e) {
            toast({
                variant: 'destructive',
                title: "Erro ao atualizar",
                description: "Tente novamente."
            });
        } finally {
            setIsUpdating(false);
        }
    }

    return (
        <div className={cn(
            "flex flex-col gap-4 p-4 rounded-lg bg-zinc-800/50 border transition-all",
            product.featured ? "border-yellow-500/30" : "border-zinc-700/50"
        )}>
            <div className="flex items-center gap-4">
                <div className="relative h-20 w-20 shrink-0 rounded-md overflow-hidden bg-zinc-700/50">
                    {product.imageUrl ? (
                        <ManagedImage
                            src={product.imageUrl}
                            alt={product.title}
                            fill
                            className="object-cover"
                        />
                    ) : (
                        <div className="h-full w-full flex items-center justify-center">
                            <ShoppingBag className="w-6 h-6 text-muted-foreground" />
                        </div>
                    )}
                    {product.featured && (
                        <div className="absolute top-1 right-1 bg-yellow-500 text-black p-0.5 rounded-sm shadow-lg">
                            <Star className="w-3 h-3 fill-current" />
                        </div>
                    )}
                </div>
                
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                        <h3 className="font-bold text-md truncate">{product.title}</h3>
                        {product.category && (
                            <Badge variant="outline" className="text-[10px] h-4 px-1 opacity-60 uppercase">{product.category}</Badge>
                        )}
                    </div>
                    <p className="text-primary text-lg">{formattedPrice}</p>
                </div>

                <div className="flex flex-col gap-2">
                    <Button variant="ghost" size="icon" onClick={() => onEdit(product)} className="text-muted-foreground hover:text-white">
                        <Edit className="w-4 h-4" />
                    </Button>
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                                <Trash2 className="w-4 h-4" />
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Excluir "{product.title}"?</AlertDialogTitle>
                                <AlertDialogDescription>Essa ação não pode ser desfeita.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => onDelete(product.id)}>Excluir</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-zinc-700/50 gap-4">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <Switch 
                            id={`stock-${product.id}`}
                            checked={product.inStock !== false}
                            onCheckedChange={(v) => handleUpdate('inStock', v)}
                            disabled={isUpdating}
                        />
                        <Label htmlFor={`stock-${product.id}`} className="text-[10px] uppercase font-bold cursor-pointer opacity-70">
                            Disponível
                        </Label>
                    </div>
                    <div className="flex items-center gap-2">
                         <Switch 
                            id={`featured-${product.id}`}
                            checked={!!product.featured}
                            onCheckedChange={(v) => handleUpdate('featured', v)}
                            disabled={isUpdating}
                        />
                        <Label htmlFor={`featured-${product.id}`} className="text-[10px] uppercase font-bold cursor-pointer opacity-70">
                            Destaque
                        </Label>
                    </div>
                </div>
                {isUpdating && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />}
            </div>
        </div>
    )
}
