
'use client';
import type { Event } from "@/types";
import { Card } from "@/components/ui/card";
import Link from "next/link";
import { getSafeDate, formatDayOfWeek, generateSlug } from "@/lib/utils";
import { format, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, ShieldCheck, MapPin } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { useMemo } from 'react';

export function SimpleEventCard({ event }: { event: Event }) {
    const { eventDate, dateParts, isEventToday, isHappeningNow } = useMemo(() => {
        const date = getSafeDate(event.date);
        if (!date) {
            return { eventDate: null, dateParts: null, isEventToday: false, isHappeningNow: false };
        }
        
        const now = new Date();
        const today = isToday(date);
        const eventEndTime = new Date(date.getTime() + 6 * 60 * 60 * 1000);
        const happeningNow = now >= date && now <= eventEndTime;
        
        const parts = {
            dayOfWeek: formatDayOfWeek(date),
            day: format(date, 'dd'),
            month: format(date, 'MMM', { locale: ptBR }).toUpperCase(),
        };

        return { eventDate: date, dateParts: parts, isEventToday: today, isHappeningNow: happeningNow };
    }, [event.date]);

    const dayLabel = () => {
        if (!dateParts) return null;
        if (isHappeningNow) return 'AGORA';
        if (isEventToday) return 'HOJE';
        return dateParts.dayOfWeek;
    };

    return (
        <Link href={`/${event.djSlug}/evento/${generateSlug(event.title)}`} className="block group h-full">
            <Card className="bg-card hover:bg-zinc-800/50 transition-colors h-full">
                 <div className="p-4 flex items-center gap-4 h-full">
                    {dateParts ? (
                        <div className="font-bold text-sm text-center text-muted-foreground w-12 shrink-0 flex flex-col">
                            <span className={(isEventToday || isHappeningNow) ? "text-xs font-bold text-red-500" : "text-xs"}>
                                {dayLabel()}
                            </span>
                            <span className="text-2xl text-white font-bold tracking-tight">{dateParts.day}</span>
                            <span className="text-xs">{dateParts.month}</span>
                        </div>
                    ) : (
                        <div className="flex items-center justify-center w-12 shrink-0">
                            <Calendar className="w-6 h-6 text-muted-foreground" />
                        </div>
                    )}
                     <div className="border-l border-zinc-700 pl-4 flex-1 min-w-0 flex flex-col h-full">
                        <h3 className="font-bold truncate text-white">{event.title}</h3>
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground mt-1">
                            <MapPin className="w-4 h-4 shrink-0" />
                            <span className="truncate">{event.venue}, {event.city}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2 pt-1 flex-grow items-end">
                            <div className="flex items-center gap-2 hover:underline">
                                <Avatar className="h-6 w-6">
                                    <AvatarImage src={event.djProfilePictureUrl} data-ai-hint="dj portrait" />
                                    <AvatarFallback>{event.djName ? event.djName.substring(0, 2) : 'DJ'}</AvatarFallback>
                                </Avatar>
                                <span className="font-semibold text-white">{event.djIsVerified && <ShieldCheck className="w-3 h-3 text-blue-500 inline-block mr-1" />} {event.djName}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </Card>
        </Link>
    )
}
