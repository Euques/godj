'use client';

import { useState } from 'react';
import Image, { type ImageProps } from 'next/image';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

type ManagedImageProps = ImageProps & {
  wrapperClassName?: string;
  onLoadingStateChange?: (isLoading: boolean) => void;
};

export function ManagedImage({ wrapperClassName, className, onLoadingStateChange, ...props }: ManagedImageProps) {
  const [isLoading, setIsLoading] = useState(true);
  
  const handleLoadingComplete = () => {
    setIsLoading(false);
    if (onLoadingStateChange) {
      onLoadingStateChange(false);
    }
  };

  // If fill is used, the wrapper is necessary for layout, but Image doesn't need w/h
  if (props.fill) {
    return (
      <div className={cn("relative h-full w-full", wrapperClassName)}>
        <Image
          className={cn(className)}
          onLoad={handleLoadingComplete}
          onError={handleLoadingComplete}
          {...props}
        />
      </div>
    );
  }

  // If width/height are used, apply w-full and h-auto to ensure responsiveness.
  return (
    <Image
      className={cn("w-full h-auto", className, wrapperClassName)}
      onLoad={handleLoadingComplete}
      onError={handleLoadingComplete}
      {...props}
    />
  );
}
