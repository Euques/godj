'use client';

import React, { useMemo } from 'react';
import { collection, query, where, limit, orderBy, or } from 'firebase/firestore';
import type { DjProfile, Event, Product } from '@/types';
import { Header } from '@/components/header';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { MapPin, ShieldCheck, Loader2, Youtube } from 'lucide-react';
import { AboutSection } from '@/components/dj/about-section';
import { EventSection } from '@/components/dj/event-section';
import { ProductSection } from '@/components/dj/product-section';
import { Card, CardContent } from '@/components/ui/card';
import { ManagedImage } from '@/components/managed-image';
import { getSafeDate } from '@/lib/utils';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { Footer } from '@/components/footer';
import Image from 'next/image';

interface DjProfilePageClientProps {
  slug: string;
}

export default function DjProfilePageClient({ slug }: DjProfilePageClientProps) {
  const firestore = useFirestore();

  const profileQuery = useMemoFirebase(() => {
    if (!firestore || !slug) return null;
    const normalizedIdentifier = slug
        .toLowerCase()
        .trim()
        .replace(/^\/+|\/+$/g, '')
        .replace(/^www\./, '');

    return query(
      collection(firestore, 'djProfiles'), 
      or(
        where('slug', '==', normalizedIdentifier), 
        where('customDomain', '==', normalizedIdentifier)
      ), 
      limit(1)
    );
  }, [firestore, slug]);

  const { data: profileResults, isLoading: isProfileLoading } = useCollection<DjProfile>(profileQuery);
  const djProfile = profileResults?.[0] || null;

  const eventsQuery = useMemoFirebase(() => {
    if (!firestore || !djProfile?.id) return null;
    return query(collection(firestore, `djProfiles/${djProfile.id}/agenda`), orderBy('date', 'asc'));
  }, [firestore, djProfile?.id]);

  const { data: allEvents } = useCollection<Event>(eventsQuery);

  const futureEvents = useMemo(() => {
    if (!allEvents) return [];
    const now = new Date();
    return allEvents.filter(event => {
        const eventDate = getSafeDate(event.date);
        if (!eventDate) return false;
        const eventEndTime = new Date(eventDate.getTime() + 6 * 60 * 60 * 1000);
        return eventEndTime >= now;
    });
  }, [allEvents]);

  const productsQuery = useMemoFirebase(() => {
    if (!firestore || !djProfile?.id) return null;
    return query(collection(firestore, `djProfiles/${djProfile.id}/products`), orderBy('lastUpdatedAt', 'desc'));
  }, [firestore, djProfile?.id]);

  const { data: products } = useCollection<Product>(productsQuery);

  if (isProfileLoading) {
    return (
        <div className="flex flex-col min-h-screen bg-background">
            <Header />
            <div className="flex-1 flex flex-col justify-center items-center">
                <Loader2 className="w-12 h-12 animate-spin text-primary" />
                <p className="mt-4 text-muted-foreground animate-pulse font-medium">Sintonizando frequências...</p>
            </div>
        </div>
    );
  }

  if (!djProfile) {
    return (
        <div className="flex flex-col min-h-screen bg-background">
            <Header />
            <div className="flex-1" />
        </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <Header />
      <main className="flex-1 container mx-auto p-4 lg:p-6">
        <Card className="bg-card overflow-hidden rounded-lg border-none shadow-none">
            <div className="relative h-40 sm:h-56 w-full">
                <ManagedImage
                    src={djProfile.coverPhotoUrl || 'https://picsum.photos/seed/placeholder/1200/400'}
                    alt={`Foto de capa de ${djProfile.name || 'DJ'}`}
                    fill
                    className="object-cover object-top"
                    data-ai-hint="dj banner"
                    priority
                />
                {/* Degradê restaurado igual ao dos flyers para o design */}
                <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-card to-transparent" />
                
                <div className="absolute inset-x-0 -bottom-20 flex justify-center">
                    <Avatar className="h-40 w-40 border-4 border-white/50 shadow-lg">
                        <AvatarImage src={djProfile.profilePictureUrl} data-ai-hint="dj portrait" className="object-cover" />
                        <AvatarFallback>{djProfile.name ? djProfile.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                    </Avatar>
                </div>
            </div>
            
            <CardContent className="text-center space-y-3 pt-24">
                <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center justify-center gap-2">
                    {djProfile.verified && (
                        <ShieldCheck className="w-7 h-7 text-blue-500" />
                    )}
                    {djProfile.name || 'DJ sem nome'}
                </h1>
                {djProfile.location && (
                    <p className="text-md sm:text-lg text-muted-foreground font-medium flex items-center justify-center gap-2">
                        <MapPin className="w-4 h-4" /> {djProfile.location}
                    </p>
                )}
                <div className="flex justify-center items-center gap-6 text-white pt-3">
                    {djProfile.socials?.instagram && (
                        <a href={djProfile.socials.instagram} target="_blank" rel="noopener noreferrer" className="text-white hover:text-primary transition-colors">
                            <svg className="h-8 w-8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                        </a>
                    )}
                    {djProfile.socials?.tiktok && (
                        <a href={djProfile.socials.tiktok} target="_blank" rel="noopener noreferrer" className="text-white hover:text-primary transition-colors">
                            <svg className="h-8 w-8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 449.45 515.38"><path fillRule="nonzero" d="M382.31 103.3c-27.76-18.1-47.79-47.07-54.04-80.82-1.35-7.29-2.1-14.8-2.1-22.48h-88.6l-.15 355.09c-1.48 39.77-34.21 71.68-74.33 71.68-12.47 0-24.21-3.11-34.55-8.56-23.71-12.47-39.94-37.32-39.94-65.91 0-41.07 33.42-74.49 74.48-74.49 7.67 0 15.02 1.27 21.97 3.44V190.8c-7.2-.99-14.51-1.59-21.97-1.59C73.16 189.21 0 262.36 0 352.3c0 55.17 27.56 104 69.63 133.52 26.48 18.61 58.71 29.56 93.46 29.56 89.93 0 163.08-73.16 163.08-163.08V172.23c34.75 24.94 77.33 39.64 123.28 39.64v-88.61c-24.75 0-47.8-7.35-67.14-19.96z"/></svg>
                        </a>
                    )}
                    {djProfile.socials?.youtube && (
                        <a href={djProfile.socials.youtube} target="_blank" rel="noopener noreferrer" className="text-white hover:text-primary transition-colors">
                            <Youtube className="h-8 w-8" />
                        </a>
                    )}
                    {djProfile.socials?.spotify && (
                        <a href={djProfile.socials.spotify} target="_blank" rel="noopener noreferrer" className="text-white hover:text-primary transition-colors flex items-center justify-center">
                            <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.521 17.34c-.22.359-.685.474-1.044.254-2.857-1.746-6.453-2.141-10.687-1.175-.411.094-.821-.161-.915-.572-.094-.411.161-.822.572-.915 4.632-1.059 8.601-.613 11.821 1.356.359.22.474.685.253 1.052zm1.472-3.272c-.277.45-.87.594-1.32.318-3.267-2.008-8.248-2.591-12.112-1.418-.507.153-1.042-.138-1.195-.645-.153-.507.138-1.042.645-1.195 4.414-1.34 9.914-.694 13.664 1.62.45.277.594.87.318 1.32zm.126-3.41c-3.918-2.327-10.373-2.541-14.116-1.404-.6.182-1.233-.157-1.415-.757-.182-.6.157-1.233.757-1.415 4.298-1.305 11.423-1.052 15.918 1.616.54.321.72 1.022.399 1.562-.321.54-1.022.72-1.543.398z"/>
                            </svg>
                        </a>
                    )}
                    {djProfile.socials?.soundcloud && (
                        <a href={djProfile.socials.soundcloud} target="_blank" rel="noopener noreferrer" className="text-white hover:text-primary transition-colors">
                            <svg className="h-8 w-8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-14.333 15.524c-.405-.365-.667-.903-.667-1.512 0-.608.262-1.146.667-1.512v3.024zm1.333.476c-.243 0-.369.003-.667-.092v-3.792c.316-.101.465-.097.667-.081v3.965zm1.333 0h-.666v-3.778l.206.121c.091-.375.253-.718.461-1.023v4.68zm1.334 0h-.667v-5.378c.206-.154.426-.286.667-.377v5.755zm1.333 0h-.667v-5.905c.251-.027.328-.046.667-.006v5.899zm1.333 0h-.667v-5.7l.253.123c.119-.207.261-.395.414-.572v6.149zm6.727 0h-6.06v-6.748c.532-.366 1.16-.585 1.842-.585 1.809 0 3.275 1.494 3.41 3.386 1.303-.638 2.748.387 2.748 1.876 0 1.143-.869 2.071-1.94 2.071z"/></svg>
                        </a>
                    )}
                </div>
            </CardContent>
        </Card>

        <div className="space-y-6 mt-8">
            {futureEvents.length > 0 && (
                <section>
                    <EventSection events={futureEvents} djProfile={djProfile} />
                </section>
            )}
            
            <section>
                <ProductSection products={products || []} djProfile={djProfile} />
            </section>

            <section>
                <AboutSection djProfile={djProfile} />
            </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}
