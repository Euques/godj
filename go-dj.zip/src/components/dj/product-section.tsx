'use client';

import React, { useMemo, useState, useEffect } from 'react';
import { ShoppingBag, ChevronDown, ExternalLink, Plus } from 'lucide-react';
import { WhatsappIcon } from '@/components/product-buy-button';
import { ProductShareButton } from '@/components/product-share-button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import type { Product, DjProfile } from '@/types';
import { ManagedImage } from '../managed-image';
import { cn, generateSlug } from '@/lib/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import Link from 'next/link';

function PublicProductItem({ product, djProfile }: { product: Product, djProfile: DjProfile }) {
    const formattedPrice = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price);
    const djSlug = djProfile?.slug || djProfile?.customDomain || (typeof window !== 'undefined' ? window.location.pathname.split('/')[1] : 'dj');
    const productSlug = generateSlug(product.title);
    const productUrl = `/${djSlug}/produto/${productSlug}`;

    const handleBuy = (e?: React.MouseEvent) => {
        if (e) e.stopPropagation();
        if (!djProfile.whatsapp) return;
        
        const message = `Olá ${djProfile.name}! Tenho interesse no produto: ${product.title} (${formattedPrice}).`;
        let cleanNumber = djProfile.whatsapp.replace(/\D/g, '');
        if ((cleanNumber.length === 10 || cleanNumber.length === 11) && !cleanNumber.startsWith('55')) {
            cleanNumber = `55${cleanNumber}`;
        }
        
        const waUrl = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
        window.open(waUrl, '_blank');
    };

    return (
        <>
            {/* Desktop / Tablet View - Direct Link to Product Page */}
            <div className="hidden md:block h-full">
                <Link href={productUrl} className="block h-full group">
                    <div className="bg-card hover:bg-zinc-800/80 border border-zinc-800/60 rounded-xl p-4 transition-all duration-300 h-full flex flex-col justify-between group-hover:border-zinc-700 shadow-md">
                        <div className="flex gap-4 items-start">
                            <div className="relative h-20 w-20 shrink-0 rounded-lg overflow-hidden border border-zinc-800 bg-zinc-900 flex items-center justify-center">
                                {product.imageUrl ? (
                                    <ManagedImage
                                        src={product.imageUrl}
                                        alt={product.title}
                                        fill
                                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                                    />
                                ) : (
                                    <ShoppingBag className="w-8 h-8 text-muted-foreground/50" />
                                )}
                            </div>

                            <div className="flex-1 min-w-0">
                                <div className="mb-1">
                                    <h3 className="font-medium text-sm sm:text-base text-white group-hover:text-primary transition-colors line-clamp-2 leading-snug">{product.title}</h3>
                                </div>
                                {product.description && (
                                    <p className="text-zinc-400 text-xs line-clamp-2 mb-2 leading-snug">
                                        {product.description}
                                    </p>
                                )}
                                <p className="text-primary font-bold text-sm sm:text-base">{formattedPrice}</p>
                            </div>
                        </div>

                        <div className="mt-4 pt-3 border-t border-zinc-800/60 flex items-center justify-between text-xs font-semibold text-zinc-400 group-hover:text-white transition-colors">
                            <span>Ver Detalhes do Produto</span>
                            <ExternalLink className="w-3.5 h-3.5 text-primary" />
                        </div>
                    </div>
                </Link>
            </div>

            {/* Mobile View - Accordion */}
            <div className="block md:hidden h-full">
                <Accordion type="single" collapsible className={cn(
                    "w-full rounded-xl border overflow-hidden transition-all duration-300 h-full",
                    "bg-card border-zinc-800/50"
                )}>
                    <AccordionItem value={product.id} className="border-none">
                        <AccordionTrigger className="p-4 hover:no-underline group [&>svg]:hidden">
                            <div className="flex items-center gap-4 w-full text-left">
                                <div className="relative h-16 w-16 shrink-0 rounded-sm overflow-hidden border border-zinc-800 bg-zinc-900 flex items-center justify-center group-data-[state=open]:opacity-0 transition-opacity duration-300">
                                    {product.imageUrl ? (
                                        <ManagedImage
                                            src={product.imageUrl}
                                            alt={product.title}
                                            fill
                                            className="object-cover"
                                        />
                                    ) : (
                                        <ShoppingBag className="w-6 h-6 text-muted-foreground/50" />
                                    )}
                                </div>

                                <div className="flex-1 min-w-0 group-data-[state=open]:-ml-20 transition-all duration-300">
                                    <div>
                                        <h3 className="font-medium text-sm sm:text-base line-clamp-2 text-white leading-snug">{product.title}</h3>
                                    </div>
                                    <p className="text-primary text-[11px] sm:text-xs mt-0.5 font-bold uppercase tracking-wider opacity-90">{formattedPrice}</p>
                                </div>

                                <div className="flex flex-col items-end gap-2 shrink-0">
                                    <ChevronDown className="h-4 w-4 text-white/60 transition-transform duration-300 group-data-[state=open]:rotate-180" />
                                </div>
                            </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-4 pb-6">
                            <div className="flex flex-col gap-6">
                                {product.imageUrl && (
                                    <div className="relative w-full aspect-square max-w-[400px] mx-auto rounded-md overflow-hidden border border-zinc-800 shadow-2xl">
                                        <ManagedImage 
                                            src={product.imageUrl} 
                                            alt={product.title} 
                                            fill 
                                            className="object-cover" 
                                        />
                                    </div>
                                )}
                                
                                <div className="space-y-4">
                                    {product.description && (
                                        <div className="bg-black/20 p-4 rounded-lg border border-zinc-800/50">
                                            <h4 className="text-xs font-bold text-white/60 uppercase tracking-widest mb-2">Descrição</h4>
                                            <p className="text-white/80 text-sm whitespace-pre-line leading-relaxed font-medium">
                                                {product.description}
                                            </p>
                                        </div>
                                    )}
                                    
                                    <div className="flex flex-col gap-3">
                                        <div className="flex justify-between items-center px-1">
                                            <span className="text-muted-foreground text-sm font-semibold">Valor do investimento</span>
                                            <span className="text-white text-2xl font-medium">{formattedPrice}</span>
                                        </div>
                                        <Button 
                                            onClick={handleBuy} 
                                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium h-12 rounded-full text-sm border-0 shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2"
                                        >
                                            <WhatsappIcon className="w-5 h-5 text-white shrink-0" />
                                            <span>Comprar via WhatsApp</span>
                                        </Button>
                                        <ProductShareButton 
                                            title={product.title} 
                                            djName={djProfile.name} 
                                            className="w-full h-12 text-sm font-medium bg-zinc-800 hover:bg-zinc-700 text-white transition-all rounded-full border-0 shadow-none" 
                                        />
                                    </div>
                                </div>
                            </div>
                        </AccordionContent>
                    </AccordionItem>
                </Accordion>
            </div>
        </>
    );
}

export function ProductSection({ products, djProfile }: { products: Product[], djProfile: DjProfile }) {
    const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
    const [showAll, setShowAll] = useState(false);

    const availableProducts = useMemo(() => {
        const list = (products || []).filter(p => p.inStock !== false);
        return list.sort((a, b) => {
            if (a.featured && !b.featured) return -1;
            if (!a.featured && b.featured) return 1;
            const dateA = a.lastUpdatedAt ? new Date(a.lastUpdatedAt.toString()).getTime() : 0;
            const dateB = b.lastUpdatedAt ? new Date(b.lastUpdatedAt.toString()).getTime() : 0;
            return dateB - dateA;
        });
    }, [products]);

    const categories = useMemo(() => {
        const cats = new Set<string>();
        availableProducts.forEach(p => { if (p.category) cats.add(p.category); });
        return Array.from(cats).sort();
    }, [availableProducts]);

    const featuredCount = useMemo(() => availableProducts.filter(p => p.featured).length, [availableProducts]);

    const productCountText = useMemo(() => {
        const total = availableProducts.length;
        const totalLabel = total === 1 ? 'PRODUTO' : 'PRODUTOS';
        if (featuredCount > 0) {
            return `${total} ${totalLabel} (${featuredCount} EM DESTAQUE)`;
        }
        return `${total} ${totalLabel}`;
    }, [availableProducts, featuredCount]);

    const [shuffledNonFeatured, setShuffledNonFeatured] = useState<Product[]>([]);

    useEffect(() => {
        const nonFeatured = availableProducts.filter(p => !p.featured);
        const shuffled = [...nonFeatured];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        setShuffledNonFeatured(shuffled);
    }, [availableProducts]);

    const { displayGroups, hasMore } = useMemo(() => {
        const isLimited = !selectedCategory && !showAll;
        
        const featured = availableProducts.filter(p => p.featured);
        const nonFeaturedList = shuffledNonFeatured.length > 0 
            ? shuffledNonFeatured 
            : availableProducts.filter(p => !p.featured);

        const limitedProducts = [
            ...featured.slice(0, 3),
            ...nonFeaturedList.slice(0, 5)
        ];

        let productsToGroup = availableProducts;
        if (isLimited) {
            productsToGroup = limitedProducts;
        } else if (selectedCategory) {
            productsToGroup = availableProducts.filter(p => p.category === selectedCategory);
        }

        const groups: Record<string, Product[]> = {};
        productsToGroup.forEach(p => {
            let catName = p.category || 'Outros';
            if (p.featured) catName = '🔥 DESTAQUES';
            if (!groups[catName]) groups[catName] = [];
            groups[catName].push(p);
        });

        const sortedGroupKeys = Object.keys(groups).sort((a, b) => {
            if (a === '🔥 DESTAQUES') return -1;
            if (b === '🔥 DESTAQUES') return 1;
            return a.localeCompare(b);
        });

        return { 
            displayGroups: sortedGroupKeys.map(key => ({ name: key, items: groups[key] })), 
            hasMore: isLimited && availableProducts.length > limitedProducts.length
        };
    }, [availableProducts, selectedCategory, showAll, shuffledNonFeatured]);

    if (availableProducts.length === 0) return null;
    const defaultOpen = djProfile.storeOpenByDefault ? "loja-item" : undefined;

    return (
        <Accordion type="single" collapsible defaultValue={defaultOpen} className="w-full rounded-lg border-border overflow-hidden transition-all duration-300">
            <AccordionItem value="loja-item" className="border-none bg-card data-[state=open]:bg-background transition-colors duration-300">
                <AccordionTrigger className="p-4 hover:no-underline">
                    <div className="flex items-center gap-3">
                        <ShoppingBag className="w-5 h-5 text-primary"/>
                        <div className="text-left">
                            <span className="font-bold text-md tracking-tight uppercase block">Loja Oficial</span>
                            <p className="text-xs text-muted-foreground font-medium">Produtos e merchandising.</p>
                        </div>
                    </div>
                </AccordionTrigger>
                <AccordionContent className="px-0">
                    <div className="flex items-center justify-center gap-2 text-sm font-semibold text-muted-foreground py-3 border-b border-zinc-800/40">
                        <ShoppingBag className="w-4 h-4" />
                        <span>{productCountText}</span>
                    </div>

                    {categories.length > 1 && (
                        <ScrollArea className="w-full whitespace-nowrap px-4 py-4">
                            <div className="flex w-max space-x-2">
                                <Button
                                    variant={selectedCategory === null ? 'default' : 'secondary'}
                                    size="sm"
                                    onClick={() => { setSelectedCategory(null); setShowAll(false); }}
                                    className="rounded-full h-8 text-[10px] uppercase font-bold tracking-widest"
                                >
                                    Todos
                                </Button>
                                {categories.map(cat => (
                                    <Button
                                        key={cat}
                                        variant={selectedCategory === cat ? 'default' : 'secondary'}
                                        size="sm"
                                        onClick={() => setSelectedCategory(cat)}
                                        className="rounded-full h-8 text-[10px] uppercase font-bold tracking-widest"
                                    >
                                        {cat}
                                    </Button>
                                ))}
                            </div>
                            <ScrollBar orientation="horizontal" />
                        </ScrollArea>
                    )}

                    {displayGroups.length === 0 ? (
                        <p className="text-muted-foreground text-center py-10 px-4">Nenhum produto encontrado.</p>
                    ) : (
                        <div className="space-y-8 pb-8 pt-4">
                            {displayGroups.map((group) => (
                                <div key={group.name} className="space-y-4">
                                    <div className="flex items-center gap-3 px-4">
                                        <h3 className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] whitespace-nowrap">{group.name}</h3>
                                        <div className="h-px bg-zinc-800/50 flex-1" />
                                    </div>
                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 px-0">
                                        {group.items.map((product) => (
                                            <PublicProductItem key={product.id} product={product} djProfile={djProfile} />
                                        ))}
                                    </div>
                                </div>
                            ))}
                            {hasMore && (
                                <div className="text-center pt-4 px-4">
                                    <Button 
                                        variant="secondary" 
                                        onClick={() => setShowAll(true)}
                                        className="w-full sm:w-auto h-12 px-8 rounded-full font-medium text-sm transition-all active:scale-[0.99]"
                                    >
                                        <Plus className="w-4 h-4 mr-2" />
                                        Mostrar outros produtos ({availableProducts.length})
                                    </Button>
                                </div>
                            )}
                        </div>
                    )}
                </AccordionContent>
            </AccordionItem>
        </Accordion>
    );
}