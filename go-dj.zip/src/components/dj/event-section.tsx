'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { format, isToday, getDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, Clock, Info, ExternalLink, MapPin, Maximize, Minimize, Loader2 } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import type { Event, DjProfile } from '@/types';
import { getSafeDate, formatDayOfWeek, generateSlug } from '@/lib/utils';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from '@/components/ui/collapsible';
import { ManagedImage } from '../managed-image';
import Link from 'next/link';
import { EventShareButton } from '@/components/event-share-button';

function PublicEventItem({ event, index }: { event: Event, index: number }) {
    if (!event) return null;

    const [isClient, setIsClient] = useState(false);
    const [isFlyerOpen, setIsFlyerOpen] = useState(false);
    const [isAccordionOpen, setIsAccordionOpen] = useState(false);
    const [isFlyerLoading, setIsFlyerLoading] = useState(true);

    useEffect(() => {
        setIsClient(true);
    }, []);

    const { eventDate, dateParts, isEventToday, isHappeningNow } = useMemo(() => {
        const date = getSafeDate(event.date);
        if (!date) {
            return { eventDate: null, dateParts: null, isEventToday: false, isHappeningNow: false };
        }
        
        const now = new Date();
        const today = isToday(date);
        const eventEndTime = new Date(date.getTime() + 6 * 60 * 60 * 1000);
        const happeningNow = now >= date && now <= eventEndTime;
        
        const parts = {
            dayOfWeek: formatDayOfWeek(date),
            day: format(date, 'dd'),
            month: format(date, 'MMM', { locale: ptBR }).toUpperCase(),
        };

        return { eventDate: date, dateParts: parts, isEventToday: today, isHappeningNow: happeningNow };
    }, [event.date]);

    const dayLabel = () => {
        if (!dateParts) return null;
        if (isHappeningNow) {
            return 'AGORA';
        }
        if (isEventToday) {
            return 'HOJE';
        }
        return dateParts.dayOfWeek;
    };


    const djSlug = event.djSlug || (typeof window !== 'undefined' ? window.location.pathname.split('/')[1] : 'dj');
    const eventSlug = generateSlug(event.title || 'evento');
    const eventPageUrl = `/${djSlug}/evento/${eventSlug}`;

    return (
        <>
            {/* Desktop / Tablet View - Direct link to event page */}
            <div className="hidden md:block h-full">
                <Link href={eventPageUrl} className="block group h-full">
                    <div className="bg-card hover:bg-zinc-800/80 border border-zinc-800/60 rounded-lg p-4 transition-all duration-300 flex items-center justify-between gap-4 h-full group-hover:border-zinc-700 shadow-md">
                        <div className="flex items-center gap-4 flex-1 min-w-0">
                            {event.flyerUrl ? (
                                <div className="relative h-14 w-14 shrink-0 rounded-md overflow-hidden border border-zinc-800 bg-zinc-900">
                                    <ManagedImage
                                        src={event.flyerUrl}
                                        alt={event.title || 'Flyer'}
                                        fill
                                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                                    />
                                </div>
                            ) : (
                                <div className="w-14 h-14 shrink-0 rounded-md bg-zinc-900 border border-zinc-800 flex items-center justify-center text-primary">
                                    <Calendar className="w-6 h-6" />
                                </div>
                            )}

                            {dateParts ? (
                                <div className="font-bold text-sm text-center text-white/60 w-14 shrink-0 flex flex-col">
                                    <span className={(isEventToday || isHappeningNow) ? "text-[10px] font-bold text-red-500" : "text-[10px]"}>
                                        {dayLabel()}
                                    </span>
                                    <span className="text-2xl text-white font-bold tracking-tight leading-none">{dateParts.day}</span>
                                    <span className="text-[10px] font-semibold">{dateParts.month}</span>
                                </div>
                            ) : (
                                <div className="w-14 shrink-0 flex items-center justify-center">
                                    <Calendar className="w-6 h-6 text-muted-foreground" />
                                </div>
                            )}

                            <div className="border-l border-zinc-700/80 pl-4 text-left flex-1 min-w-0">
                                <h3 className="font-condensed font-bold text-base sm:text-lg line-clamp-2 text-white group-hover:text-primary transition-colors leading-snug">
                                    {event.title || 'Evento sem título'}
                                </h3>
                                <div className="text-xs sm:text-sm text-muted-foreground mt-0.5 flex flex-col sm:flex-row sm:items-center sm:gap-2">
                                    <span className="font-condensed uppercase truncate font-bold text-white/70">{event.venue || 'Local não informado'}</span>
                                    {event.city && (
                                        <>
                                            <span className="hidden sm:inline text-zinc-600">•</span>
                                            <span className="truncate font-medium text-zinc-400">{event.city}</span>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                            {event.url && (
                                <span className="bg-primary rounded-full h-7 px-3 flex items-center justify-center font-bold text-xs text-primary-foreground">
                                    GO
                                </span>
                            )}
                            <div className="text-xs font-semibold text-zinc-400 group-hover:text-white flex items-center gap-1 pl-2">
                                <ExternalLink className="w-4 h-4 text-primary" />
                            </div>
                        </div>
                    </div>
                </Link>
            </div>

            {/* Mobile View - Accordion */}
            <div className="block md:hidden h-full">
                <Accordion type="single" collapsible onValueChange={(value) => setIsAccordionOpen(!!value)} className="w-full bg-card rounded-lg border border-zinc-800/50 overflow-hidden h-full">
                    <AccordionItem value={event.id || `event-item-${index}`} className="border-b-0 h-full">
                        <AccordionTrigger className="p-4 w-full cursor-pointer hover:no-underline [&>svg]:hidden group">
                             <div className="flex justify-between items-center gap-3 flex-1 min-w-0">
                                <div className="flex items-center gap-3 sm:gap-4 flex-1">
                                    {event.flyerUrl && (
                                        <div className={cn(
                                            "relative h-14 w-14 shrink-0 rounded-sm overflow-hidden border border-zinc-800 bg-zinc-900 transition-all duration-300",
                                            isAccordionOpen ? "opacity-0 scale-90 -ml-16" : "opacity-100 scale-100"
                                        )}>
                                            <ManagedImage
                                                src={event.flyerUrl}
                                                alt="Flyer thumb"
                                                fill
                                                className="object-cover"
                                            />
                                        </div>
                                    )}

                                     {!isClient ? (
                                        <div className="w-14 h-14 shrink-0 flex items-center justify-center">
                                            <Loader2 className="w-5 h-5 animate-spin" />
                                        </div>
                                     ) : dateParts ? (
                                        <div className={cn(
                                            "font-bold text-sm text-center text-white/60 w-14 shrink-0 flex flex-col transition-all duration-300",
                                        )}>
                                            <span className={(isEventToday || isHappeningNow) ? "text-[10px] font-bold text-red-500" : "text-[10px]"}>
                                                {dayLabel()}
                                            </span>
                                            <span className="text-xl sm:text-2xl text-white font-bold tracking-tight leading-none">{dateParts.day}</span>
                                            <span className="text-[10px] font-semibold">{dateParts.month}</span>
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-center w-14 shrink-0">
                                            <Calendar className="w-6 h-6 text-muted-foreground" />
                                        </div>
                                    )}
                                    
                                    <div className="border-l border-zinc-700 pl-4 text-left flex-1 min-w-0">
                                        <h3 className="font-condensed font-bold text-base sm:text-lg line-clamp-2 text-white leading-snug">{event.title || 'Evento sem título'}</h3>
                                        <div className="text-xs sm:text-sm text-muted-foreground mt-0.5 sm:mt-1 flex flex-col gap-0.5">
                                            <div className="font-condensed uppercase truncate font-bold text-white/70 leading-tight">{event.venue || 'Local não informado'}</div>
                                            <div className="truncate font-medium leading-tight">{event.city || 'cidade não informada'}</div>
                                        </div>
                                    </div>
                                </div>
                                {event.url && (
                                     <div className="bg-primary rounded-full h-6 w-6 flex items-center justify-center shrink-0 font-bold text-[10px] text-primary-foreground ml-2">
                                        GO
                                    </div>
                                )}
                            </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-4 pb-4 space-y-4">
                            
                            {event.flyerUrl && (
                                <Collapsible open={isFlyerOpen} onOpenChange={setIsFlyerOpen} className="relative overflow-hidden rounded-lg group">
                                    {isFlyerLoading && (
                                        <div className="absolute inset-0 flex items-start justify-center bg-card z-10" style={{ paddingTop: '100px' }}>
                                            <Loader2 className="w-10 h-10 animate-spin text-muted-foreground" />
                                        </div>
                                    )}
                                    <CollapsibleTrigger asChild>
                                        <div
                                            className={cn(
                                                "relative w-full overflow-hidden transition-all duration-300 ease-in-out cursor-pointer",
                                                "data-[state=open]:max-h-[800px] data-[state=closed]:max-h-[250px]"
                                            )}
                                            >
                                            <ManagedImage
                                                src={event.flyerUrl}
                                                alt={`Flyer for ${event.title}`}
                                                width={600}
                                                height={800}
                                                className="object-top object-contain w-full h-auto"
                                                wrapperClassName="flex items-center justify-center"
                                                onLoadingStateChange={setIsFlyerLoading}
                                                unoptimized
                                            />
                                            <div className={cn(
                                                "absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-card to-transparent",
                                                isFlyerOpen && "hidden"
                                            )}/>
                                        </div>
                                    </CollapsibleTrigger>
                                    <button 
                                        className="absolute bottom-2 right-2 bg-zinc-700 text-white h-8 w-8 rounded-full flex items-center justify-center transition-opacity hover:bg-zinc-600 z-10" 
                                        onClick={() => setIsFlyerOpen(prev => !prev)}
                                    >
                                        {isFlyerOpen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                                    </button>
                                </Collapsible>
                            )}
                            
                            <div className="space-y-3 text-sm text-muted-foreground pt-4">
                                {eventDate && (
                                    <div className="flex items-center gap-3">
                                        <Clock className="w-4 h-4 text-white shrink-0" />
                                        <span className="text-white font-medium">
                                            {format(eventDate, "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
                                        </span>
                                    </div>
                                )}
                                {event.description && (
                                    <div className="flex items-start gap-3">
                                        <Info className="w-4 h-4 text-white mt-0.5 shrink-0" />
                                        <p className="text-pretty text-white/80">{event.description}</p>
                                    </div>
                                )}
                                {(event.address || event.venue || event.city) && (
                                    <div className="flex items-start gap-3 pt-1">
                                        <MapPin className="w-4 h-4 text-white mt-0.5 shrink-0" />
                                        <div className="text-white/90">
                                            {event.venue && <div className="font-medium text-white">{event.venue}</div>}
                                            {event.address && <div className="text-white/80">{event.address}</div>}
                                            {event.city && <div className="text-white/60 text-xs">{event.city}</div>}
                                        </div>
                                    </div>
                                )}
                            </div>
                            
                            <div className="flex flex-col gap-2.5 pt-4">
                                {event.url && (
                                    <a href={event.url} target="_blank" rel="noopener noreferrer" className="block w-full">
                                        <Button className="w-full h-12 text-base font-medium bg-white hover:bg-zinc-200 text-black shadow-md transition-all active:scale-[0.99] rounded-full border-0">
                                            GO - Ir para o Link
                                        </Button>
                                    </a>
                                )}
                                {(event.address || event.venue) && (
                                    <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(event.address || `${event.venue || ''} ${event.city || ''}`)}`} target="_blank" rel="noopener noreferrer" className="block w-full">
                                        <Button className="w-full h-12 text-base font-medium bg-zinc-800 hover:bg-zinc-700 text-white transition-all rounded-full border-0 shadow-none">
                                            <MapPin className="mr-2 h-5 w-5 text-white" /> Como Chegar
                                        </Button>
                                    </a>
                                )}
                                <EventShareButton
                                    title={event.title || 'Evento'}
                                    eventUrl={eventPageUrl}
                                    className="w-full h-12 text-base font-medium bg-zinc-800 hover:bg-zinc-700 text-white transition-all rounded-full border-0 shadow-none"
                                />
                            </div>
                        </AccordionContent>
                    </AccordionItem>
                </Accordion>
            </div>
        </>
    );
}

const weekDays = [
    { label: 'DOM', mobileLabel: 'D', value: 0, fullName: 'DOMINGO' },
    { label: 'SEG', mobileLabel: 'S', value: 1, fullName: 'SEGUNDA' },
    { label: 'TER', mobileLabel: 'T', value: 2, fullName: 'TERÇA' },
    { label: 'QUA', mobileLabel: 'Q', value: 3, fullName: 'QUARTA' },
    { label: 'QUI', mobileLabel: 'Q', value: 4, fullName: 'QUINTA' },
    { label: 'SEX', mobileLabel: 'S', value: 5, fullName: 'SEXTA' },
    { label: 'SAB', mobileLabel: 'S', value: 6, fullName: 'SÁBADO' },
];

export function EventSection({ events, djProfile }: { events: Event[]; djProfile?: DjProfile }) {
    const [selectedDay, setSelectedDay] = useState<number | null>(null);

    const defaultOpen = djProfile?.agendaOpenByDefault !== false ? "agenda-item" : undefined;

    const futureEvents = useMemo(() => {
        if (!events) return [];
        const now = new Date();
        const startOfToday = new Date();
        startOfToday.setHours(0, 0, 0, 0);

        return events.filter(event => {
            const eventDate = getSafeDate(event.date);
            if (!eventDate) return true;
            const eventEndTime = new Date(eventDate.getTime() + 6 * 60 * 60 * 1000);
            return eventEndTime >= now || eventDate >= startOfToday;
        });
    }, [events]);

    const filteredEvents = useMemo(() => {
        if (selectedDay === null) {
            return futureEvents;
        }
        return futureEvents.filter(event => {
            const eventDate = getSafeDate(event.date);
            if (!eventDate) return false;
            return getDay(eventDate) === selectedDay;
        });
    }, [futureEvents, selectedDay]);

    const eventCount = filteredEvents?.length || 0;
    
     const eventCountText = useMemo(() => {
        if (selectedDay !== null) {
            const dayName = weekDays.find(d => d.value === selectedDay)?.fullName || '';
            const eventLabel = eventCount === 1 ? 'EVENTO' : 'EVENTOS';
            return `${eventCount} ${eventLabel} ${dayName}`;
        }
        const eventLabel = eventCount === 1 ? 'EVENTO AGENDADO' : 'EVENTOS AGENDADOS';
        return `${eventCount} ${eventLabel}`;
    }, [eventCount, selectedDay]);

    return (
        <Accordion type="single" collapsible defaultValue={defaultOpen} className="w-full rounded-lg border-border overflow-hidden transition-all duration-300">
            <AccordionItem value="agenda-item" className="border-b-0 bg-card data-[state=open]:bg-background transition-colors duration-300">
                <AccordionTrigger className="p-4 hover:no-underline">
                    <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-primary"/>
                        <div className="text-left">
                            <span className="font-bold text-md tracking-tight uppercase block">Agenda de Eventos</span>
                            <p className="text-xs text-muted-foreground font-medium">Próximos shows e apresentações.</p>
                        </div>
                    </div>
                </AccordionTrigger>
                <AccordionContent className="px-0">
                    <div className="flex flex-col justify-center items-center gap-4 py-6 px-4">
                        <div className="flex items-center justify-center gap-1 sm:gap-2 max-w-full overflow-x-auto py-1">
                            <Button 
                                onClick={(e) => { e.stopPropagation(); setSelectedDay(null); }}
                                variant={selectedDay === null ? 'default' : 'secondary'}
                                size="sm"
                                className={cn(
                                    "rounded-full w-7 h-7 sm:w-9 sm:h-9 p-0 shrink-0",
                                    selectedDay !== null && "bg-[#151515] hover:bg-zinc-800"
                                )}
                            >
                                <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            </Button>
                            {weekDays.map(day => (
                                <Button 
                                    key={day.value}
                                    onClick={(e) => { e.stopPropagation(); setSelectedDay(day.value); }}
                                    variant={selectedDay === day.value ? 'default' : 'secondary'}
                                    size="sm"
                                    className={cn(
                                        "rounded-full text-[11px] sm:text-sm h-7 w-7 sm:h-9 sm:w-auto p-0 sm:px-3 shrink-0 font-medium", 
                                        selectedDay !== day.value && "bg-[#151515] hover:bg-zinc-800"
                                    )}
                                >
                                    <span className="hidden sm:inline">{day.label}</span>
                                    <span className="sm:hidden text-[10px] sm:text-xs font-semibold">{day.mobileLabel}</span>
                                </Button>
                            ))}
                        </div>
                        <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                            <Calendar className="w-4 h-4" />
                            <span>{eventCountText}</span>
                        </div>
                    </div>

                    {!filteredEvents || filteredEvents.length === 0 ? (
                        <p className="text-muted-foreground text-center py-10 px-4">Nenhum evento agendado para este dia.</p>
                    ): (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pb-8 px-0">
                            {filteredEvents.map((event, index) => (event && <PublicEventItem key={event.id || `event-${index}`} event={event} index={index} />))}
                        </div>
                    )}
                </AccordionContent>
            </AccordionItem>
        </Accordion>
    );
}
