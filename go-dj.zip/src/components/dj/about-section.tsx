'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Image from 'next/image';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { User as UserIcon, CheckCircle, Share2, Copy, Check } from 'lucide-react';
import type { DjProfile } from '@/types';
import { Button } from '../ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog"
import { useToast } from '@/hooks/use-toast';

function QRCode({ url }: { url: string }) {
    if (!url) return null;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}&qzone=1&bgcolor=FFFFFF&color=000000`;
    return (
        <div className="bg-white p-2 rounded-xl w-44 h-44 mx-auto flex items-center justify-center shadow-inner">
            <Image 
                src={qrUrl} 
                alt="QR Code do perfil" 
                width={160} 
                height={160}
                className="rendering-pixelated"
            />
        </div>
    )
}

const BIO_CHAR_LIMIT = 150;

export function AboutSection({ djProfile }: { djProfile: DjProfile }) {
    const [isBioExpanded, setIsBioExpanded] = useState(false);
    const [isClient, setIsClient] = useState(false);
    const [copied, setCopied] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        setIsClient(true);
    }, []);
    
    const profileUrl = useMemo(() => {
        if (djProfile.customDomain) {
            return `https://${djProfile.customDomain.replace(/\/$/, '')}`;
        }
        return `https://godj.com.br/${djProfile.slug}`;
    }, [djProfile.customDomain, djProfile.slug]);

    const bioText = djProfile.bio || 'Biografia não disponível.';
    const isBioLong = bioText.length > BIO_CHAR_LIMIT;

    const displayedBio = isBioLong && !isBioExpanded 
        ? `${bioText.substring(0, BIO_CHAR_LIMIT)}...` 
        : bioText;

    const handleShare = () => {
        if (navigator.share && profileUrl) {
            navigator.share({
                title: `Perfil de ${djProfile.name} | GoDJ`,
                text: `Confira o perfil e a agenda de ${djProfile.name} no GoDJ!`,
                url: profileUrl,
            }).catch((error) => console.log('Erro ao compartilhar', error));
        }
    };

    const copyToClipboard = () => {
        if (!profileUrl) return;
        navigator.clipboard.writeText(profileUrl).then(() => {
            setCopied(true);
            toast({
                title: "Link Copiado!",
                description: "O endereço do perfil está na sua área de transferência."
            });
            setTimeout(() => setCopied(false), 2000);
        });
    };
    
    const canShare = isClient && typeof navigator !== 'undefined' && !!navigator.share;

    return (
        <Accordion type="single" collapsible className="w-full rounded-lg border-border overflow-hidden transition-all duration-300">
            <AccordionItem value="item-1" className="border-b-0 bg-card data-[state=open]:bg-background transition-colors duration-300">
            <AccordionTrigger className="p-4 hover:no-underline">
                <div className="flex items-center gap-3">
                    <UserIcon className="w-5 h-5 text-primary"/>
                    <div className="text-left">
                        <span className="font-bold text-md tracking-tight">SOBRE {djProfile.name?.toUpperCase() || 'O DEEJAY'}</span>
                        <p className="text-xs text-muted-foreground font-medium">Biografia, tags e mais.</p>
                    </div>
                </div>
            </AccordionTrigger>
            <AccordionContent className="px-0">
                <div className="flex flex-col items-center text-center py-6 px-0">
                    <Avatar className="h-28 w-24 mb-4">
                        <AvatarImage src={djProfile.profilePictureUrl} data-ai-hint="dj portrait" className="object-cover" />
                        <AvatarFallback>{djProfile.name ? djProfile.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                    </Avatar>
                    
                    {djProfile.verified && (
                       <Dialog>
                            <DialogTrigger asChild>
                                <Button variant="ghost" className="flex items-center gap-2 text-blue-400 font-bold mb-4 hover:bg-blue-400/10 hover:text-blue-400 h-8 px-3 rounded-full border border-blue-400/20">
                                    <CheckCircle className="w-4 h-4" />
                                    <span className="text-xs tracking-widest">VERIFICADO</span>
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-xs bg-zinc-900 border-zinc-800">
                                <DialogHeader className="items-center text-center">
                                     <CheckCircle className="w-16 h-16 text-blue-500 mb-4" />
                                    <DialogTitle>Deejay Verificado</DialogTitle>
                                    <DialogDescription className="text-center pt-2 text-zinc-400">
                                        Nós do GoDj asseguramos que <strong>{djProfile.name}</strong> é um profissional ativo e autêntico da cena.
                                    </DialogDescription>
                                </DialogHeader>
                                <DialogFooter className="sm:justify-center mt-2">
                                    <DialogClose asChild>
                                        <Button type="button" variant="secondary" className="w-full">Entendido</Button>
                                    </DialogClose>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                    )}

                    <div className="max-w-prose text-left w-full bg-card p-4 rounded-xl border border-zinc-800/50 mx-auto">
                        <p className="text-white/80 text-sm whitespace-pre-line leading-relaxed font-medium">
                            {displayedBio}
                        </p>
                        {isBioLong && (
                             <div className="text-right">
                                <Button
                                    variant="link"
                                    onClick={() => setIsBioExpanded(!isBioExpanded)}
                                    className="text-primary hover:text-primary/80 p-0 h-auto mt-2 text-xs font-bold uppercase tracking-wider hover:no-underline"
                                >
                                    {isBioExpanded ? 'Ver menos' : 'Ler biografia completa'}
                                </Button>
                            </div>
                        )}
                    </div>

                    <div className="flex flex-wrap gap-2 mt-6 justify-center px-4">
                        {djProfile.tags?.filter(Boolean).map((tag) => (
                            <Badge key={tag} variant="secondary" className="bg-zinc-800 text-white/70 border-none hover:bg-zinc-700">
                                {tag}
                            </Badge>
                        ))}
                    </div>
                </div>

                <div className="text-center space-y-5 pt-8 pb-8 border-t border-zinc-800/50 px-4">
                    <div className="space-y-1">
                        <h3 className="font-bold text-xs text-white/60 uppercase tracking-[0.2em]">Compartilhe este perfil</h3>
                        <p className="text-[10px] text-muted-foreground uppercase font-semibold">Leve sua música para todos os lugares</p>
                    </div>

                    {isClient && profileUrl && (
                        <div className="space-y-6">
                            <QRCode url={profileUrl} />
                            
                            <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto">
                                <Button 
                                    onClick={copyToClipboard}
                                    variant="secondary"
                                    className="bg-zinc-800 hover:bg-zinc-700 text-white/80 text-xs gap-2 border border-zinc-700/50"
                                >
                                    {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                                    <span>{copied ? 'Copiado!' : 'Copiar Link'}</span>
                                </Button>

                                {canShare ? (
                                    <Button 
                                        onClick={handleShare}
                                        variant="secondary"
                                        className="bg-zinc-800 hover:bg-zinc-700 text-white/80 text-xs gap-2 border border-zinc-700/50"
                                    >
                                        <Share2 className="h-4 w-4" /> <span>Compartilhar</span>
                                    </Button>
                                ) : (
                                    <a 
                                        href={`https://wa.me/?text=${encodeURIComponent(`Confira o perfil de ${djProfile.name} no GoDJ: ${profileUrl}`)}`}
                                        target="_blank" 
                                        rel="noopener noreferrer" 
                                        className="inline-flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 text-white/80 text-xs gap-2 border border-zinc-700/50 rounded-md px-4 py-2"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                                        <span>WhatsApp</span>
                                    </a>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </AccordionContent>
            </AccordionItem>
        </Accordion>
    )
}
