'use client';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  CarouselDots
} from "@/components/ui/carousel"
import Autoplay from "embla-carousel-autoplay"
import type { Event } from '@/types';
import { Loader2 } from 'lucide-react';
import { useEvents } from '@/hooks/use-events';
import { FeaturedEventCard } from './featured-event-card';
import { Button } from "./ui/button";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { EventCardSkeleton } from "@/app/eventos/page";


const MAX_EVENTS = 10;

function FeaturedEventsContent() {
    const { events, isLoading } = useEvents();
    
    // Filter for events that have a flyerUrl and then slice
    const featuredEvents = (events || []).filter(event => event.flyerUrl).slice(0, MAX_EVENTS);
    
    return (
        <div className="space-y-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-white tracking-wider font-headline">Próximos Eventos</h2>
                <p className="text-md text-muted-foreground mt-1">
                    Fique por dentro do que está rolando na cena.
                </p>
            </div>

            {isLoading ? (
                 <Carousel
                    opts={{
                        align: "start",
                    }}
                    className="w-full"
                >
                    <CarouselContent className="-ml-4">
                        {Array.from({ length: 6 }).map((_, index) => (
                            <CarouselItem key={`skeleton-${index}`} className="md:basis-1/2 lg:basis-1/3 pl-4">
                                <EventCardSkeleton />
                            </CarouselItem>
                        ))}
                    </CarouselContent>
                </Carousel>
            ) : !isLoading && featuredEvents.length === 0 ? (
                 <div className="text-center py-10 px-4 rounded-lg bg-card border-border">
                    <p className="text-muted-foreground">Nenhum evento com flyer encontrado no momento.</p>
                </div>
            ) : (
                <Carousel
                    opts={{
                        align: "start",
                    }}
                    plugins={[
                        Autoplay({
                          delay: 5000,
                        }),
                      ]}
                    className="w-full"
                >
                    <CarouselContent className="-ml-4">
                        {featuredEvents.map((event, index) => (
                           event && <CarouselItem key={event.id || index} className="md:basis-1/2 lg:basis-1/3 pl-4">
                                <FeaturedEventCard event={event} />
                            </CarouselItem>
                        ))}
                    </CarouselContent>
                    <CarouselPrevious className="hidden sm:flex" />
                    <CarouselNext className="hidden sm:flex" />
                    <CarouselDots className="pt-4" />
                </Carousel>
            )}
            
            <div className="text-center pt-4">
                <Link href="/eventos">
                    <Button variant="secondary">
                        Ver todos os eventos
                        <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </Link>
            </div>
        </div>
    );
}

export function FeaturedEvents() {
    return <FeaturedEventsContent />;
}
