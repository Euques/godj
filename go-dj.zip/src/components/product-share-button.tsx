'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Share2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export function ProductShareButton({ title, djName, variant = 'secondary', className }: { title: string; djName: string; variant?: 'secondary' | 'outline' | 'default' | 'ghost'; className?: string }) {
  const { toast } = useToast();

  const handleShare = async () => {
    const shareData = {
      title: `${title} - Dj ${djName}`,
      text: `Confira ${title} na loja oficial de Dj ${djName} no GoDJ!`,
      url: typeof window !== 'undefined' ? window.location.href : '',
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err) {
        // User cancelled or not allowed
      }
    }

    try {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copiado!",
        description: "O link do produto foi copiado para a área de transferência.",
      });
    } catch (e) {
      toast({
        variant: "destructive",
        title: "Erro ao compartilhar",
        description: "Não foi possível copiar o link.",
      });
    }
  };

  return (
    <Button
      variant={variant}
      onClick={handleShare}
      className={cn("w-full bg-zinc-800 hover:bg-zinc-700 text-white font-medium h-12 rounded-full text-sm border-0 transition-all active:scale-[0.99] flex items-center justify-center gap-2 shadow-none", className)}
    >
      <Share2 className="mr-2 h-5 w-5 text-white shrink-0" /> Enviar para um amigo
    </Button>
  );
}

