'use client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { addDocument, setDocument, useStorage } from '@/firebase';
import { collection, doc, Firestore, serverTimestamp, getDocs } from 'firebase/firestore';
import type { User } from 'firebase/auth';
import type { DjProfile, Product } from '@/types';
import { useEffect, useState, useCallback, useMemo } from 'react';
import { ImageUploader } from './image-uploader';
import { Loader2, Star } from 'lucide-react';
import { ref as storageRef, uploadString, getDownloadURL } from 'firebase/storage';
import Image from 'next/image';
import { Checkbox } from './ui/checkbox';

const productFormSchema = z.object({
  title: z.string().min(3, 'O título é muito curto').max(50, 'O título é muito longo'),
  price: z.string().refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: 'Preço inválido',
  }),
  category: z.string().min(2, 'Informe uma categoria').max(30),
  description: z.string().max(1000, 'A descrição é muito longa').optional().or(z.literal('')),
  featured: z.boolean().default(false),
});

type ProductFormValues = z.infer<typeof productFormSchema>;

interface ProductFormProps {
  user: User;
  firestore: Firestore;
  djProfile: DjProfile;
  productToEdit?: Product | null;
  onFinished?: () => void;
}

export function ProductForm({ user, firestore, djProfile, productToEdit, onFinished }: ProductFormProps) {
  const { toast } = useToast();
  const storage = useStorage();
  const isEditing = !!productToEdit;

  const [imageUrl, setImageUrl] = useState(productToEdit?.imageUrl || '');
  const [existingCategories, setExistingCategories] = useState<string[]>([]);
  
  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      title: '',
      price: '',
      category: '',
      description: '',
      featured: false,
    },
    mode: 'onChange',
  });

  // Buscar categorias já existentes do DJ para sugestão
  useEffect(() => {
    async function fetchCategories() {
        if (!user || !firestore) return;
        try {
            const productsCol = collection(firestore, 'djProfiles', user.uid, 'products');
            const snapshot = await getDocs(productsCol);
            const categories = new Set<string>();
            snapshot.docs.forEach(doc => {
                const data = doc.data() as Product;
                if (data.category) categories.add(data.category);
            });
            setExistingCategories(Array.from(categories).sort());
        } catch (e) {
            console.error("Erro ao carregar categorias:", e);
        }
    }
    fetchCategories();
  }, [user, firestore]);

  useEffect(() => {
    if (productToEdit) {
      form.reset({
        title: productToEdit.title || '',
        price: productToEdit.price?.toString() || '',
        category: productToEdit.category || '',
        description: productToEdit.description || '',
        featured: productToEdit.featured || false,
      });
      setImageUrl(productToEdit.imageUrl || '');
    }
  }, [productToEdit, form]);

 const handleImageUpload = useCallback((url: string | null) => {
    if (url) {
      setImageUrl(url);
    }
  }, []);

  async function onSubmit(data: ProductFormValues) {
    if (!user || !firestore) return;
    
    let finalImageUrl = imageUrl;

    try {
      if (imageUrl && imageUrl.startsWith('data:image')) {
        if (!storage) throw new Error("Serviço de Storage não está disponível.");
        const productId = productToEdit?.id || doc(collection(firestore, 'dummy')).id;
        const filePath = `djs/${djProfile.id}/products/${productId}/image.webp`;
        const fileRef = storageRef(storage, filePath);
        
        await uploadString(fileRef, imageUrl, 'data_url');
        finalImageUrl = await getDownloadURL(fileRef);
      }

      const productData: Omit<Product, 'id'> = {
          title: data.title,
          price: parseFloat(data.price),
          category: data.category,
          description: data.description || '',
          imageUrl: finalImageUrl || '',
          inStock: productToEdit ? (productToEdit.inStock ?? true) : true,
          featured: data.featured,
          djProfileId: user.uid,
          lastUpdatedAt: serverTimestamp(),
      };

      if (isEditing && productToEdit?.id) {
          const productRef = doc(firestore, 'djProfiles', user.uid, 'products', productToEdit.id);
          await setDocument(productRef, productData, { merge: true });
          toast({ title: 'Produto Atualizado!' });
      } else {
          const productsColRef = collection(firestore, 'djProfiles', user.uid, 'products');
          await addDocument(productsColRef, productData);
          toast({ title: 'Produto Cadastrado!' });
      }

      form.reset();
      setImageUrl('');
      onFinished?.();
    } catch(e) {
        console.error(e);
        toast({
            variant: 'destructive',
            title: 'Falha ao salvar',
            description: 'Tente novamente.',
        });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nome do Produto</FormLabel>
              <FormControl>
                <Input placeholder="Ex: Camiseta GoDJ Official" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField
            control={form.control}
            name="price"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Preço (R$)</FormLabel>
                <FormControl>
                    <Input type="number" step="0.01" placeholder="0,00" {...field} />
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
            />
            <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Categoria</FormLabel>
                <FormControl>
                    <div className="relative">
                        <Input placeholder="Ex: Vestuário" {...field} list="category-suggestions" />
                        <datalist id="category-suggestions">
                            {existingCategories.map(cat => <option key={cat} value={cat} />)}
                        </datalist>
                    </div>
                </FormControl>
                <FormDescription>Selecione uma existente ou digite uma nova.</FormDescription>
                <FormMessage />
                </FormItem>
            )}
            />
        </div>

         <FormField
          control={form.control}
          name="featured"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 bg-zinc-900/30">
              <FormControl>
                <Checkbox
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  Produto em Destaque
                </FormLabel>
                <FormDescription>
                  Aparecerá no topo da sua loja com prioridade.
                </FormDescription>
              </div>
            </FormItem>
          )}
        />
       
        <div className="bg-zinc-900/50 p-4 rounded-lg space-y-4">
            <FormItem>
                <FormLabel>Foto do Produto</FormLabel>
                 {imageUrl && (
                    <div className="mt-4 mb-4 relative w-full aspect-square max-w-[200px] mx-auto rounded-md overflow-hidden bg-muted">
                        <Image src={imageUrl} alt="Preview" layout="fill" objectFit="cover" />
                    </div>
                )}
                <FormControl>
                    <ImageUploader 
                        onUploadComplete={handleImageUpload} 
                        cropEnabled={true}
                        aspect={1}
                        initialImageUrl={imageUrl}
                    />
                </FormControl>
            </FormItem>
        </div>
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descrição</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Descreva o produto, tamanhos, cores..."
                  className="resize-none"
                  rows={4}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full" size="lg" disabled={form.formState.isSubmitting}>
            {(form.formState.isSubmitting) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEditing ? "Salvar Alterações" : "Cadastrar Produto"}
        </Button>
      </form>
    </Form>
  );
}
