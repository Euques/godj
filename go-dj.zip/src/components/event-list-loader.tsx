// This component has been deprecated and replaced by the more performant useEvents hook.
// It caused N+1 query issues, leading to slow load times.
// The file is kept to prevent breaking imports but should be considered removed.
export function EventListLoader({ children }: { children: (props: { events: any[], isLoading: boolean }) => React.ReactNode; }) {
  return children({ events: [], isLoading: true });
}
