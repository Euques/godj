
'use client';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel"
import Autoplay from "embla-carousel-autoplay"
import type { DjProfile } from '@/types';
import { Loader2 } from 'lucide-react';
import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { getSafeDate } from "@/lib/utils";
import { useDjs } from "@/hooks/use-djs";

const MAX_DJS = 12;

function NewDjsContent() {
    const { djs, isLoading } = useDjs();

    // 1. Filter for DJs with profile picture and createdAt timestamp
    const recentDjsWithPics = (djs || []).filter(dj => dj.profilePictureUrl && dj.createdAt);

    // 2. Sort by creation date (most recent first)
    recentDjsWithPics.sort((a, b) => {
        const dateA = a.createdAt ? getSafeDate(a.createdAt)!.getTime() : 0;
        const dateB = b.createdAt ? getSafeDate(b.createdAt)!.getTime() : 0;
        return dateB - dateA;
    });

    const newDjs = recentDjsWithPics.slice(0, MAX_DJS);
    
    return (
        <div className="space-y-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-white tracking-wider font-headline">Novos DJs na Área</h2>
                <p className="text-md text-muted-foreground mt-1">
                    Dê as boas-vindas aos mais novos talentos da plataforma.
                </p>
            </div>

            {isLoading && (
                <div className="flex justify-center items-center h-24">
                    <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                </div>
            )}

            {!isLoading && newDjs.length === 0 && (
                <p className="text-muted-foreground text-center py-10">Nenhum novo DJ encontrado ainda.</p>
            )}

            {!isLoading && newDjs.length > 0 && (
                <Carousel
                    opts={{
                        align: "start",
                        loop: newDjs.length > 5,
                    }}
                    plugins={[
                        Autoplay({
                          delay: 3000,
                        }),
                      ]}
                    className="w-full"
                >
                    <CarouselContent className="-ml-4 py-4">
                        {newDjs.map((dj, index) => (
                           dj && (
                            <CarouselItem key={dj.id || index} className="basis-auto pl-4">
                                <Link href={`/perfil/${dj.slug}`} className="block group">
                                     <Avatar className="h-20 w-20 border-2 border-zinc-700 transition-transform duration-300 group-hover:scale-110 group-hover:border-primary">
                                        <AvatarImage src={dj.profilePictureUrl} data-ai-hint="dj portrait" />
                                        <AvatarFallback>{dj.name ? dj.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                                    </Avatar>
                                </Link>
                            </CarouselItem>
                           )
                        ))}
                    </CarouselContent>
                    <CarouselPrevious className="hidden sm:flex" />
                    <CarouselNext className="hidden sm:flex" />
                </Carousel>
            )}
        </div>
    );
}

export function NewDjs() {
    return <NewDjsContent />
}
