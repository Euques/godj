
'use client';
import Link from 'next/link';
import Image from 'next/image';
import { UserNav } from '@/components/user-nav';
import { Button } from './ui/button';

export function Header() {
  return (
    <header className="py-3 sm:py-4 bg-background border-b border-zinc-800/40 sticky top-0 z-40 backdrop-blur-md">
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-4 sm:gap-6">
          <Link href="/" className="flex items-center shrink-0">
            <Image 
                src="/logo.png" 
                alt="Logo GoDJ" 
                width={90} 
                height={30}
                priority
                className="transition-opacity hover:opacity-80 h-auto w-auto max-h-7 sm:max-h-8"
            />
          </Link>
          <nav className="hidden md:flex items-center gap-4">
              <Link href="/eventos">
                  <Button variant="link" className="text-muted-foreground hover:text-white">Eventos</Button>
              </Link>
              <Link href="/djs">
                  <Button variant="link" className="text-muted-foreground hover:text-white">Deejays</Button>
              </Link>
          </nav>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <UserNav />
        </div>
      </div>
    </header>
  );
}
