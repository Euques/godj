import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, toDate } from 'date-fns';
import { Timestamp } from 'firebase/firestore';
import { ptBR } from 'date-fns/locale';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) {
    return "00:00";
  }
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  const formattedMinutes = String(minutes).padStart(2, '0');
  const formattedSeconds = String(remainingSeconds).padStart(2, '0');
  return `${formattedMinutes}:${formattedSeconds}`;
}

export const getSafeDate = (date: any): Date | null => {
    if (!date) return null;
    try {
        if (date instanceof Timestamp) {
            return date.toDate();
        }
        // Firestore Timestamps in server components are often serialized differently
        if (date && typeof date.seconds === 'number' && typeof date.nanoseconds === 'number') {
            return new Timestamp(date.seconds, date.nanoseconds).toDate();
        }
        if (typeof date.toDate === 'function') {
            return date.toDate();
        }
        const d = toDate(new Date(date));
        if (!isNaN(d.getTime())) {
            return d;
        }
        return null;
    } catch (e) {
        return null;
    }
};

export const formatForInput = (date: any): string => {
  const d = getSafeDate(date);
  if (!d) return '';
  // Formats to 'YYYY-MM-DDTHH:mm' which is required by datetime-local input
  return format(d, "yyyy-MM-dd'T'HH:mm");
};

export const generateSlug = (name: string) => {
  if (!name) return '';
  return name
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
};

export const formatDayOfWeek = (date: Date) => {
    const day = format(date, 'EEEE', { locale: ptBR });
    const abbreviations: { [key: string]: string } = {
        'Domingo': 'DOM',
        'Segunda-feira': 'SEG',
        'Terça-feira': 'TER',
        'Quarta-feira': 'QUA',
        'Quinta-feira': 'QUI',
        'Sexta-feira': 'SEX',
        'Sábado': 'SAB',
    };
    return abbreviations[day] || day.substring(0, 3).toUpperCase();
};
