import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Header } from '@/components/header';

export const dynamic = 'force-dynamic';

export default function NotFound() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <Header />
      <main className="flex-1 container mx-auto p-6 flex flex-col items-center justify-center text-center">
        <h1 className="text-4xl font-bold mb-4">404 - Página Não Encontrada</h1>
        <p className="text-muted-foreground mb-6">A página ou evento que você procura não existe ou foi removido.</p>
        <Link href="/">
          <Button variant="default">Voltar para a Página Inicial</Button>
        </Link>
      </main>
    </div>
  );
}
