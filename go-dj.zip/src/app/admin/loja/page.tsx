
'use client';

import { useMemoFirebase, useCollection, deleteDocument, useUser, useFirestore, useDoc, updateDocument } from '@/firebase';
import { doc, collection, query, orderBy } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { Loader2, PlusCircle, ShoppingBag, Settings2 } from 'lucide-react';
import { Header } from '@/components/header';
import type { DjProfile, Product } from '@/types';
import { ProductForm } from '@/components/product-form';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"
import { AdminProductItem } from '@/components/admin-product-item';
import type { User } from 'firebase/auth';
import Image from 'next/image';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';

function AdminProductFormWrapper({ 
    user, 
    djProfile, 
    productToEdit,
    onFinished
}: { 
    user: User, 
    djProfile: DjProfile, 
    productToEdit: Product | null,
    onFinished: () => void
}) {
    const firestore = useFirestore();

    if (!firestore) return <Loader2 className="w-6 h-6 animate-spin" />;

    return (
        <ProductForm 
            user={user}
            firestore={firestore}
            djProfile={djProfile} 
            productToEdit={productToEdit}
            onFinished={onFinished}
        />
    )
}

export default function AdminLojaPage() {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const { toast } = useToast();
    
    const [sheetOpen, setSheetOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);
    const [isUpdatingSettings, setIsUpdatingSettings] = useState(false);

    const djProfileRef = useMemoFirebase(() => {
        if (!user || !firestore) return null;
        return doc(firestore, 'djProfiles', user.uid);
    }, [user, firestore]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    
    const productsQuery = useMemoFirebase(() => {
        if (!firestore || !user?.uid) return null;
        return query(collection(firestore, 'djProfiles', user.uid, 'products'), orderBy('lastUpdatedAt', 'desc'));
    }, [firestore, user?.uid]);

    const {data: allProducts, isLoading: areProductsLoading} = useCollection<Product>(productsQuery);

    const isLoading = isUserLoading || isProfileLoading;

    const handleAddNew = () => {
        setEditingProduct(null);
        setSheetOpen(true);
    };

    const handleEdit = (product: Product) => {
        setEditingProduct(product);
        setSheetOpen(true);
    };
    
    const handleSheetClose = () => {
        setSheetOpen(false);
        setEditingProduct(null);
    }

    const handleDelete = async (productId: string) => {
        if (!firestore || !user?.uid || !productId) return;
        const productRef = doc(firestore, 'djProfiles', user.uid, 'products', productId);
        try {
            await deleteDocument(productRef);
            toast({
                title: "Produto Removido",
                description: "O produto foi removido da sua loja."
            })
        } catch(e) {
            toast({
                variant: 'destructive',
                title: "Falha ao remover",
                description: "Não foi possível remover o produto. Tente novamente.",
            });
        }
    }

    const handleToggleStoreOpen = async (value: boolean) => {
        if (!firestore || !user?.uid) return;
        setIsUpdatingSettings(true);
        try {
            const profileRef = doc(firestore, 'djProfiles', user.uid);
            await updateDocument(profileRef, { storeOpenByDefault: value });
            toast({
                title: "Configuração salva",
                description: value ? "A loja agora iniciará aberta no seu perfil." : "A loja agora iniciará fechada no seu perfil."
            });
        } catch (e) {
            toast({
                variant: 'destructive',
                title: "Erro ao salvar",
                description: "Não foi possível atualizar a configuração."
            });
        } finally {
            setIsUpdatingSettings(false);
        }
    }

    if (isLoading || !user) {
        return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }
    
    if (!djProfile) {
         return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <p>Carregando perfil...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col min-h-screen bg-background text-white">
            <Header />
            <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 sm:space-y-8">
                 <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                    <div className="text-left space-y-1">
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Gerenciar Loja</h1>
                        <p className="text-xs sm:text-sm text-muted-foreground">
                            Cadastre produtos para vender diretamente via WhatsApp.
                        </p>
                    </div>
                    <Drawer open={sheetOpen} onOpenChange={setSheetOpen}>
                        <DrawerTrigger asChild>
                            <Button onClick={handleAddNew} className="w-full sm:w-auto font-medium shadow-sm">
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Adicionar Produto
                            </Button>
                        </DrawerTrigger>
                        <DrawerContent className="max-w-2xl mx-auto">
                            <DrawerHeader>
                                <DrawerTitle>{editingProduct ? "Editar Produto" : "Adicionar Novo Produto"}</DrawerTitle>
                                <DrawerDescription>
                                    {editingProduct ? "Atualize os detalhes do produto." : "Preencha as informações do novo produto."}
                                </DrawerDescription>
                            </DrawerHeader>
                            <div className="mt-2">
                                <AdminProductFormWrapper 
                                    user={user}
                                    djProfile={djProfile} 
                                    productToEdit={editingProduct}
                                    onFinished={handleSheetClose}
                                />
                            </div>
                        </DrawerContent>
                    </Drawer>
                </div>

                <Card className="bg-card/50 border-zinc-800">
                    <CardContent className="p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                            <Settings2 className="w-5 h-5 text-muted-foreground" />
                            <div>
                                <h3 className="font-bold text-sm">Loja aberta por padrão</h3>
                                <p className="text-xs text-muted-foreground">Decida se a aba da loja inicia expandida no seu perfil.</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            {isUpdatingSettings && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
                            <Switch 
                                checked={!!djProfile.storeOpenByDefault}
                                onCheckedChange={handleToggleStoreOpen}
                                disabled={isUpdatingSettings}
                            />
                        </div>
                    </CardContent>
                </Card>
                
                <div className="space-y-4">
                    {areProductsLoading ? (
                         <div className="flex justify-center items-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                    ) : allProducts && allProducts.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {allProducts.map((product) => (
                                <AdminProductItem 
                                    key={product.id}
                                    product={product}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center text-muted-foreground py-10 px-4 rounded-lg bg-card border border-border">
                          <ShoppingBag className="w-12 h-12 mx-auto mb-4 opacity-20" />
                          <p>Nenhum produto cadastrado na sua loja.</p>
                          <Button onClick={handleAddNew} size="sm" className="mt-4">
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Cadastrar primeiro produto
                          </Button>
                        </div>
                    )}
                </div>
            </main>
             <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
              </footer>
        </div>
    );
}
