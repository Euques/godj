'use client';

import { useMemoFirebase, useCollection, deleteDocument, useUser, useFirestore, useDoc, updateDocument } from '@/firebase';
import { doc, collection, query, orderBy } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { useEffect, useState, useMemo } from 'react';
import { Loader2, PlusCircle, Settings2 } from 'lucide-react';
import { Header } from '@/components/header';
import type { DjProfile, Event } from '@/types';
import { EventForm } from '@/components/event-form';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"
import { AdminEventItem } from '@/components/admin-event-item';
import type { User } from 'firebase/auth';
import { getSafeDate } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';
import Image from 'next/image';

function AdminEventFormWrapper({ 
    user, 
    djProfile, 
    eventToEdit,
    onFinished
}: { 
    user: User, 
    djProfile: DjProfile, 
    eventToEdit: Event | null,
    onFinished: () => void
}) {
    const firestore = useFirestore();

    if (!firestore) return <Loader2 className="w-6 h-6 animate-spin" />;

    return (
        <EventForm 
            user={user}
            firestore={firestore}
            djProfile={djProfile} 
            eventToEdit={eventToEdit}
            onFinished={onFinished}
        />
    )
}

export default function AdminAgendaPage() {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const router = useRouter();
    const { toast } = useToast();
    
    const [sheetOpen, setSheetOpen] = useState(false);
    const [editingEvent, setEditingEvent] = useState<Event | null>(null);
    const [isUpdatingSettings, setIsUpdatingSettings] = useState(false);

    const djProfileRef = useMemoFirebase(() => {
        if (!user || !firestore) return null;
        return doc(firestore, 'djProfiles', user.uid);
    }, [user, firestore]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    
    const agendaQuery = useMemoFirebase(() => {
        if (!firestore || !user?.uid) return null;
        return query(collection(firestore, 'djProfiles', user.uid, 'agenda'), orderBy('date', 'desc'));
    }, [firestore, user?.uid]);

    const {data: allEvents, isLoading: areEventsLoading} = useCollection<Event>(agendaQuery);

    const { upcomingEvents, pastEvents } = useMemo(() => {
        if (!allEvents) return { upcomingEvents: [], pastEvents: [] };
        const now = new Date();
        const upcoming: Event[] = [];
        const past: Event[] = [];
        allEvents.forEach(event => {
            const eventDate = getSafeDate(event.date);
            if (eventDate) {
                const eventEndTime = new Date(eventDate.getTime() + 6 * 60 * 60 * 1000); // Adiciona 6 horas
                if (eventEndTime >= now) {
                    upcoming.push(event);
                } else {
                    past.push(event);
                }
            }
        });
        return { upcomingEvents: upcoming.sort((a,b) => getSafeDate(a.date)!.getTime() - getSafeDate(b.date)!.getTime()), pastEvents: past };
    }, [allEvents]);

    const isLoading = isUserLoading || isProfileLoading;

    const handleAddNew = () => {
        setEditingEvent(null);
        setSheetOpen(true);
    };

    const handleEdit = (event: Event) => {
        setEditingEvent(event);
        setSheetOpen(true);
    };
    
    const handleSheetClose = () => {
        setSheetOpen(false);
        setEditingEvent(null);
    }

    const handleDelete = async (eventId: string) => {
        if (!firestore || !user?.uid || !eventId) return;
        const eventRef = doc(firestore, 'djProfiles', user.uid, 'agenda', eventId);
        try {
            await deleteDocument(eventRef);
            toast({
                title: "Evento Removido",
                description: "O evento foi removido da sua agenda."
            })
        } catch(e) {
            toast({
                variant: 'destructive',
                title: "Falha ao remover",
                description: "Não foi possível remover o evento. Tente novamente.",
            });
        }
    }

    const handleToggleAgendaOpen = async (value: boolean) => {
        if (!firestore || !user?.uid) return;
        setIsUpdatingSettings(true);
        try {
            const profileRef = doc(firestore, 'djProfiles', user.uid);
            await updateDocument(profileRef, { agendaOpenByDefault: value });
            toast({
                title: "Configuração salva",
                description: value ? "A agenda agora iniciará aberta no seu perfil." : "A agenda agora iniciará fechada no seu perfil."
            });
        } catch (e) {
            toast({
                variant: 'destructive',
                title: "Erro ao salvar",
                description: "Não foi possível atualizar a configuração."
            });
        } finally {
            setIsUpdatingSettings(false);
        }
    };

    if (isLoading || !user) {
        return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }
    
    if (!djProfile) {
         return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }


    return (
        <div className="flex flex-col min-h-screen bg-background text-white">
            <Header />
            <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 sm:space-y-8">
                 <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                    <div className="text-left space-y-1">
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Gerenciar Agenda</h1>
                        <p className="text-xs sm:text-sm text-muted-foreground">
                            Adicione, visualize e remova seus eventos.
                        </p>
                    </div>
                    <Drawer open={sheetOpen} onOpenChange={setSheetOpen}>
                        <DrawerTrigger asChild>
                            <Button onClick={handleAddNew} className="w-full sm:w-auto font-medium shadow-sm">
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Adicionar Evento
                            </Button>
                        </DrawerTrigger>
                        <DrawerContent className="max-w-2xl mx-auto">
                            <DrawerHeader>
                                <DrawerTitle>{editingEvent ? "Editar Evento" : "Adicionar Novo Evento"}</DrawerTitle>
                                <DrawerDescription>
                                    {editingEvent ? "Atualize os detalhes do seu evento." : "Preencha as informações do novo evento."}
                                </DrawerDescription>
                            </DrawerHeader>
                            <div className="mt-2">
                                <AdminEventFormWrapper 
                                    user={user}
                                    djProfile={djProfile} 
                                    eventToEdit={editingEvent}
                                    onFinished={handleSheetClose}
                                />
                            </div>
                        </DrawerContent>
                    </Drawer>
                </div>

                <Card className="bg-card/50 border-zinc-800">
                    <CardContent className="p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                            <Settings2 className="w-5 h-5 text-muted-foreground" />
                            <div>
                                <h3 className="font-bold text-sm">Agenda aberta por padrão</h3>
                                <p className="text-xs text-muted-foreground">Decida se a aba da agenda inicia expandida no seu perfil.</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            {isUpdatingSettings && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
                            <Switch 
                                checked={djProfile.agendaOpenByDefault !== false}
                                onCheckedChange={handleToggleAgendaOpen}
                                disabled={isUpdatingSettings}
                            />
                        </div>
                    </CardContent>
                </Card>
                
                <div className="space-y-4">
                     <div className="text-left">
                        <h2 className="text-2xl font-bold">Próximos Eventos</h2>
                        <p className="text-muted-foreground mt-1 text-sm">
                            {upcomingEvents && upcomingEvents.length > 0 ? `Você tem ${upcomingEvents.length} próximo(s) evento(s).` : "Nenhum próximo evento cadastrado."}
                        </p>
                    </div>
                    
                    {areEventsLoading ? (
                         <div className="flex justify-center items-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                    ) : upcomingEvents && upcomingEvents.length > 0 ? (
                        <div className="space-y-3">
                            {upcomingEvents.map((event, index) => (
                                event && <AdminEventItem 
                                    key={event?.id || index}
                                    event={event}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center text-muted-foreground py-10 px-4 rounded-lg bg-card border border-border">
                          <p>Nenhum evento na sua agenda futura.</p>
                          <Button onClick={handleAddNew} size="sm" className="mt-4">
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Adicionar primeiro evento
                          </Button>
                        </div>
                    )}
                </div>

                {pastEvents && pastEvents.length > 0 && (
                     <div className="space-y-4 pt-8">
                         <div className="flex items-center gap-4">
                            <Separator className="flex-1 bg-zinc-700" />
                            <h3 className="text-center font-semibold text-muted-foreground tracking-widest text-sm">EVENTOS PASSADOS</h3>
                            <Separator className="flex-1 bg-zinc-700" />
                        </div>
                        <div className="space-y-3">
                            {pastEvents.map((event, index) => (
                                event && <AdminEventItem 
                                    key={event?.id || index}
                                    event={event}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                />
                            ))}
                        </div>
                    </div>
                )}
            </main>
             <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
              </footer>
        </div>
    );
}
