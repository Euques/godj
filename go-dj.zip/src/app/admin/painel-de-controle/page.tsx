
'use client';
import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2, Edit, Calendar, ShoppingBag } from 'lucide-react';
import { Header } from '@/components/header';
import type { DjProfile } from '@/types';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';

export default function DashboardPage() {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const router = useRouter();

    const djProfileRef = useMemoFirebase(() => {
        if (!user || !firestore) return null;
        return doc(firestore, 'djProfiles', user.uid);
    }, [user, firestore]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    const isLoading = isUserLoading || isProfileLoading;

    if (isLoading || !user) {
        return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }
    
    if (!djProfile) {
        return (
             <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                    <p className="ml-4">Carregando perfil...</p>
                </div>
            </div>
        )
    }

    return (
        <div className="flex flex-col min-h-screen bg-background text-white">
            <Header />
            <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 sm:space-y-8">
                <Card className="bg-card">
                    <CardHeader>
                        <CardTitle className="text-2xl">Bem-vindo(a) ao seu painel, {djProfile.name || 'DJ'}!</CardTitle>
                        <CardDescription>
                            Aqui você pode gerenciar seu perfil, agenda, loja e muito mais. Este é o seu espaço para controlar todas as informações que seus fãs veem.
                        </CardDescription>
                    </CardHeader>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     <Card className="bg-card flex flex-col">
                        <CardHeader>
                            <CardTitle>Gerenciar Perfil</CardTitle>
                            <CardDescription>Edite sua bio, fotos, redes sociais e tags.</CardDescription>
                        </CardHeader>
                        <CardContent className="mt-auto">
                            <Link href="/admin/profile" className="w-full">
                                <Button variant="secondary" className="w-full">
                                    <Edit className="mr-2 h-4 w-4"/>
                                    Editar Perfil
                                </Button>
                            </Link>
                        </CardContent>
                    </Card>
                     <Card className="bg-card flex flex-col">
                        <CardHeader>
                            <CardTitle>Gerenciar Agenda</CardTitle>
                            <CardDescription>Adicione, edite ou remova seus próximos eventos.</CardDescription>
                        </CardHeader>
                        <CardContent className="mt-auto">
                             <Link href="/admin/agenda" className="w-full">
                                <Button variant="secondary" className="w-full">
                                    <Calendar className="mr-2 h-4 w-4"/>
                                    Gerenciar Agenda
                                </Button>
                            </Link>
                        </CardContent>
                    </Card>
                    <Card className="bg-card flex flex-col">
                        <CardHeader>
                            <CardTitle>Minha Loja</CardTitle>
                            <CardDescription>Cadastre produtos para vender via WhatsApp.</CardDescription>
                        </CardHeader>
                        <CardContent className="mt-auto">
                             <Link href="/admin/loja" className="w-full">
                                <Button variant="secondary" className="w-full">
                                    <ShoppingBag className="mr-2 h-4 w-4"/>
                                    Gerenciar Loja
                                </Button>
                            </Link>
                        </CardContent>
                    </Card>
                </div>
            </main>
            <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
            </footer>
        </div>
    );
}
