'use client';

import { useUser, useFirestore, useDoc, useMemoFirebase, updateDocument, useStorage } from '@/firebase';
import { doc, serverTimestamp } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { Header } from '@/components/header';
import type { DjProfile } from '@/types';
import { DjProfileForm } from '@/components/dj-profile-form';
import Image from 'next/image';
import { ref as storageRef, uploadString, getDownloadURL } from 'firebase/storage';
import { useToast } from '@/hooks/use-toast';

function AdminProfileFormWrapper() {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const storage = useStorage();
    const { toast } = useToast();

    const djProfileRef = useMemoFirebase(() => {
        if (!user || !firestore) return null;
        return doc(firestore, 'djProfiles', user.uid);
    }, [user, firestore]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    
    const handleImageUploadAndUpdate = async (
        imageDataUri: string | null,
        imageType: 'profile' | 'cover'
      ) => {
        if (!imageDataUri || !storage || !user?.uid) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Serviço de upload indisponível.' });
            return null;
        }

        const toastId = toast({ title: 'Enviando imagem...', description: 'Aguarde, por favor.' }).id;

        try {
            const filePath = `djs/${user.uid}/images/${imageType}-${Date.now()}.webp`;
            const fileRef = storageRef(storage, filePath);
            
            await uploadString(fileRef, imageDataUri, 'data_url');
            const downloadUrl = await getDownloadURL(fileRef);

            const profileRef = doc(firestore, 'djProfiles', user.uid);
            const fieldToUpdate = imageType === 'profile' ? 'profilePictureUrl' : 'coverPhotoUrl';
            await updateDocument(profileRef, { [fieldToUpdate]: downloadUrl });

            toast({ id: toastId, title: 'Sucesso!', description: 'Imagem atualizada.' });
            return downloadUrl;

        } catch (error) {
            console.error('Falha no upload da imagem:', error);
            toast({ id: toastId, variant: 'destructive', title: 'Falha no Upload', description: 'Não foi possível salvar a imagem. Tente novamente.'});
            return null;
        }
    };


    if (isUserLoading || isProfileLoading || !firestore || !user) {
        return (
            <div className="flex justify-center items-center py-10">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                 <p className="ml-4 text-muted-foreground">Conectando ao banco de dados...</p>
            </div>
        );
    }
    
    const isEditing = !!djProfile;

    return (
        <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
                <h1 className="text-3xl font-bold">{isEditing ? 'Editar Perfil' : 'Criar seu Perfil de DJ'}</h1>
                <p className="text-muted-foreground mt-2">
                    {isEditing ? 'Atualize suas informações para manter seus fãs informados.' : 'Preencha as informações abaixo para que todos possam te conhecer.'}
                </p>
            </div>
            <DjProfileForm 
                user={user} 
                djProfile={djProfile} 
                firestore={firestore}
                isEditing={isEditing}
                onImageUpload={handleImageUploadAndUpdate}
            />
        </div>
    );
}

export default function AdminProfilePage() {
    const { user, isUserLoading } = useUser();
    const router = useRouter();

    useEffect(() => {
        if (!isUserLoading && !user) {
            router.push('/');
        }
    }, [user, isUserLoading, router]);

     if (isUserLoading || !user) {
        return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col min-h-screen bg-background text-white">
            <Header />
             <main className="flex-1 container mx-auto p-4 lg:p-6 space-y-8">
                <AdminProfileFormWrapper />
            </main>
            <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
            </footer>
        </div>
    );
}
