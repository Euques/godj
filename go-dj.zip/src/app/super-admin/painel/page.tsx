'use client';

import { useMemo } from 'react';
import type { DjProfile } from '@/types';
import { Header } from '@/components/header';
import Image from 'next/image';
import { Loader2, ShieldCheck, Edit, Calendar, Copy, Search, X, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useUser, useFirestore, useDoc, useMemoFirebase, updateDocument } from '@/firebase';
import { useRouter } from 'next/navigation';
import { useEffect, useState, useTransition } from 'react';
import { doc, type DocumentReference } from 'firebase/firestore';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { deleteDj, setAdminClaim } from '@/firebase/admin-actions';
import { getAuth } from 'firebase/auth';
import { useDjs } from '@/hooks/use-djs';


const SUPER_ADMIN_EMAIL = "euques@gmail.com";
const DJS_PER_PAGE = 10;

function DjAdminCard({ dj, currentUser, onDjDeleted }: { dj: DjProfile, currentUser: any, onDjDeleted: (djId: string) => void }) {
    const firestore = useFirestore();
    const { toast } = useToast();
    const eventCount = dj.eventCount || 0;
    const [isPending, startTransition] = useTransition();

    const [isVerified, setIsVerified] = useState(dj.verified || false);
    const [isSuperAdmin, setIsSuperAdmin] = useState(dj.isSuperAdmin || false);
    
    const handleStatusChange = async (field: 'verified' | 'isSuperAdmin', value: boolean) => {
        if (!firestore) return;

        startTransition(async () => {
             try {
                if (field === 'isSuperAdmin') {
                    await setAdminClaim(dj.id, value);
                }

                const djRef = doc(firestore, 'djProfiles', dj.id) as DocumentReference<DjProfile>;
                await updateDocument(djRef, { [field]: value });

                if (field === 'verified') setIsVerified(value);
                if (field === 'isSuperAdmin') setIsSuperAdmin(value);

                // If the current user is changing their own admin status, force a token refresh
                if (dj.id === currentUser.uid) {
                    const auth = getAuth();
                    await auth.currentUser?.getIdToken(true);
                }

                toast({
                    title: 'Status do DJ atualizado!',
                    description: `O status de ${dj.name} foi alterado com sucesso.`,
                });
            } catch (error: any) {
                console.error(`Failed to update DJ status for field ${field}:`, error);
                toast({
                    variant: "destructive",
                    title: 'Falha ao atualizar',
                    description: error.message || `Não foi possível alterar o status do DJ.`,
                });
                // Revert UI on failure
                if (field === 'verified') setIsVerified(!value);
                if (field === 'isSuperAdmin') setIsSuperAdmin(!value);
            }
        });
    };
    
    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text).then(() => {
             toast({
                title: 'UID Copiado!',
                description: 'O UID do DJ foi copiado para a área de transferência.',
            });
        });
    }

    const handleDelete = () => {
        startTransition(async () => {
            try {
                await deleteDj(dj.id);
                toast({
                    title: 'DJ Excluído!',
                    description: `${dj.name} foi removido(a) permanentemente da plataforma.`
                });
                onDjDeleted(dj.id);
            } catch (error: any) {
                console.error("Failed to delete DJ:", error);
                 toast({
                    variant: "destructive",
                    title: 'Falha ao excluir DJ',
                    description: error.message || 'Ocorreu um erro inesperado.',
                });
            }
        });
    }


    return (
         <Card className="bg-card hover:bg-zinc-800/50 transition-colors">
            <div className="p-4 flex flex-col gap-4">
                {/* DJ Info */}
                <div className='flex items-center gap-4 min-w-0'>
                    <Avatar className="h-14 w-14 border-2 border-zinc-700">
                        <AvatarImage src={dj.profilePictureUrl} data-ai-hint="dj portrait" />
                        <AvatarFallback>{dj.name ? dj.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                           {isVerified && <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0" />}
                            <h4 className="font-bold truncate text-white">{dj.name || 'DJ sem nome'}</h4>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{dj.email}</p>
                         {isSuperAdmin && <p className="text-xs font-bold text-primary truncate mt-1">SUPER ADMIN</p>}
                         <div className="flex items-center gap-2 mt-1">
                            <p className="text-xs text-muted-foreground/60 font-mono truncate">UID: {dj.id}</p>
                             <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground/60 hover:text-muted-foreground" onClick={() => copyToClipboard(dj.id)}>
                                <Copy className="h-3 w-3" />
                            </Button>
                        </div>
                    </div>
                </div>

                <Separator className='bg-zinc-700/50' />

                {/* Actions */}
                <div className='grid grid-cols-2 gap-2'>
                    <Link href={`/super-admin/agenda/${dj.id}`} className="flex-1">
                        <Button variant="outline" size="sm" className="w-full">
                            <Calendar className="mr-2 h-4 w-4"/>
                            Eventos ({eventCount})
                        </Button>
                    </Link>
                    <Link href={`/super-admin/perfil/${dj.id}`} className="flex-1">
                        <Button variant="secondary" size="sm" className="w-full">
                            <Edit className="mr-2 h-4 w-4"/>
                            Editar Perfil
                        </Button>
                    </Link>
                </div>
                
                {/* Status Toggles */}
                 <div className='flex gap-2 items-center justify-between w-full pt-2'>
                    <div className='flex gap-4 items-center'>
                      <div className="flex items-center space-x-2">
                          <Switch 
                              id={`verified-${dj.id}`} 
                              checked={isVerified}
                              onCheckedChange={(value) => handleStatusChange('verified', value)}
                              disabled={isPending}
                          />
                          <Label htmlFor={`verified-${dj.id}`} className="text-xs">Verificado</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                          <Switch 
                              id={`superadmin-${dj.id}`}
                              checked={isSuperAdmin}
                              onCheckedChange={(value) => handleStatusChange('isSuperAdmin', value)}
                              disabled={isPending || dj.email === SUPER_ADMIN_EMAIL}
                          />
                          <Label htmlFor={`superadmin-${dj.id}`} className="text-xs">Super Admin</Label>
                      </div>
                    </div>

                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm" disabled={isPending}>
                               {isPending ? <Loader2 className="w-4 h-4 animate-spin"/> : <Trash2 className="w-4 h-4"/>}
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
                                <AlertDialogDescription>
                                    Você tem certeza que deseja excluir permanentemente <strong>{dj.name}</strong>? Todos os seus dados, incluindo perfil, eventos, e arquivos (fotos, flyers) serão apagados. O acesso será revogado. <strong>Esta ação não pode ser desfeita.</strong>
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDelete} disabled={isPending}>
                                    {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Excluir DJ
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </div>
            </div>
        </Card>
    );
}

function SuperAdminDashboard({ currentUser }: { currentUser: any }) {
    const { djs: initialDjs, isLoading } = useDjs();
    const [searchTerm, setSearchTerm] = useState('');
    const [visibleCount, setVisibleCount] = useState(DJS_PER_PAGE);
    const [djs, setDjs] = useState(initialDjs);

    useEffect(() => {
        setDjs(initialDjs);
    }, [initialDjs]);

    const handleDjDeleted = (djId: string) => {
        setDjs(prevDjs => prevDjs.filter(dj => dj.id !== djId));
    };

    const filteredDjs = useMemo(() => {
        if (!djs) return [];
        return djs.filter(dj => {
            if (!dj) return false;
            const term = searchTerm.toLowerCase();
            return (
                dj.name?.toLowerCase().includes(term) ||
                dj.email?.toLowerCase().includes(term) ||
                dj.id.toLowerCase().includes(term)
            );
        });
    }, [djs, searchTerm]);

    const visibleDjs = useMemo(() => {
        return filteredDjs.slice(0, visibleCount);
    }, [filteredDjs, visibleCount]);

    const handleLoadMore = () => {
        setVisibleCount(prev => prev + DJS_PER_PAGE);
    };

    return (
        <div className="space-y-8">
            <div className="text-left">
                <h1 className="text-3xl font-bold text-white tracking-wider">Painel Super Admin</h1>
                <p className="text-md text-muted-foreground mt-1">
                    Gerencie todos os DJs da plataforma.
                </p>
            </div>
            
            <div className="relative max-w-lg">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    placeholder="Buscar por nome, e-mail ou UID..."
                    className="pl-10 h-11"
                    value={searchTerm}
                    onChange={(e) => {
                        setSearchTerm(e.target.value);
                        setVisibleCount(DJS_PER_PAGE); // Reset pagination on new search
                    }}
                />
                {searchTerm && (
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                        onClick={() => setSearchTerm('')}
                    >
                        <X className="h-5 w-5 text-muted-foreground" />
                    </Button>
                )}
            </div>

            {isLoading && (
                <div className="flex justify-center items-center h-40">
                    <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                </div>
            )}
            {!isLoading && filteredDjs.length === 0 && (
                <p className="text-muted-foreground text-center py-10">
                    {searchTerm ? `Nenhum DJ encontrado para "${searchTerm}".` : "Nenhum DJ cadastrado na plataforma."}
                </p>
            )}

            <div className="space-y-3">
                {!isLoading && visibleDjs.map((dj) => (
                    dj && <DjAdminCard key={dj.id} dj={dj} currentUser={currentUser} onDjDeleted={handleDjDeleted} />
                ))}
            </div>
            
            {!isLoading && visibleCount < filteredDjs.length && (
                <div className="text-center pt-8">
                    <Button onClick={handleLoadMore}>Carregar mais</Button>
                </div>
            )}
        </div>
    );
}


export default function SuperAdminPage() {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const router = useRouter();

    const djProfileRef = useMemoFirebase(() => {
        if (!isUserLoading && user && firestore) {
            return doc(firestore, 'djProfiles', user.uid);
        }
        return null;
    }, [user, isUserLoading, firestore]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    
    useEffect(() => {
        if (!isUserLoading && !isProfileLoading) {
            if (!user || (user.email !== SUPER_ADMIN_EMAIL && !djProfile?.isSuperAdmin)) {
                router.push('/');
            }
        }
    }, [user, isUserLoading, djProfile, isProfileLoading, router]);

    if (isUserLoading || isProfileLoading || !user) {
        return (
             <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        )
    }

    return (
         <div className="flex flex-col min-h-screen bg-background">
            <Header />
            <main className="flex-1 container mx-auto p-4 lg:p-6 space-y-12">
                 <SuperAdminDashboard currentUser={user} />
            </main>
             <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
              </footer>
        </div>
    );
}
