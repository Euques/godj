'use client';

import { useMemoFirebase, useCollection, deleteDocument, useUser, useFirestore, useDoc } from '@/firebase';
import { doc, collection, query, orderBy } from 'firebase/firestore';
import { useRouter, useParams } from 'next/navigation';
import { useEffect, useState, useMemo } from 'react';
import { Loader2, PlusCircle, ArrowLeft, ShieldCheck } from 'lucide-react';
import { Header } from '@/components/header';
import type { DjProfile, Event } from '@/types';
import { EventForm } from '@/components/event-form';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"
import { AdminEventItem } from '@/components/admin-event-item';
import type { User } from 'firebase/auth';
import { getSafeDate } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';
import Image from 'next/image';
import Link from 'next/link';


const SUPER_ADMIN_EMAIL = "euques@gmail.com";

function AdminEventFormWrapper({ 
    djId,
    djProfile, 
    eventToEdit,
    onFinished
}: { 
    djId: string,
    djProfile: DjProfile, 
    eventToEdit: Event | null,
    onFinished: () => void
}) {
    const firestore = useFirestore();
    const { user } = useUser(); // use the currently logged-in user
    const fakeUser = useMemo(() => ({ uid: djId } as User), [djId]);

    if (!firestore || !user) return <Loader2 className="w-6 h-6 animate-spin" />;

    return (
        <EventForm 
            user={fakeUser} // The user being edited
            firestore={firestore}
            djProfile={djProfile} 
            eventToEdit={eventToEdit}
            onFinished={onFinished}
        />
    )
}

export default function SuperAdminAgendaPage() {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const router = useRouter();
    const params = useParams();
    const djId = params.djId as string;
    const { toast } = useToast();
    
    const [sheetOpen, setSheetOpen] = useState(false);
    const [editingEvent, setEditingEvent] = useState<Event | null>(null);

    const currentUserProfileRef = useMemoFirebase(() => {
        if (!isUserLoading && user && firestore) {
            return doc(firestore, 'djProfiles', user.uid);
        }
        return null;
    }, [user, isUserLoading, firestore]);
    const { data: currentUserProfile, isLoading: isCurrentUserProfileLoading } = useDoc<DjProfile>(currentUserProfileRef);

    const djProfileRef = useMemoFirebase(() => {
        if (!firestore || !djId) return null;
        return doc(firestore, 'djProfiles', djId);
    }, [firestore, djId]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    
    const agendaQuery = useMemoFirebase(() => {
        if (!firestore || !djId) return null;
        return query(collection(firestore, 'djProfiles', djId, 'agenda'), orderBy('date', 'desc'));
    }, [firestore, djId]);

    const {data: allEvents, isLoading: areEventsLoading} = useCollection<Event>(agendaQuery);

    const { upcomingEvents, pastEvents } = useMemo(() => {
        if (!allEvents) return { upcomingEvents: [], pastEvents: [] };
        const now = new Date();
        const upcoming: Event[] = [];
        const past: Event[] = [];
        allEvents.forEach(event => {
            const eventDate = getSafeDate(event.date);
            if (eventDate) {
                const eventEndTime = new Date(eventDate.getTime() + 6 * 60 * 60 * 1000); // Adiciona 6 horas
                if (eventEndTime >= now) {
                    upcoming.push(event);
                } else {
                    past.push(event);
                }
            }
        });
        return { upcomingEvents: upcoming.sort((a,b) => getSafeDate(a.date)!.getTime() - getSafeDate(b.date)!.getTime()), pastEvents: past };
    }, [allEvents]);

    useEffect(() => {
       if (!isUserLoading && !isCurrentUserProfileLoading) {
            if (!user || (user.email !== SUPER_ADMIN_EMAIL && !currentUserProfile?.isSuperAdmin)) {
                router.push('/');
            }
        }
    }, [user, isUserLoading, currentUserProfile, isCurrentUserProfileLoading, router]);

    const handleAddNew = () => {
        setEditingEvent(null);
        setSheetOpen(true);
    };

    const handleEdit = (event: Event) => {
        setEditingEvent(event);
        setSheetOpen(true);
    };
    
    const handleSheetClose = () => {
        setSheetOpen(false);
        setEditingEvent(null);
    }

    const handleDelete = async (eventId: string) => {
        if (!firestore || !djId || !eventId) return;
        const eventRef = doc(firestore, 'djProfiles', djId, 'agenda', eventId);
        try {
            await deleteDocument(eventRef);
            toast({
                title: "Evento Removido",
                description: "O evento foi removido da agenda do DJ."
            })
        } catch(e) {
            toast({
                variant: 'destructive',
                title: "Falha ao remover",
                description: "Não foi possível remover o evento. Tente novamente.",
            });
        }
    }

    if (isUserLoading || isProfileLoading || isCurrentUserProfileLoading || !user) {
        return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }
    
    if (!djProfile) {
         return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                   <p>Perfil de DJ não encontrado.</p>
                </div>
            </div>
        );
    }


    return (
        <div className="flex flex-col min-h-screen bg-background text-white">
            <Header />
            <main className="flex-1 container mx-auto p-4 lg:p-6 space-y-8">
                 <div className="flex justify-between items-center">
                    <div className="text-left">
                        <Link href="/super-admin/painel">
                            <Button variant="ghost" className='mb-4'>
                                <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para o painel
                            </Button>
                        </Link>
                        <h1 className="text-3xl font-bold flex items-center gap-2">
                            {djProfile.verified && <ShieldCheck className="w-6 h-6 text-blue-500" />}
                            Agenda de: {djProfile.name}
                        </h1>
                        <p className="text-muted-foreground mt-2">
                           Adicione, visualize e remova eventos para este DJ.
                        </p>
                    </div>
                    <Drawer open={sheetOpen} onOpenChange={setSheetOpen}>
                        <DrawerTrigger asChild>
                            <Button onClick={handleAddNew}>
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Adicionar Evento
                            </Button>
                        </DrawerTrigger>
                        <DrawerContent className="max-w-2xl mx-auto">
                            <DrawerHeader>
                                <DrawerTitle>{editingEvent ? "Editar Evento" : "Adicionar Novo Evento"}</DrawerTitle>
                                <DrawerDescription>
                                    {editingEvent ? "Atualize os detalhes do evento." : "Preencha as informações do novo evento."}
                                </DrawerDescription>
                            </DrawerHeader>
                            <div className="mt-2">
                                <AdminEventFormWrapper 
                                    djId={djId}
                                    djProfile={djProfile} 
                                    eventToEdit={editingEvent}
                                    onFinished={handleSheetClose}
                                />
                            </div>
                        </DrawerContent>
                    </Drawer>
                </div>
                
                <div className="space-y-4">
                     <div className="text-left">
                        <h2 className="text-2xl font-bold">Próximos Eventos</h2>
                        <p className="text-muted-foreground mt-1 text-sm">
                            {upcomingEvents && upcomingEvents.length > 0 ? `${djProfile.name} tem ${upcomingEvents.length} próximo(s) evento(s).` : "Nenhum próximo evento cadastrado."}
                        </p>
                    </div>
                    
                    {areEventsLoading ? (
                         <div className="flex justify-center items-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                    ) : upcomingEvents && upcomingEvents.length > 0 ? (
                        <div className="space-y-3">
                            {upcomingEvents.map((event, index) => (
                                event && <AdminEventItem 
                                    key={event?.id || index}
                                    event={event}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center text-muted-foreground py-10 px-4 rounded-lg bg-card border border-border">
                          <p>Nenhum evento na agenda futura deste DJ.</p>
                          <Button onClick={handleAddNew} size="sm" className="mt-4">
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Adicionar primeiro evento
                          </Button>
                        </div>
                    )}
                </div>

                {pastEvents && pastEvents.length > 0 && (
                     <div className="space-y-4 pt-8">
                         <div className="flex items-center gap-4">
                            <Separator className="flex-1 bg-zinc-700" />
                            <h3 className="text-center font-semibold text-muted-foreground tracking-widest text-sm">EVENTOS PASSADOS</h3>
                            <Separator className="flex-1 bg-zinc-700" />
                        </div>
                        <div className="space-y-3">
                            {pastEvents.map((event, index) => (
                                event && <AdminEventItem 
                                    key={event?.id || index}
                                    event={event}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                />
                            ))}
                        </div>
                    </div>
                )}
            </main>
             <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
              </footer>
        </div>
    );
}
