'use client';

import { useUser, useFirestore, useDoc, useMemoFirebase, updateDocument, setDocument, useStorage } from '@/firebase';
import { doc, serverTimestamp } from 'firebase/firestore';
import { useRouter, useParams } from 'next/navigation';
import React, { useEffect, useState } from 'react';
import { Loader2, ShieldCheck, ArrowLeft } from 'lucide-react';
import { Header } from '@/components/header';
import type { DjProfile } from '@/types';
import { DjProfileForm } from '@/components/dj-profile-form';
import type { User } from 'firebase/auth';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ref as storageRef, uploadString, getDownloadURL } from 'firebase/storage';
import { useToast } from '@/hooks/use-toast';

const SUPER_ADMIN_EMAIL = "euques@gmail.com";

function AdminProfileFormWrapper({ djId, currentUser }: { djId: string, currentUser: User }) {
    const firestore = useFirestore();
    const storage = useStorage();
    const { toast } = useToast();

    const djProfileRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return doc(firestore, 'djProfiles', djId);
    }, [firestore, djId]);

    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);
    
    // This is the user object for the DJ being edited.
    const fakeUser = React.useMemo(() => {
        if (!djProfile) return null;
        return { uid: djId, email: djProfile.email } as User;
    }, [djId, djProfile]);

    const handleImageUploadAndUpdate = async (
        imageDataUri: string | null,
        imageType: 'profile' | 'cover'
      ) => {
        if (!imageDataUri || !storage || !djId) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Serviço de upload indisponível.' });
            return null;
        }

        const toastId = toast({ title: 'Enviando imagem...', description: 'Aguarde, por favor.' }).id;

        try {
            const filePath = `djs/${djId}/images/${imageType}-${Date.now()}.webp`;
            const fileRef = storageRef(storage, filePath);
            
            await uploadString(fileRef, imageDataUri, 'data_url');
            const downloadUrl = await getDownloadURL(fileRef);

            const profileRef = doc(firestore, 'djProfiles', djId);
            const fieldToUpdate = imageType === 'profile' ? 'profilePictureUrl' : 'coverPhotoUrl';
            await updateDocument(profileRef, { [fieldToUpdate]: downloadUrl });

            toast({ id: toastId, title: 'Sucesso!', description: 'Imagem atualizada.' });
            return downloadUrl;

        } catch (error) {
            console.error('Falha no upload da imagem:', error);
            toast({ id: toastId, variant: 'destructive', title: 'Falha no Upload', description: 'Não foi possível salvar a imagem. Tente novamente.'});
            return null;
        }
    };


    if (isProfileLoading || !firestore || !djProfile || !fakeUser) {
        return (
            <div className="flex justify-center items-center py-10">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                 <p className="ml-4 text-muted-foreground">Carregando perfil do DJ...</p>
            </div>
        );
    }
    
    return (
        <div className="max-w-2xl mx-auto">
            <DjProfileForm 
                user={fakeUser} 
                currentUser={currentUser} 
                djProfile={djProfile} 
                firestore={firestore} 
                isEditing={true}
                onImageUpload={handleImageUploadAndUpdate}
            />
        </div>
    );
}

export default function SuperAdminEditProfilePage() {
    const { user, isUserLoading } = useUser();
    const router = useRouter();
    const params = useParams();
    const djId = params.djId as string;
    const firestore = useFirestore();

    const djProfileRef = useMemoFirebase(() => {
        if (!firestore || !djId) return null;
        return doc(firestore, 'djProfiles', djId);
    }, [firestore, djId]);
    
    const { data: djProfile, isLoading: isProfileLoading } = useDoc<DjProfile>(djProfileRef);

    const currentUserProfileRef = useMemoFirebase(() => {
        if (!isUserLoading && user && firestore) {
            return doc(firestore, 'djProfiles', user.uid);
        }
        return null;
    }, [user, isUserLoading, firestore]);
    const { data: currentUserProfile, isLoading: isCurrentUserProfileLoading } = useDoc<DjProfile>(currentUserProfileRef);

    useEffect(() => {
         if (!isUserLoading && !isCurrentUserProfileLoading) {
            if (!user || (user.email !== SUPER_ADMIN_EMAIL && !currentUserProfile?.isSuperAdmin)) {
                router.push('/');
            }
        }
    }, [user, isUserLoading, currentUserProfile, isCurrentUserProfileLoading, router]);

     if (isUserLoading || isProfileLoading || isCurrentUserProfileLoading || !user) {
        return (
            <div className="flex flex-col min-h-screen bg-background">
                <Header />
                <div className="flex-1 flex justify-center items-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col min-h-screen bg-background text-white">
            <Header />
            <main className="flex-1 container mx-auto p-4 lg:p-6 space-y-8">
                 <div className="flex justify-between items-center">
                    <div className="text-left">
                         <Link href="/super-admin/painel">
                            <Button variant="ghost" className='mb-4'>
                                <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para o painel
                            </Button>
                        </Link>
                        <h1 className="text-3xl font-bold flex items-center gap-2">
                            {djProfile?.verified && <ShieldCheck className="w-6 h-6 text-blue-500" />}
                            Editando Perfil de: {djProfile?.name || '...'}
                        </h1>
                        <p className="text-muted-foreground mt-2">
                           Faça alterações no perfil deste DJ como Super Admin.
                        </p>
                    </div>
                </div>
                <AdminProfileFormWrapper djId={djId} currentUser={user} />
            </main>
            <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
            </footer>
        </div>
    );
}
