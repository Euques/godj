'use client';

import { Header } from "@/components/header";
import { Loader2, Calendar, Search, X } from "lucide-react";
import Image from 'next/image';
import type { Event } from "@/types";
import { FeaturedEventCard } from "@/components/featured-event-card";
import { useMemo, useState } from "react";
import { SimpleEventCard } from "@/components/simple-event-card";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useEvents } from "@/hooks/use-events";
import { getDay } from "date-fns";
import { getSafeDate, cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

const EVENTS_PER_PAGE = 18;

const weekDays = [
    { label: 'DOM', mobileLabel: 'D', value: 0, fullName: 'DOMINGO' },
    { label: 'SEG', mobileLabel: 'S', value: 1, fullName: 'SEGUNDA' },
    { label: 'TER', mobileLabel: 'T', value: 2, fullName: 'TERÇA' },
    { label: 'QUA', mobileLabel: 'Q', value: 3, fullName: 'QUARTA' },
    { label: 'QUI', mobileLabel: 'Q', value: 4, fullName: 'QUINTA' },
    { label: 'SEX', mobileLabel: 'S', value: 5, fullName: 'SEXTA' },
    { label: 'SAB', mobileLabel: 'S', value: 6, fullName: 'SÁBADO' },
];

export function EventCardSkeleton() {
    return (
        <div className="flex flex-col space-y-3 h-full">
            <div className="relative">
                <Skeleton className="h-auto w-full aspect-[4/3] rounded-t-lg" />
                 <div className="absolute bottom-4 left-4 space-y-2">
                    <Skeleton className="h-6 w-40" />
                    <Skeleton className="h-4 w-24" />
                 </div>
            </div>
            <div className="flex items-center space-x-4 p-4">
                 <Skeleton className="h-12 w-12 flex-shrink-0" />
                <div className="space-y-2 flex-grow">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                </div>
            </div>
        </div>
    );
}


function EventsPageContent() {
    const { events, isLoading } = useEvents();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedDay, setSelectedDay] = useState<number | null>(null);
    const [visibleCount, setVisibleCount] = useState(EVENTS_PER_PAGE);


    const filteredEvents = useMemo(() => {
        let results = events || [];

        // Filter by search term first
        if (searchTerm) {
            const lowercasedTerm = searchTerm.toLowerCase();
            results = results.filter(event => 
                event.title?.toLowerCase().includes(lowercasedTerm) ||
                event.venue?.toLowerCase().includes(lowercasedTerm) ||
                event.city?.toLowerCase().includes(lowercasedTerm) ||
                event.djName?.toLowerCase().includes(lowercasedTerm)
            );
        }

        // Then, filter by selected day
        if (selectedDay !== null) {
            results = results.filter(event => {
                const eventDate = getSafeDate(event.date);
                if (!eventDate) return false;
                return getDay(eventDate) === selectedDay;
            });
        }
        
        return results;

    }, [events, searchTerm, selectedDay]);

    const eventCountText = useMemo(() => {
        const count = filteredEvents.length;
        if (selectedDay !== null) {
            const dayName = weekDays.find(d => d.value === selectedDay)?.fullName || '';
            const eventLabel = count === 1 ? 'EVENTO' : 'EVENTOS';
            return `${count} ${eventLabel} ${dayName}`;
        }
        const eventLabel = count === 1 ? 'PRÓXIMO EVENTO' : 'PRÓXIMOS EVENTOS';
        return `${count} ${eventLabel}`;
    }, [filteredEvents, selectedDay]);
    
    const { featuredEvents, otherEvents } = useMemo(() => {
        const featured: Event[] = [];
        const others: Event[] = [];
        
        if (filteredEvents) {
            filteredEvents.forEach(event => {
                if (event.flyerUrl) {
                    featured.push(event);
                } else {
                    others.push(event);
                }
            });
        }
        
        return { featuredEvents: featured, otherEvents: others };
    }, [filteredEvents]);

    const visibleOtherEvents = useMemo(() => {
        return otherEvents.slice(0, visibleCount);
    }, [otherEvents, visibleCount]);

    const handleLoadMore = () => {
        setVisibleCount(prev => prev + EVENTS_PER_PAGE);
    }
    
     const handleSearchChange = (term: string) => {
        setSearchTerm(term);
        setVisibleCount(EVENTS_PER_PAGE);
        setSelectedDay(null);
    };

    const handleDaySelect = (day: number | null) => {
        setSelectedDay(day);
        setVisibleCount(EVENTS_PER_PAGE);
        // Clear search when a day is selected to avoid confusion
        if (day !== null && searchTerm) {
            setSearchTerm('');
        }
    };


    return (
        <div className="flex flex-col min-h-screen bg-background">
            <Header />
            <main className="flex-1 container mx-auto p-4 lg:p-6 space-y-12">
                <section>
                    <div className="text-center pt-16 md:pt-24 pb-8">
                        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-white sm:text-6xl bg-clip-text text-transparent bg-gradient-to-b from-white to-neutral-400">
                            Próximos Eventos
                        </h1>
                        <p className="mt-4 max-w-2xl mx-auto text-lg leading-8 text-muted-foreground">
                            Fique por dentro do que está rolando na cena.
                        </p>
                    </div>
                     <div className="max-w-lg mx-auto my-8 space-y-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                            <Input 
                                placeholder="Buscar por evento, local, cidade ou DJ..."
                                className="pl-10 h-11"
                                value={searchTerm}
                                onChange={(e) => handleSearchChange(e.target.value)}
                            />
                            {searchTerm && (
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                                    onClick={() => handleSearchChange('')}
                                >
                                    <X className="h-5 w-5 text-muted-foreground" />
                                </Button>
                            )}
                        </div>
                        <div className="flex flex-wrap justify-center gap-2">
                             <Button 
                                onClick={() => handleDaySelect(null)}
                                variant={selectedDay === null ? 'destructive' : 'secondary'}
                                size="sm"
                                className={cn(
                                    "rounded-full w-9 h-9 p-0",
                                    selectedDay !== null && "bg-[#151515] hover:bg-zinc-800"
                                )}
                            >
                                <Calendar className="w-4 h-4" />
                            </Button>
                            {weekDays.map(day => (
                                <Button 
                                    key={day.value}
                                    onClick={() => handleDaySelect(day.value)}
                                    variant={selectedDay === day.value ? 'destructive' : 'secondary'}
                                    size="sm"
                                   className={cn(
                                        "rounded-full text-sm h-9 w-9 sm:w-auto sm:px-3", 
                                        selectedDay !== day.value && "bg-[#151515] hover:bg-zinc-800"
                                    )}
                                >
                                    <span className="hidden sm:inline">{day.label}</span>
                                    <span className="sm:hidden">{day.mobileLabel}</span>
                                </Button>
                            ))}
                        </div>
                         <div className="flex items-center justify-center gap-2 text-sm font-semibold text-muted-foreground pt-2">
                            <Calendar className="w-4 h-4" />
                            <span>{eventCountText}</span>
                        </div>
                    </div>
                </section>

                {isLoading && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <EventCardSkeleton />
                        <EventCardSkeleton />
                        <EventCardSkeleton />
                    </div>
                )}

                {!isLoading && (!filteredEvents || filteredEvents.length === 0) && (
                    <div className="text-center py-10 px-4 rounded-lg bg-card border-border">
                        <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-white">
                            {searchTerm ? `Nenhum evento encontrado para "${searchTerm}"` : 'Nenhum evento futuro encontrado.'}
                            {selectedDay !== null && ` para este dia.`}
                        </h3>
                        <p className="text-muted-foreground mt-2">
                            {searchTerm ? 'Tente uma busca diferente ou limpe os filtros.' : 'Volte em breve para conferir as novidades!'}
                        </p>
                    </div>
                )}
                
                {!isLoading && featuredEvents.length > 0 && (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {featuredEvents.map((event, index) => (
                           event && <FeaturedEventCard key={event.id || index} event={event} />
                        ))}
                    </div>
                )}

                {!isLoading && otherEvents.length > 0 && (
                    <div className="space-y-4 pt-8">
                        <div className="flex items-center gap-4">
                            <Separator className="flex-1 bg-zinc-700" />
                            <h3 className="text-center font-semibold text-muted-foreground tracking-widest text-sm">
                                {featuredEvents.length > 0 ? 'OUTROS EVENTOS' : 'EVENTOS'}
                            </h3>
                            <Separator className="flex-1 bg-zinc-700" />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                           {visibleOtherEvents.map((event) => (
                                event && <SimpleEventCard key={event.id} event={event} />
                            ))}
                        </div>
                        
                        {visibleCount < otherEvents.length && (
                            <div className="text-center pt-8">
                                <Button onClick={handleLoadMore}>
                                    Carregar Mais
                                </Button>
                            </div>
                        )}
                    </div>
                )}

            </main>
            <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                    href="https://wabes.com.br" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                    © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
            </footer>
        </div>
    );
}


export default function EventosPage() {
    return (
        <EventsPageContent />
    );
}
