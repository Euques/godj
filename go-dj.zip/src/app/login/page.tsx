'use client';
import { AuthForm } from "@/components/auth-form";
import { Header } from "@/components/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";

export default function LoginPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-black border-zinc-800">
            <CardHeader>
                <CardTitle>Acesso Restrito</CardTitle>
                <CardDescription>
                    Faça login para gerenciar seu perfil de DJ.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <AuthForm authType="login" />
            </CardContent>
        </Card>
      </main>
      <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
        <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
        <a 
          href="https://wabes.com.br" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
        >
          © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
        </a>
      </footer>
    </div>
  );
}
