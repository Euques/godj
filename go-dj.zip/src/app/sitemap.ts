import { MetadataRoute } from 'next';
import { getAdminSdks } from '@/firebase/server';
import { generateSlug } from '@/lib/utils';

export const dynamic = 'force-dynamic';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = 'https://godj.com.br';
  
  const staticRoutes = [
    '',
    '/eventos',
    '/djs',
    '/login',
    '/signup',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'daily' as const,
    priority: route === '' ? 1 : 0.8,
  }));

  try {
      const { firestore } = getAdminSdks();
      if (!firestore) return staticRoutes;

      const snapshot = await firestore.collection('djProfiles').get();
      
      const djRoutes: MetadataRoute.Sitemap = [];

      for (const doc of snapshot.docs) {
          const data = doc.data();
          const slug = data.slug || doc.id;
          const djUrl = data.customDomain 
            ? `https://${data.customDomain.replace(/\/$/, '')}` 
            : `${baseUrl}/${slug}`;
          
          const lastMod = data.updatedAt?.toDate?.() || data.createdAt?.toDate?.() || new Date();
          
          djRoutes.push({
            url: djUrl,
            lastModified: lastMod,
            changeFrequency: 'weekly' as const,
            priority: 0.7,
          });

          // Fetch products for each DJ
          try {
            const productsSnap = await firestore.collection('djProfiles').doc(doc.id).collection('products').get();
            productsSnap.forEach((pDoc) => {
              const pData = pDoc.data();
              if (pData.title) {
                const pSlug = generateSlug(pData.title);
                djRoutes.push({
                  url: `${djUrl}/produto/${pSlug}`,
                  lastModified: pData.lastUpdatedAt?.toDate?.() || lastMod,
                  changeFrequency: 'weekly' as const,
                  priority: 0.6,
                });
              }
            });
          } catch (e) {
            // Ignore subcollection errors
          }
      }

      return [...staticRoutes, ...djRoutes];
  } catch (error) {
      return staticRoutes;
  }
}
