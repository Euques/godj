
import { redirect } from 'next/navigation';

// Esta rota antiga agora redireciona para a nova URL curta na raiz
export default async function OldDjProfilePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  redirect(`/${slug}`);
}
