'use client';

import { useEffect, useState, useMemo } from 'react';
import type { DjProfile } from '@/types';
import { Header } from '@/components/header';
import Image from 'next/image';
import { Loader2, Search, MapPin, Calendar, ShieldCheck, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Link from 'next/link';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { ManagedImage } from '@/components/managed-image';
import { useDjs } from '@/hooks/use-djs'; // Importa o novo hook
import { Skeleton } from '@/components/ui/skeleton';

function DjCardSkeleton() {
    return (
      <div className="flex flex-col space-y-3 h-full">
        <div className="relative">
            <Skeleton className="h-auto w-full aspect-[2/1] rounded-t-lg" />
            <div className="absolute inset-x-0 -bottom-14 flex justify-center">
                <Skeleton className="h-28 w-28 rounded-full border-4 border-card" />
            </div>
        </div>
        <div className="space-y-2 text-center flex flex-col items-center pt-16 flex-grow p-4">
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
        </div>
      </div>
    );
}


function DjCard({ dj }: { dj: DjProfile }) {
    const eventCount = dj.eventCount || 0;
    return (
        <Link href={`/${dj.slug}`} className="block group">
            <Card className="overflow-hidden bg-card h-full transition-all duration-300 hover:bg-zinc-800/50 hover:border-zinc-700">
                <div className="relative aspect-[2/1]">
                    <ManagedImage
                        src={dj.coverPhotoUrl || 'https://picsum.photos/seed/placeholder-lg/800/800'}
                        alt={dj.name || 'Capa do DJ'}
                        fill
                        className="object-cover object-top"
                        data-ai-hint="dj banner"
                    />
                         <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
                        <div className="absolute top-3 left-3 flex items-center gap-2">
                             {eventCount > 0 && (
                                <div className="flex items-center gap-1.5 bg-red-600/90 backdrop-blur-sm text-white font-bold text-xs px-2 py-1 rounded-full">
                                    <Calendar className="w-4 h-4" />
                                    <span>{eventCount}</span>
                                </div>
                            )}
                            {dj.verified && (
                                <div className="flex items-center justify-center bg-blue-500/80 backdrop-blur-sm text-white font-bold text-xs p-1.5 rounded-full">
                                    <ShieldCheck className="w-4 h-4" />
                                </div>
                            )}
                        </div>
                    <div className="absolute inset-x-0 -bottom-14 flex justify-center">
                        <Avatar className="h-28 w-28 border-4 border-card shadow-lg transition-transform duration-300 group-hover:scale-105">
                            <AvatarImage src={dj.profilePictureUrl} data-ai-hint="dj portrait" />
                            <AvatarFallback>{dj.name ? dj.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                        </Avatar>
                    </div>
                </div>
                <CardContent className="p-4 pt-16 text-center">
                    <h3 className="text-xl font-bold truncate text-white">{dj.name || 'DJ sem nome'}</h3>
                    {dj.location && (
                        <div className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground mt-1">
                            <MapPin className="w-4 h-4" />
                            <span className="truncate">{dj.location}</span>
                        </div>
                    )}
                </CardContent>
            </Card>
        </Link>
    );
}


function CompactDjCard({ dj }: { dj: DjProfile }) {
    const eventCount = dj.eventCount || 0;
    return (
        <Card className="bg-card hover:bg-zinc-800/50">
            <Link href={`/${dj.slug}`} className="block group p-3">
                <div className="flex items-center gap-4">
                    <Avatar className="h-14 w-14 border-2 border-zinc-700">
                        <AvatarImage src={dj.profilePictureUrl} data-ai-hint="dj portrait" />
                        <AvatarFallback>{dj.name ? dj.name.substring(0, 2) : 'DJ'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                            {dj.verified && <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0" />}
                            <h4 className="font-bold truncate text-white">{dj.name || 'DJ sem nome'}</h4>
                        </div>
                        {dj.location && (
                            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                                <MapPin className="w-3 h-3" />
                                <span className="truncate">{dj.location}</span>
                            </div>
                        )}
                    </div>
                    {eventCount > 0 && (
                        <div className="flex items-center gap-1.5 bg-red-600 text-white font-bold text-xs px-2 py-1 rounded-full shrink-0">
                            <Calendar className="w-4 h-4" />
                            <span>{eventCount}</span>
                        </div>
                    )}
                </div>
            </Link>
        </Card>
    )
}

const INITIAL_LOAD = 15;
const LOAD_MORE_COUNT = 16;

function DjsPageContent() {
    const { djs: allDjs, isLoading } = useDjs(); // Usa o novo hook
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedTag, setSelectedTag] = useState<string | null>(null);
    const [visibleCount, setVisibleCount] = useState(INITIAL_LOAD);
    
    const allTags = useMemo(() => {
        const tagCounts = new Map<string, number>();
        allDjs.forEach(dj => {
            dj.tags?.forEach(tag => {
                if (tag) {
                   tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
                }
            });
        });
        
        return Array.from(tagCounts.entries())
            .sort(([, countA], [, countB]) => countB - countA)
            .map(([tag]) => tag);

    }, [allDjs]);

    const filteredDjs = useMemo(() => {
        return allDjs.filter(dj => {
            const lowercasedTerm = searchTerm.toLowerCase();
            const matchesSearchTerm = !searchTerm ||
                dj.name?.toLowerCase().includes(lowercasedTerm) ||
                dj.location?.toLowerCase().includes(lowercasedTerm);
            
            const matchesTag = !selectedTag || dj.tags?.includes(selectedTag);

            return matchesSearchTerm && matchesTag;
        });
    }, [allDjs, searchTerm, selectedTag]);

    useEffect(() => {
        setVisibleCount(INITIAL_LOAD);
    }, [searchTerm, selectedTag]);
    
    const visibleDjs = useMemo(() => {
        return filteredDjs.slice(0, visibleCount);
    }, [filteredDjs, visibleCount]);

    const featuredDjs = visibleDjs.slice(0, 3);
    const otherDjs = visibleDjs.slice(3);

    const noResultsMessage = useMemo(() => {
        if (allDjs.length === 0) {
            return "Nenhum DJ cadastrado ainda.";
        }
        if (searchTerm && selectedTag) {
            return `Nenhum DJ encontrado para "${searchTerm}" na tag "${selectedTag}".`;
        }
        if (searchTerm) {
            return `Nenhum DJ encontrado para "${searchTerm}".`;
        }
        if (selectedTag) {
            return `Nenhum DJ encontrado na tag "${selectedTag}".`;
        }
        return "Nenhum DJ encontrado para sua busca.";
    }, [allDjs.length, searchTerm, selectedTag]);

    const handleLoadMore = () => {
        setVisibleCount(prev => prev + LOAD_MORE_COUNT);
    }


    return (
        <div className="flex flex-col min-h-screen bg-background">
            <Header />
            <main className="flex-1 container mx-auto p-4 lg:p-6 space-y-8">
                <div className="space-y-4 text-center">
                    <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Encontre DJs</h1>
                    <p className="max-w-2xl mx-auto text-muted-foreground">
                        Procure por nome, gênero musical, cidade ou descubra novos artistas.
                    </p>
                </div>

                <div className="max-w-2xl mx-auto space-y-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                        <Input 
                            placeholder="Buscar por nome ou cidade..."
                            className="pl-10 h-12"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        {searchTerm && (
                            <Button 
                                variant="ghost" 
                                size="icon" 
                                className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                                onClick={() => setSearchTerm('')}
                            >
                                <X className="h-5 w-5 text-muted-foreground" />
                            </Button>
                        )}
                    </div>
                     {allTags.length > 0 && (
                        <ScrollArea className="w-full whitespace-nowrap rounded-md">
                            <div className="flex w-max space-x-2 p-2">
                                 <Button
                                    variant={selectedTag === null ? 'default' : 'secondary'}
                                    size="sm"
                                    onClick={() => setSelectedTag(null)}
                                    className="rounded-full"
                                >
                                    Todos
                                </Button>
                                {allTags.map(tag => (
                                    <Button 
                                        key={tag}
                                        variant={selectedTag === tag ? 'default' : 'secondary'}
                                        size="sm"
                                        onClick={() => setSelectedTag(tag)}
                                        className="rounded-full"
                                    >
                                        {tag}
                                    </Button>
                                ))}
                            </div>
                            <ScrollBar orientation="horizontal" />
                        </ScrollArea>
                    )}
                </div>

                 {isLoading && (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <DjCardSkeleton />
                        <DjCardSkeleton />
                        <DjCardSkeleton />
                    </div>
                )}
                {!isLoading && filteredDjs.length === 0 && (
                    <p className="text-muted-foreground text-center py-10">
                        {noResultsMessage}
                    </p>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {!isLoading && featuredDjs.map((dj) => (
                        dj && <DjCard key={dj.id} dj={dj} />
                    ))}
                </div>
                 {otherDjs.length > 0 && (
                    <div className="space-y-4 pt-8">
                        <div className="flex items-center gap-4">
                            <Separator className="flex-1 bg-zinc-700" />
                            <h3 className="text-center font-semibold text-muted-foreground tracking-widest text-sm">OUTROS DEEJAYS</h3>
                            <Separator className="flex-1 bg-zinc-700" />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                           {!isLoading && otherDjs.map((dj) => (
                                dj && <CompactDjCard key={dj.id} dj={dj} />
                            ))}
                        </div>
                    </div>
                )}
                
                {!isLoading && visibleCount < filteredDjs.length && (
                    <div className="text-center pt-8">
                        <Button onClick={handleLoadMore}>Carregar mais</Button>
                    </div>
                )}
            </main>
             <footer className="py-8 text-center flex flex-col items-center justify-center gap-4">
                <Image src="/logo.png" alt="Logo GoDJ" width={100} height={33} className="brightness-0 invert" />
                <a 
                  href="https://wabes.com.br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
                >
                  © {new Date().getFullYear()} - GODJ BY WABES - TODOS OS DIREITOS RESERVADOS
                </a>
              </footer>
        </div>
    );
}

export default function DjsPage() {
    return (
        <DjsPageContent />
    );
}