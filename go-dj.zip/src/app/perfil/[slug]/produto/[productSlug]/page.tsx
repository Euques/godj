import React from 'react';
import { Metadata } from 'next';
import { getAdminSdks } from '@/firebase/server';
import { Header } from '@/components/header';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ShoppingBag, ArrowLeft, ShieldCheck, Tag, Star } from 'lucide-react';
import Link from 'next/link';
import { ManagedImage } from '@/components/managed-image';
import { generateSlug } from '@/lib/utils';
import { ProductShareButton } from '@/components/product-share-button';
import { ProductBuyButton } from '@/components/product-buy-button';
import { Footer } from '@/components/footer';

export const dynamic = 'force-dynamic';

type Props = {
  params: Promise<{ slug: string; productSlug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug, productSlug } = await params;
  const baseUrl = 'https://godj.com.br';

  const defaultMeta: Metadata = {
    title: 'GoDJ - Produto',
    description: 'Confira este produto na loja GoDJ.',
    openGraph: {
      title: 'GoDJ - Produto',
      images: [`${baseUrl}/tumb.jpg`],
    },
  };

  try {
    const { firestore } = getAdminSdks();
    if (!firestore) return defaultMeta;

    const normalizedIdentifier = slug.toLowerCase().trim().replace(/^\/+|\/+$/g, '').replace(/^www\./, '');

    let snapshot = await firestore.collection('djProfiles').where('slug', '==', normalizedIdentifier).limit(1).get();
    if (snapshot.empty) {
      snapshot = await firestore.collection('djProfiles').where('customDomain', '==', normalizedIdentifier).limit(1).get();
    }

    if (snapshot.empty) return defaultMeta;

    const djDoc = snapshot.docs[0];
    const djData = djDoc.data();
    const djId = djDoc.id;

    const productsSnap = await firestore.collection('djProfiles').doc(djId).collection('products').get();
    let productData: any = null;
    productsSnap.forEach(docSnap => {
      const data = docSnap.data();
      const pSlug = data.title ? generateSlug(data.title) : '';
      if (pSlug === productSlug || docSnap.id === productSlug) {
        productData = data;
      }
    });

    if (!productData) return defaultMeta;

    const title = productData.title || 'Produto';
    const price = typeof productData.price === 'number' 
      ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(productData.price)
      : '';
    const djName = djData.name || 'DJ';
    const photo = productData.imageUrl || djData.profilePictureUrl || `${baseUrl}/tumb.jpg`;
    const description = productData.description 
      ? productData.description.substring(0, 160)
      : `Confira ${title} (${price}) na loja oficial de Dj ${djName} no GoDJ.`;

    const metaTitle = `${title} ${price ? `(${price})` : ''} - Dj ${djName} | GoDJ`;

    return {
      title: metaTitle,
      description: description,
      openGraph: {
        title: metaTitle,
        description: description,
        url: `${baseUrl}/${slug}/produto/${productSlug}`,
        siteName: 'GoDJ',
        images: [{ url: photo, width: 800, height: 800, alt: title }],
        type: 'website',
      },
      twitter: {
        card: 'summary_large_image',
        title: metaTitle,
        description: description,
        images: [photo],
      },
    };
  } catch (error) {
    console.error("[Product Metadata Error]", error);
    return defaultMeta;
  }
}

export default async function ProductDetailPage({ params }: Props) {
  const { slug, productSlug } = await params;

  let dj: any = null;
  let product: any = null;

  try {
    const { firestore } = getAdminSdks();
    if (firestore) {
      const normalizedIdentifier = slug.toLowerCase().trim().replace(/^\/+|\/+$/g, '').replace(/^www\./, '');
      let snapshot = await firestore.collection('djProfiles').where('slug', '==', normalizedIdentifier).limit(1).get();
      if (snapshot.empty) {
        snapshot = await firestore.collection('djProfiles').where('customDomain', '==', normalizedIdentifier).limit(1).get();
      }

      if (!snapshot.empty) {
        const djDoc = snapshot.docs[0];
        dj = { id: djDoc.id, ...djDoc.data() };

        const productsSnap = await firestore.collection('djProfiles').doc(dj.id).collection('products').get();
        productsSnap.forEach(docSnap => {
          const pData = docSnap.data();
          const pSlug = pData.title ? generateSlug(pData.title) : '';
          if (pSlug === productSlug || docSnap.id === productSlug) {
            product = { id: docSnap.id, ...pData };
          }
        });
      }
    }
  } catch (e) {
    console.error("Error loading product detail:", e);
  }

  if (!dj || !product) {
    return (
      <div className="flex flex-col min-h-screen bg-background text-white">
        <Header />
        <main className="flex-1 container mx-auto p-6 flex flex-col items-center justify-center text-center">
          <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
          <p className="text-muted-foreground mb-6">Este produto pode ter sido removido ou o link está incorreto.</p>
          <Link href={`/${slug}`}>
            <Button variant="secondary">
              <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para a Loja
            </Button>
          </Link>
        </main>
      </div>
    );
  }

  const formattedPrice = typeof product.price === 'number'
    ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price)
    : 'R$ 0,00';

  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <Header />
      <main className="flex-1 container mx-auto p-4 lg:p-8 max-w-4xl space-y-8">
        <div className="flex items-center">
          <Link href={`/${slug}`}>
            <Button variant="ghost" className="text-muted-foreground hover:text-white p-0 hover:bg-transparent text-sm font-medium">
              <ArrowLeft className="mr-2 h-4 w-4 shrink-0" /> Voltar para a loja de {dj.name}
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          {product.imageUrl ? (
            <div className="relative w-full aspect-square rounded-2xl overflow-hidden border border-zinc-800 bg-black/60 flex items-center justify-center shadow-2xl">
              <ManagedImage
                src={product.imageUrl}
                alt={product.title}
                fill
                className="object-cover"
                priority
              />
              {product.featured && (
                <div className="absolute top-3 right-3 bg-yellow-500/90 text-black px-3 py-1 rounded-full text-xs font-semibold shadow-md">
                  DESTAQUE
                </div>
              )}
            </div>
          ) : (
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden border border-zinc-800 bg-card/50 flex flex-col items-center justify-center p-6 text-center">
              <ShoppingBag className="w-20 h-20 text-muted-foreground/40 mb-4" />
              <h2 className="text-xl font-bold">{product.title}</h2>
            </div>
          )}

          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <Link href={`/${slug}`} className="flex items-center gap-2 group">
                  <Avatar className="h-10 w-10 border border-zinc-700">
                    <AvatarImage src={dj.profilePictureUrl} />
                    <AvatarFallback>{dj.name?.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="font-semibold group-hover:text-primary transition-colors flex items-center gap-1.5">
                    {dj.name}
                    {dj.verified && <ShieldCheck className="w-4 h-4 text-blue-500" />}
                  </span>
                </Link>
              </div>

              {product.category && (
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-zinc-800 text-zinc-300 mb-2">
                  <Tag className="w-3 h-3 text-primary" />
                  {product.category}
                </div>
              )}

              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mb-3">{product.title}</h1>
              
              <div className="text-3xl font-extrabold text-primary tracking-tight">
                {formattedPrice}
              </div>
            </div>

            {product.description && (
              <Card className="bg-card/60 border-zinc-800">
                <CardContent className="p-6 space-y-2">
                  <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Descrição do Produto</h3>
                  <p className="text-white/90 whitespace-pre-wrap leading-relaxed font-medium text-sm sm:text-base">
                    {product.description}
                  </p>
                </CardContent>
              </Card>
            )}

            <div className="space-y-3 pt-2">
              <ProductBuyButton
                whatsapp={dj.whatsapp}
                djName={dj.name}
                productTitle={product.title}
                formattedPrice={formattedPrice}
              />
              <ProductShareButton title={product.title} djName={dj.name} variant="outline" className="w-full h-11" />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
