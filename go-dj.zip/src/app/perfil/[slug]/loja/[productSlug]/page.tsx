import ProductDetailPage, { generateMetadata as genMeta } from '@/app/perfil/[slug]/produto/[productSlug]/page';

export const dynamic = 'force-dynamic';

export const generateMetadata = genMeta;
export default ProductDetailPage;
