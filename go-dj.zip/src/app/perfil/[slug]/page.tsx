import React, { Suspense } from 'react';
import { Metadata } from 'next';
import { getAdminSdks } from '@/firebase/server';
import DjProfilePageClient from '@/components/dj/profile-page-client';
import { Loader2 } from 'lucide-react';

export const dynamic = 'force-dynamic';

type Props = {
  params: Promise<{ slug: string }>;
};

/**
 * Injeta metadados dinâmicos no <head> para Google e WhatsApp.
 * Executa no servidor antes de enviar o HTML.
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const baseUrl = 'https://godj.com.br';
  
  const defaultMeta: Metadata = {
    title: 'GoDJ - Domine a Cena',
    description: 'Encontre os melhores DJs e eventos.',
    openGraph: {
      title: 'GoDJ - Domine a Cena',
      images: [`${baseUrl}/tumb.jpg`],
    },
  };
  
  try {
      const { firestore } = getAdminSdks();
      if (!firestore) return defaultMeta;

      const normalizedIdentifier = slug.toLowerCase().trim().replace(/^\/+|\/+$/g, '').replace(/^www\./, '');

      // Busca o DJ por slug ou domínio personalizado no Firestore Admin
      let snapshot = await firestore.collection('djProfiles').where('slug', '==', normalizedIdentifier).limit(1).get();
      if (snapshot.empty) {
          snapshot = await firestore.collection('djProfiles').where('customDomain', '==', normalizedIdentifier).limit(1).get();
      }

      if (snapshot.empty) return defaultMeta;

      const dj = snapshot.docs[0].data();
      const name = dj.name || 'Deejay';
      const city = dj.location || '';
      const genres = dj.tags?.join(', ') || '';
      const photo = dj.profilePictureUrl || `${baseUrl}/tumb.jpg`;
      
      // Título Rico: Dj [Nome] em [Cidade] - Gêneros: [Tags]
      const metaTitle = `Dj ${name}${city ? ` em ${city}` : ''}${genres ? ` - Gêneros: ${genres}` : ''}`;
      const metaDescription = dj.bio 
        ? (dj.bio.length > 160 ? dj.bio.substring(0, 157) + '...' : dj.bio) 
        : `Confira a agenda e produtos de Dj ${name} no GoDJ.`;

      return {
        title: metaTitle,
        description: metaDescription,
        openGraph: {
          title: metaTitle,
          description: metaDescription,
          url: `${baseUrl}/${dj.slug || slug}`,
          siteName: 'GoDJ',
          images: [{ url: photo, width: 600, height: 600, alt: name }],
          type: 'website',
        },
        twitter: {
          card: 'summary_large_image',
          title: metaTitle,
          description: metaDescription,
          images: [photo],
        },
      };
  } catch (error) {
      console.error("[Metadata Error]", error);
      return defaultMeta;
  }
}

export default async function Page({ params }: Props) {
  const { slug } = await params;
  
  return (
    <Suspense fallback={
        <div className="flex flex-col min-h-screen bg-background items-center justify-center">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
    }>
        <DjProfilePageClient slug={slug} />
    </Suspense>
  );
}
