import React from 'react';
import { Metadata } from 'next';
import { getAdminSdks } from '@/firebase/server';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Calendar, MapPin, Clock, ExternalLink, ArrowLeft, ShieldCheck, Info } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ManagedImage } from '@/components/managed-image';
import { generateSlug } from '@/lib/utils';
import { EventShareButton } from '@/components/event-share-button';
import { EventFlyer } from '@/components/event-flyer';

export const dynamic = 'force-dynamic';

type Props = {
  params: Promise<{ slug: string; eventSlug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug, eventSlug } = await params;
  const baseUrl = 'https://godj.com.br';

  const defaultMeta: Metadata = {
    title: 'GoDJ - Evento',
    description: 'Confira os detalhes deste evento no GoDJ.',
    openGraph: {
      title: 'GoDJ - Evento',
      images: [`${baseUrl}/tumb.jpg`],
    },
  };

  try {
    const { firestore } = getAdminSdks();
    if (!firestore) return defaultMeta;

    const normalizedIdentifier = slug.toLowerCase().trim().replace(/^\/+|\/+$/g, '').replace(/^www\./, '');

    let snapshot = await firestore.collection('djProfiles').where('slug', '==', normalizedIdentifier).limit(1).get();
    if (snapshot.empty) {
      snapshot = await firestore.collection('djProfiles').where('customDomain', '==', normalizedIdentifier).limit(1).get();
    }

    if (snapshot.empty) return defaultMeta;

    const djDoc = snapshot.docs[0];
    const djData = djDoc.data();
    const djId = djDoc.id;

    const agendaSnap = await firestore.collection('djProfiles').doc(djId).collection('agenda').get();
    let eventData: any = null;
    agendaSnap.forEach(docSnap => {
      const data = docSnap.data();
      if (data.title && generateSlug(data.title) === eventSlug) {
        eventData = data;
      }
    });

    if (!eventData) return defaultMeta;

    const title = eventData.title || 'Evento';
    const venue = eventData.venue || '';
    const city = eventData.city || '';
    const djName = djData.name || 'DJ';
    const photo = eventData.flyerUrl || djData.profilePictureUrl || `${baseUrl}/tumb.jpg`;

    let dateStr = '';
    if (eventData.date) {
      const d = eventData.date.toDate ? eventData.date.toDate() : new Date(eventData.date);
      if (!isNaN(d.getTime())) {
        dateStr = format(d, "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
      }
    }

    const metaTitle = `${title} - Dj ${djName}${venue ? ` em ${venue}` : ''} | GoDJ`;
    const metaDescription = `Data: ${dateStr || 'Em breve'}${city ? ` | Local: ${venue}, ${city}` : ''}. Confira a agenda de Dj ${djName} no GoDJ.`;

    return {
      title: metaTitle,
      description: metaDescription,
      openGraph: {
        title: metaTitle,
        description: metaDescription,
        url: `${baseUrl}/${slug}/evento/${eventSlug}`,
        siteName: 'GoDJ',
        images: [{ url: photo, width: 800, height: 800, alt: title }],
        type: 'website',
      },
      twitter: {
        card: 'summary_large_image',
        title: metaTitle,
        description: metaDescription,
        images: [photo],
      },
    };
  } catch (error) {
    console.error("[Event Metadata Error]", error);
    return defaultMeta;
  }
}

export default async function EventDetailPage({ params }: Props) {
  const { slug, eventSlug } = await params;

  let dj: any = null;
  let event: any = null;
  let allDjEvents: any[] = [];

  try {
    const { firestore } = getAdminSdks();
    if (firestore) {
      const normalizedIdentifier = slug.toLowerCase().trim().replace(/^\/+|\/+$/g, '').replace(/^www\./, '');
      let snapshot = await firestore.collection('djProfiles').where('slug', '==', normalizedIdentifier).limit(1).get();
      if (snapshot.empty) {
        snapshot = await firestore.collection('djProfiles').where('customDomain', '==', normalizedIdentifier).limit(1).get();
      }

      if (!snapshot.empty) {
        const djDoc = snapshot.docs[0];
        dj = { id: djDoc.id, ...djDoc.data() };

        const agendaSnap = await firestore.collection('djProfiles').doc(dj.id).collection('agenda').orderBy('date', 'asc').get();
        agendaSnap.forEach(docSnap => {
          const evData = docSnap.data();
          if (evData.title) {
            let parsedDate = null;
            if (evData.date) {
              const d = evData.date.toDate ? evData.date.toDate() : new Date(evData.date);
              if (!isNaN(d.getTime())) {
                parsedDate = d.toISOString();
              }
            }
            const evSlug = generateSlug(evData.title);
            const item = { id: docSnap.id, ...evData, date: parsedDate, slug: evSlug };
            allDjEvents.push(item);
            if (evSlug === eventSlug) {
              event = item;
            }
          }
        });
      }
    }
  } catch (e) {
    console.error("Error loading event detail:", e);
  }

  if (!dj || !event) {
    return (
      <div className="flex flex-col min-h-screen bg-background text-white">
        <Header />
        <main className="flex-1 container mx-auto p-6 flex flex-col items-center justify-center text-center">
          <h1 className="text-2xl font-bold mb-4">Evento não encontrado</h1>
          <p className="text-muted-foreground mb-6">Este evento pode ter sido removido ou o link está incorreto.</p>
          <Link href={`/${slug}`}>
            <Button variant="secondary">
              <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para o Perfil
            </Button>
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  let formattedDate = '';
  if (event.date) {
    const d = new Date(event.date);
    if (!isNaN(d.getTime())) {
      formattedDate = format(d, "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR });
    }
  }

  const otherEvents = allDjEvents.filter(e => e.id !== event.id);

  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <Header />
      <main className="flex-1 container mx-auto p-4 lg:p-8 max-w-4xl space-y-8">
        <div className="flex justify-between items-center">
          <Link href={`/${slug}`}>
            <Button variant="ghost" className="text-muted-foreground hover:text-white p-0 hover:bg-transparent">
              <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para o perfil de {dj.name}
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          {/* Flyer section */}
          <EventFlyer flyerUrl={event.flyerUrl} title={event.title} />

          {/* Event info section */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <Link href={`/${slug}`} className="flex items-center gap-2 group">
                  <Avatar className="h-10 w-10 border border-zinc-700">
                    <AvatarImage src={dj.profilePictureUrl} />
                    <AvatarFallback>{dj.name?.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="font-semibold group-hover:text-primary transition-colors flex items-center gap-1.5">
                    {dj.name}
                    {dj.verified && <ShieldCheck className="w-4 h-4 text-blue-500" />}
                  </span>
                </Link>
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mb-2">{event.title}</h1>
            </div>

            <Card className="bg-card/60 border-zinc-800">
              <CardContent className="p-6 space-y-5">
                {formattedDate && (
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-white shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">Data e Horário</p>
                      <p className="font-medium text-white text-base">{formattedDate}</p>
                    </div>
                  </div>
                )}

                {event.description && (
                  <div className="space-y-1 pt-2 border-t border-zinc-800/80">
                    <div className="flex items-center gap-2 text-white font-semibold mb-1">
                      <Info className="w-4 h-4 text-white shrink-0" />
                      <span>Sobre o Evento</span>
                    </div>
                    <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed text-sm sm:text-base">
                      {event.description}
                    </p>
                  </div>
                )}

                {(event.venue || event.address || event.city) && (
                  <div className="flex items-start gap-3 pt-2 border-t border-zinc-800/80">
                    <MapPin className="w-5 h-5 text-white shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Endereço Completo</p>
                      {event.venue && <p className="font-semibold text-white text-base">{event.venue}</p>}
                      {event.address && <p className="text-sm text-white/90">{event.address}</p>}
                      {event.city && <p className="text-sm text-muted-foreground">{event.city}</p>}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Action buttons */}
            <div className="flex flex-col gap-3 pt-2">
              {event.url && (
                <a href={event.url} target="_blank" rel="noopener noreferrer" className="w-full">
                  <Button className="w-full h-12 text-base font-medium bg-white hover:bg-zinc-200 text-black shadow-lg transition-all active:scale-[0.99] rounded-full border-0">
                    GO - Ir para o Link
                  </Button>
                </a>
              )}

              {(event.address || event.venue) && (
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(event.address || `${event.venue || ''} ${event.city || ''}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full"
                >
                  <Button className="w-full h-12 text-base font-medium bg-zinc-800 hover:bg-zinc-700 text-white transition-all rounded-full border-0 shadow-none">
                    <MapPin className="mr-2 h-5 w-5 text-white" /> Como Chegar
                  </Button>
                </a>
              )}

              <EventShareButton
                title={event.title}
                djName={dj.name}
                className="w-full h-12 text-base font-medium bg-zinc-800 hover:bg-zinc-700 text-white transition-all rounded-full border-0 shadow-none"
              />
            </div>
          </div>
        </div>

        {/* Section: Card do DJ */}
        <section className="pt-10 border-t border-zinc-800/80">
          <Card className="bg-card/70 border-zinc-800/90 rounded-2xl overflow-hidden shadow-xl">
            {dj.coverPhotoUrl && (
              <div className="relative w-full h-32 sm:h-44 bg-zinc-900 overflow-hidden">
                <ManagedImage
                  src={dj.coverPhotoUrl}
                  alt={dj.name}
                  fill
                  className="object-cover opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
              </div>
            )}

            <CardContent className={`p-6 sm:p-8 relative ${dj.coverPhotoUrl ? '-mt-12 sm:-mt-16' : ''}`}>
              <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-5">
                <Avatar className="h-24 w-24 sm:h-28 sm:w-28 border-4 border-card shadow-2xl shrink-0">
                  <AvatarImage src={dj.profilePictureUrl} alt={dj.name} />
                  <AvatarFallback className="text-2xl font-bold bg-zinc-800 text-white">
                    {dj.name?.substring(0, 2)?.toUpperCase() || 'DJ'}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 space-y-3 min-w-0 w-full">
                  <div>
                    <div className="flex items-center justify-center sm:justify-start gap-2">
                      <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">{dj.name}</h2>
                      {dj.verified && (
                        <ShieldCheck className="w-5 h-5 text-blue-500 shrink-0" />
                      )}
                    </div>
                    {dj.location && (
                      <p className="text-sm text-muted-foreground flex items-center justify-center sm:justify-start gap-1 mt-1">
                        <MapPin className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                        <span>{dj.location}</span>
                      </p>
                    )}
                  </div>

                  {dj.bio && (
                    <p className="text-sm text-zinc-300 line-clamp-3 leading-relaxed max-w-2xl">
                      {dj.bio}
                    </p>
                  )}

                  <div className="pt-2 flex justify-center sm:justify-start">
                    <Link href={`/${slug}`}>
                      <Button className="px-6 h-11 bg-white hover:bg-zinc-200 text-black font-medium rounded-full shadow-md transition-all active:scale-[0.99]">
                        Ver perfil completo do DJ
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
      <Footer />
    </div>
  );
}
