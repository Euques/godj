'use client';
import { Header } from "@/components/header";
import { FeaturedDjs } from "@/components/featured-djs";
import Image from 'next/image';
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { Loader2 } from "lucide-react";
import { FeaturedEvents } from "@/components/featured-events";
import { NewDjs } from "@/components/new-djs";
import { OtherDjs } from "@/components/other-djs";
import { useUser } from "@/firebase";
import { Footer } from "@/components/footer";


export default function Home() {
  const { user, isUserLoading } = useUser();

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 container mx-auto px-4 lg:px-6 space-y-12">
        <section>
          <div className="text-center py-16 md:py-24">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-white sm:text-6xl bg-clip-text text-transparent bg-gradient-to-b from-white to-neutral-400">
              Domine a Cena
            </h1>
            <p className="mt-4 max-w-2xl mx-auto text-lg leading-8 text-muted-foreground">
              Encontre os eventos, descubra novos talentos e conecte-se com a comunidade. Sua agenda de DJs, em um só lugar.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                {isUserLoading ? (
                  <div className="h-11 w-full sm:w-auto" /> 
                ) : !user ? (
                  <>
                    <Link href="/login" className="w-full sm:w-auto">
                      <Button size="lg" className="w-full">Entrar</Button>
                    </Link>
                    <Link href="/signup" className="w-full sm:w-auto">
                        <Button variant="secondary" size="lg" className="w-full">Cadastrar</Button>
                    </Link>
                  </>
                ) : null}
                <Link href="/djs" className="w-full sm:w-auto">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto border-foreground/50 hover:bg-foreground/10 rounded-full">
                    Encontrar DJs
                  </Button>
                </Link>
            </div>
          </div>
        </section>

        <section id="featured-events">
          <FeaturedEvents />
        </section>

        <section id="featured-djs">
          <FeaturedDjs />
        </section>

        <section id="new-djs">
          <NewDjs />
        </section>

        <section id="other-djs">
            <OtherDjs />
        </section>
      </main>
      <Footer />
    </div>
  );
}
