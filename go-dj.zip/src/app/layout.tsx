
import type { Metadata } from 'next';
import { Space_Grotesk, Barlow_Condensed } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { FirebaseClientProvider } from '@/firebase/client-provider';

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
});

const barlowCondensed = Barlow_Condensed({
  weight: ['400', '500', '600', '700', '800'],
  subsets: ['latin'],
  variable: '--font-barlow-condensed',
});

export const metadata: Metadata = {
  title: 'GoDJ - Domine a Cena',
  description: 'A plataforma para encontrar os próximos eventos dos seus DJs favoritos.',
  icons: {
    icon: 'https://godj.com.br/favicon.png',
  },
  openGraph: {
    title: 'GoDJ - Domine a Cena',
    description: 'Encontre os eventos, descubra novos talentos e conecte-se com a comunidade. Sua agenda de DJs, em um só lugar.',
    url: 'https://godj.com.br',
    siteName: 'GoDJ',
    images: [
      {
        url: 'https://godj.com.br/tumb.jpg',
        width: 1200,
        height: 630,
        alt: 'GoDJ - Domine a Cena',
      },
    ],
    locale: 'pt_BR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'GoDJ - Domine a Cena',
    description: 'A plataforma para encontrar os próximos eventos dos seus DJs favoritos.',
    images: ['https://godj.com.br/tumb.jpg'],
  },
};


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="dark" suppressHydrationWarning>
      <body className={`${spaceGrotesk.variable} ${barlowCondensed.variable} font-sans antialiased bg-background text-foreground min-h-screen`}>
        <div className="w-full max-w-7xl mx-auto">
          <FirebaseClientProvider>
            {children}
          </FirebaseClientProvider>
          <Toaster />
        </div>
      </body>
    </html>
  );
}
